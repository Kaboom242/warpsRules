<html>
    <head>
        <title>Print Abilities</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
         width: 800px;
        }
    </style>
    <body style='background:white;'>
        <div style='height: 11in;width: 8.5in;background: white; box-sizing: border-box;border-radius: 0px;border-style: solid;border-color: white;border-width: 0.125in 0.25in 0.25in 0.25in;overflow: hidden;position: relative;display: flex;align-items: flex-start;flex-direction: column;border-radius: 0px;'><div style='display:grid;grid-template-rows: 1fr 10px 1fr 10px;grid-template-columns: 1fr;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 10px auto 10px;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Survivalist <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Survivalist</b> is able to survive off the land and manage dangerous terrain.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Survivalist 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 2
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Arid: <br><f7>Chaparral, Plains, Desert, Badlands</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Lush: <br><f7>Wetlands, Forest, Coniferous, Jungle</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Temperate: <br><f7>Plains, Pastoral, Chaparral, Wetlands, Alpine</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Severe: <br><f7>Pastoral, Forest, Coniferous, Alpine, Tundra, Ice Field</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 3
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Alpine:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Badlands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Chaparral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Coniferous:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Desert:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Forest:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Ice Field:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Pastoral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Plains:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Jungle:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Tundra:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Wet Lands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Knowledge (Nature):</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection><div style='height:3px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Survialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Forage</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                    &nbsp;&nbsp;&nbsp;  <b>Attempt Additional Forage:</b> Resist <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div>.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Region</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> 1 Rummage. <cs>1S:</cs> 2 Herbs. <cs>2S:</cs> 1 Food </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Hunt</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>Attempt to hunt within region. Cannot be done in Darkness.</f7>
                    <br><sc>2S:</sc>Kill Small(2 Meat) Creature. 
                    <br><sc>3S:</sc>Medium(4 Meat). <sc>4S:</sc>Large(6 Meat + Cloak).
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Find/Make<div style='height:1px;'></div> Shelter</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> +1 Warmth/Cool Dice.
                    <br><sc>2S:</sc> +2 Warmth/Cool Dice. <sc>2S:</sc> +1 Comfort.
                </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Specialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Gather Tinder</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Refill Tinderbox.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Expert
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Fire By Hand</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Create a Fire without using any tools.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Guide</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Party's Resist Travel Fatigue check.</div></challengeText></challengeContainer></div></actionContainter></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Survivalist <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Survivalist</b> is able to survive off the land and manage dangerous terrain.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Survivalist 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 2
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Arid: <br><f7>Chaparral, Plains, Desert, Badlands</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Lush: <br><f7>Wetlands, Forest, Coniferous, Jungle</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Temperate: <br><f7>Plains, Pastoral, Chaparral, Wetlands, Alpine</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Severe: <br><f7>Pastoral, Forest, Coniferous, Alpine, Tundra, Ice Field</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 3
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Alpine:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Badlands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Chaparral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Coniferous:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Desert:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Forest:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Ice Field:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Pastoral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Plains:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Jungle:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Tundra:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Wet Lands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Knowledge (Nature):</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection><div style='height:3px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Survialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Forage</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                    &nbsp;&nbsp;&nbsp;  <b>Attempt Additional Forage:</b> Resist <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div>.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Region</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> 1 Rummage. <cs>1S:</cs> 2 Herbs. <cs>2S:</cs> 1 Food </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Hunt</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>Attempt to hunt within region. Cannot be done in Darkness.</f7>
                    <br><sc>2S:</sc>Kill Small(2 Meat) Creature. 
                    <br><sc>3S:</sc>Medium(4 Meat). <sc>4S:</sc>Large(6 Meat + Cloak).
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Find/Make<div style='height:1px;'></div> Shelter</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> +1 Warmth/Cool Dice.
                    <br><sc>2S:</sc> +2 Warmth/Cool Dice. <sc>2S:</sc> +1 Comfort.
                </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Specialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Gather Tinder</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Refill Tinderbox.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Expert
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Fire By Hand</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Create a Fire without using any tools.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Guide</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Party's Resist Travel Fatigue check.</div></challengeText></challengeContainer></div></actionContainter></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div></div><div style='border-style:dotted none none none; border-width:2px; border-color:black; position:relative; top:5px; border-radius:0px;'></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 10px auto 10px;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;width: 353.175px;height: 489.736px;grid-gap: 2px;align-items: stretch;'><div></div></div><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;width: 353.175px;height: 489.736px;grid-gap: 2px;align-items: stretch;'><div></div></div><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div></div><div style='border-style:dotted none none none; border-radius:0px; border-width:2px; border-color:black; position:relative; top:5px;'></div></div></div>
    </body>
</html>