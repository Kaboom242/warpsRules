<html>
    <head>
        <title>Print Items</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
         width: 800px;
        }
    </style>
    <body style='background:white;'>
    <br>
<div style='/*Page Print Setup*/
                /*height: 1049px;*/
                /*width: 825px; */
                background: white; 
                box-sizing: border-box;
                border-radius: 0px;
                border-style: solid;
                /*border-color: hsla(0,55%,95%,1);*/
                /*border-width: 0.25in 0.125in 0.25in 0.80in;*/
                /*James Print*/
                border-color: white;
                border-width: 0.25in 0.125in 0.25in 0.25in;
                overflow: hidden;height: 8.5in;width: 11in; border-radius:0px;position: relative; display: flex;align-items: flex-start;flex-direction: column;transform-origin: 100% 0%; transform: rotate(270deg); left: -11in; top: 0px'><div style='display: grid;grid-template-columns: repeat(6, auto);grid-template-rows: 1fr 1fr 1fr;grid-auto-flow: row dense; justify-content: end;grid-gap: 5px 5px;margin-left: auto;'><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'><f14>Animate Object</f14><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Uncommon Scroll - Green</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Green-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 3S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/2</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Animate<br> Object <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum-Green</div></f7> </div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                            Animate medium sized mundane object within 1R. Item functions as a Poltergeist (Small) you control.
                            <br> Item stays animated for <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Trained)/ <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Untrained) Rounds.
                            <br> Target Item must not be carried by anyone.
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Over-<br> charge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> May animate 2 Items. 
                            <br><b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> May animate a large item. Functions as Poltergest (Large).
                            <br> <b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> May animate a weapon. Functions as Poltergest (Weapon)</f7>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>Per Backlash:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue</f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Make an item come alive to attack your enemies.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 10G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'><f14>Mind Projection</f14><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Uncommon Scroll - Green</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Green-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 3S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/2</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Mind<br> Projection</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>  <br><b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            Consumes personal item/lock of hair/body part of Target.
                            <br> May see through the Target eyes for 5 minutes. 
                            <br> Target may make <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Role to sense you doing so. Targets with <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> or more may resist the spell and are immune for 1 week.
                            Those without magic experience, may only have some idea what is happening.
                            <br> More Successes increases the effect of the disguise.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> See through the eyes of someone else.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 10G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkBlue-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkBlue-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkBlue-3);'><f12>Deepen Darkness</f12><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Common Scroll - Shadow</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--DarkBlue-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 1S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/3</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Deepen Darkness</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <br><b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Make an area darker to help hide what’s inside it. More Successes intensifies effect.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Intensify darkness.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 3G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkGreen-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkGreen-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkGreen-3);'><f15>Vermin Scout</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Common Scroll - Plague</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--DarkGreen-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 1S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/3</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Vermin Scout</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> <br><b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Control a neary vermin (ex: rat) to go where you desire and see through it's eyes.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> See through the eyes of nearby rat.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 3G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkPurple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkPurple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkPurple-3);'><f15>Disintegration</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Uncommon Scroll - Void</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 20px;background:var(--DarkPurple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 3S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/2</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Disintegration<br> <f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>4 Arcanum-Void</div> <br>+3 Backlash</f7> </div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Create Ball that follows Target for 4 Rounds and moves <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces per Round. On Contact apply Blast to Target.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Null</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Over-<br> charge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg, +1 Burning. <br> <b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> Ball moves +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Spaces.</f7>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>1:</b> <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Null Dmg to Casting Arm.<br><b>2:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Null Dmg to Casting Arm and Torso.<br><b>3:</b> Circle 3 Blast: Null Dmg <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f7>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeHead style='border-radius:4px 4px 4px 4px; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Null</div></div></challengeHead><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                            <f7>Has <div style='display:inline; color:black; font-weight:800;'>AP</div> <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Harm applied by Null Dmg must be removed as if it was Wound.</f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Create a ball that disintegration substance on contact.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 10G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkBlue-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkBlue-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkBlue-3);'><f11>Shadow Passage</f11><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Uncommon Scroll - Shadow</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--DarkBlue-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 3S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/2</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Shadow Passage <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>0 Arcanum-Shadow</div></f7> </div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    		Shadow you can touch is now adjacent to a shadow you can see within <img 
        src='/Resources/Art/Images/HexagonW_3R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>.
                    		<br> Shadow size does not change. Shadows can not be separated by any major barriers (large valleys, huge walls, etc.)
                    		<br> Shadows must be created by Light (Night time darkness is not a shadow.)
                    		<br> <b>Untrained:</b> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>Per Backlash:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue</f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Create an instant passage between two shadows.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 10G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkPurple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkPurple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkPurple-3);'>Black Hole<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Rare Scroll - Void</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--DarkPurple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><f8><b>Ready Cost:</b> <b style='font-weight:700; color: black;'>10<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> + 3 Spell Materials + 1 Brain + 1 Onyx (30<b6>G</b6> Gem)</f8></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 20px;background:var(--DarkPurple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/1</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Black<br> Hole <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>5 Arcanum-Void</div><br> +3 Backlash</f7><br><f7>Req: Trained</f7> </div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                            <f7>
                    		Black Hole (takes up 1 Space) is created 1R over the next <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rounds.
                            Once created, it pulls everyone and everything <b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces (Collision: <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>) every Round (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>) within 3R towards it.
                            <br> Anyone in the same Space of Black Hole takes Blast: Null: <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> every Round. Body Areas Disabled this way are destroyed. Items sucked in are destroyed.
                            </f7>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                            <f7>Each Round roll +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dice, adding result to total Successes. 
                            <br> At <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Black Hole gets 1 Circle Larger and Pulls +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> more, role is reset to 0.
                            The third time, everyone in 3R takes Blast: Null: <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and Black Hole disappears.</f7>

                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7>	
                                <b>1:</b> Black Hole is created with 3 Spaces of you.
                            	<br> <b>2:</b> Black Hole is created with 2 Spaces of you.
                            	<br> <b>3:</b> Black Hole is created with 1 Space of you.
                            </f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Tear a hole through space that pulls in all nearby.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 20G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'><f15>Lighten Load</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Common Scroll - Purple</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Purple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 1S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/3</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Lighten Load</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                                Make something weight half as much.
                                <br> In Combat: Lasts til end of Combat.
                                <br> Out of Combat: Lasts til end of Day.
                                <br> <b>Trained:</b> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>. <br><b>Untrained:</b> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.
                            </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Make an item weigh half as much for limited time.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 3G</div></div></div></div></div></div><div style='grid-column: span 2;'><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--DarkGreen-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--DarkGreen-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr 60px  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--DarkGreen-3);'>Acid Spray<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Uncommon Scroll - Plague</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><b style='font-weight:800; font-size:150%;'>&#8533;</b>&nbsp;<img 
        src='/Resources/Art/Images/EWeight.svg' 
        height='13px'
        width='13px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr auto;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--DarkGreen-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Prepared (Cost: 3S)</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/2</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Acid Spary <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum-Plague</div><br>+3 Backlash</f7> </div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeHead style='border-radius:4px 4px 4px 4px; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cone 3</div></div></challengeHead></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Acid</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><div style='display:inline; color:black; font-weight:800;'>AP</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Over-<br> charge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> +3 Range.<br> <b>+2 Backlash<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg, <div style='display:inline; color:black; font-weight:800;'>AP</div> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>1:</b> Circle 0 Blast:<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='display:inline; color:black; font-weight:800;'>XP</div> <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <br><b>2:</b> Circle 1 Blast:<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='display:inline; color:black; font-weight:800;'>XP</div> <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><br><b>3:</b> Circle 3 Blast:<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f7>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeHead style='border-radius:4px 4px 4px 4px; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Acid</div></div></challengeHead><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                            <f8>Harm applied by Acid Dmg must be removed as if it was Wound.</f8>
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Create a spray of acid.</div><div style='display: grid; grid-template-columns: auto;'><div><b>Price:</b> 10G</div></div></div></div></div></div></div></div>    </body>
</html>