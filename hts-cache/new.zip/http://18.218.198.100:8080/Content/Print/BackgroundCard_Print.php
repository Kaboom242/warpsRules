<html>
    <head>
        <title>Print Backgrounds</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
         width: 800px;
        }
    </style>
    <body style='background:white;'>
        <div style='height: 11in;width: 8.5in;background: white; box-sizing: border-box;border-radius: 0px;border-style: solid;border-color: white;border-width: 0.125in 0.25in 0.25in 0.25in;overflow: hidden;position: relative;display: flex;align-items: flex-start;flex-direction: column;border-radius: 0px;'><div style='display:grid;grid-template-rows: 1fr 10px 1fr 10px;grid-template-columns: 1fr;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 10px auto 10px;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><rulecard style='grid-template-rows:auto auto auto auto auto auto auto auto auto 80px;;'><rulecardtitle style='display:grid; grid-template-columns:1fr; background:black;'>
            <div>Background</div>
        </rulecardtitle><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <!--<b style='font-size:20px;'>Name:</b>--> 
            <span style='font-size:20px;'>&nbsp;&nbsp;Caldor Mobius</span>
        </div><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px;'><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Age:</b> <span style='font-size:16px;'>25</span>
            </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Birthdate:</b> <span style='font-size:15px;'>June 15</span>
            </div></div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Description</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Height:</b> 6’1
                    <br><b>Eyes:</b> Pale Blue
                    <br><b>Hair:</b> Long Black Hair. Long Black beard.
                    <br><b>Features:</b> Average Body Type. Looks older than he is.

                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>From</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Ersen Fields:</b> Grew up a peasant. High magic aptitude was noticed. Sold to a wizard of The Clan.
                    <br><b>The Skillegs:</b> Cold dour tower in the mountains.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Family</u></b>
            <br>
            <span style='font-size:10px;'>
                    No Memory of them. Kind of strange.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Connections</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>The Clan:</b> Mysterious Mage School. Did not tell you their secrets. Looking for additional color of magic.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Goal</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Knowledge:</b> Find a new color of magic.
                    <br><b>Adventure:</b> See the world.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Complications</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Captured:</b> Was captured by goblins on first ‘independent test’.
                    <br><b>Memory Problems:</b> Have trouble remembering things that maybe you should.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Reputation</u></b>
            <br>
            <span style='font-size:10px;'><b>Minor Fame (3LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Renown (6LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Legend (9LP):</b></span>
        </div></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div><rulecard style='grid-template-rows:auto auto auto auto auto auto auto auto auto 80px;;'><rulecardtitle style='display:grid; grid-template-columns:1fr; background:black;'>
            <div>Background</div>
        </rulecardtitle><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <!--<b style='font-size:20px;'>Name:</b>--> 
            <span style='font-size:20px;'>&nbsp;&nbsp;Galvan McGallagher</span>
        </div><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px;'><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Age:</b> <span style='font-size:16px;'>16</span>
            </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Birthdate:</b> <span style='font-size:15px;'>May 4</span>
            </div></div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Description</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Height:</b> 5’9
                    <br><b>Eyes:</b> Green
                    <br><b>Hair:</b> Brown curly hair, bushy eyebrows.
                    <br><b>Features:</b> Chunkier side of fat. Big broad smile. Aggressively friendly.

                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>From</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Arcadian Forest:</b> Forest outside Arcadia
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Family</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Daniel McGallagher (Father):</b> Woodsman/hunter. Raised you in the forest.
                    <br><b>Grams (Grandmother):</b> Peasant in the nearby village of Toterage. On mother’s side. Taught him a bit of music.
                    <br><b>(Mother):</b> Died when young.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Connections</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Ol’ Brandlebuck, The Oaken Leaf:</b> Druid. Traveling Druid of the western mountains of Ersonia. Friend and mentor. 
                    <br><b>Sir Ives:</b> Knight. Master of Ceremonies. Introduced you to the Revelation of Yavera.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Goal</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Fame:</b> Become a well known name. Make my father proud. Be Remembered.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Complications</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Addiction:</b> Sir Ives said drugs were good.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Reputation</u></b>
            <br>
            <span style='font-size:10px;'><b>Minor Fame (3LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Renown (6LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Legend (9LP):</b></span>
        </div></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div></div><div style='border-style:dotted none none none; border-width:2px; border-color:black; position:relative; top:5px; border-radius:0px;'></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 10px auto 10px;background:white;grid-gap: 0px 0px;grid-auto-flow: row;'><rulecard style='grid-template-rows:auto auto auto auto auto auto auto auto auto 80px;;'><rulecardtitle style='display:grid; grid-template-columns:1fr; background:black;'>
            <div>Background</div>
        </rulecardtitle><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <!--<b style='font-size:20px;'>Name:</b>--> 
            <span style='font-size:20px;'>&nbsp;&nbsp;Kenwynn Rheddovir</span>
        </div><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px;'><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Age:</b> <span style='font-size:16px;'>22</span>
            </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Birthdate:</b> <span style='font-size:15px;'>October 28</span>
            </div></div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Description</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Height:</b> 5’10
                    <br><b>Eyes:</b> Green
                    <br><b>Hair:</b> Wavy brown. Short-medium length. Unshaven.
                    <br><b>Features:</b> Lean. Handsome (but not too much). Scar on off arm (ran through when village when sacked.)

                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>From</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Venica</b> Outskirts of Mecuria City (countryside). Raided by a military group.
                    <br><b>Worked</b> Venica Capital. Worked as a smuggler/thief for the Black Hand.
                    <br><b>Traveled</b> Venica-Ersonia. To get away from Black Hand.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Family</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Elaine Rheddovir (Mother):</b> Herder. Ekes existence in the fields. Still near Mercuria City.
                    <br><b>Balan Rheddovir (Younger Brother):</b> 13. Helps the mom.
                    <br><b>Ancestor:</b> Forest Elf. May still be alive.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Connections</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Frank (Begger):</b> Secretly information broker. Travels around selling information.
                    <br><b>Bree Kelso (Barkeeper):</b> Cleared from murder on first job.
                    <br><b>Maric (Mechant):</b> Traveling merchant you you helped.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Goal</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Fortune:</b> Use money to settle score and get back at Black Hand.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Complications</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Pursued:</b> Pursued by the Black Hand. Hunting by a guy named the Fingernail.
                    <br><b>Red Hand:</b> Symbol of a Red Hand. Burned your city. 
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Reputation</u></b>
            <br>
            <span style='font-size:10px;'><b>Minor Fame (3LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Renown (6LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Legend (9LP):</b></span>
        </div></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div><rulecard style='grid-template-rows:auto auto auto auto auto auto auto auto auto 80px;;'><rulecardtitle style='display:grid; grid-template-columns:1fr; background:black;'>
            <div>Background</div>
        </rulecardtitle><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <!--<b style='font-size:20px;'>Name:</b>--> 
            <span style='font-size:20px;'>&nbsp;&nbsp;Tsar-Jen</span>
        </div><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px;'><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Age:</b> <span style='font-size:16px;'>17</span>
            </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
                <b style='font-size:15px;'>Birthdate:</b> <span style='font-size:15px;'>December 28</span>
            </div></div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Description</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Height:</b> 5’7
                    <br><b>Eyes:</b> Purple, Dark with light stripes.
                    <br><b>Hair:</b> Black Hair w/ White Streaks. Long.
                    <br><b>Features:</b> Beads in hair. Shifty eyes.

                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>From</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Region:</b> The Misty Isles
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Family</u></b>
            <br>
            <span style='font-size:10px;'>
                    Family of prominent doctors.
                    <br><b>Maoilos Jen (Father):</b> Important surgeon among the High Elves.
                    <br><b>Messin Jen (Eldest Brother):</b> Healer.
                    <br><b>Theros Jen (2nd Older Brother):</b> Mage.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Connections</u></b>
            <br>
            <span style='font-size:10px;'>
                    ...
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Goal</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Knowledge:</b> To have a true understanding of Humans Biology, Language, and Psyche.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Complications</u></b>
            <br>
            <span style='font-size:10px;'>
                    <b>Bullied:</b> Weirdo with an interest in humans.
                    <br><b>Outcast:</b> Dislikes his family. Disowned. Kicked off island.
                </span>
        </div><div style='color:black; border:solid black 1px; padding:2px 1px 2px 1px'>
            <b style='font-size:9px;'><u>Reputation</u></b>
            <br>
            <span style='font-size:10px;'><b>Minor Fame (3LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Renown (6LP):</b></span>
            <br><br>
            <span style='font-size:10px;'><b>Legend (9LP):</b></span>
        </div></rulecard><div style='border-style:none dotted none none; border-radius:0px; border-width:2px; border-color:black; position:relative; right:5px;'></div></div><div style='border-style:dotted none none none; border-radius:0px; border-width:2px; border-color:black; position:relative; top:5px;'></div></div></div>
    </body>
</html>