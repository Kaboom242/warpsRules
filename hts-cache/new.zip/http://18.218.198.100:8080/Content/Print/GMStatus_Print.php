<html>
    <head>
        <title>GM Status Cards</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style>    </head>
    <style type="text/css">
        body { width: 800px; background:white;}
    </style>
    <body>
<style type="text/css">
.RuleTitle {
    font-size:16px; 
    color:black; 
    border-radius: 0px 100px 100px 0px; 
    padding: 1px 5px;
    font-weight: 400;
}

</style>


<div style='
/*Page Print Setup*/
height: 1049px; 
width: 825px; 
background: white; 
box-sizing: border-box;
border-radius: 0px;


position: relative;
display: flex;
align-items: flex-start;
flex-direction: column;
'>
    <div style='
    display:grid;
    grid-template-rows: 24px 1fr;
    grid-template-columns: auto;
    width: 100%;
    height: 100%;
    grid-gap: 2px;
    '>
        <!--
        <div class='RuleTitle' style='font-size:18px; color:white; background:hsla(122.4,0%,23%,1); ' >
            NPC Status
        </div>
        -->
        <div style="
        color: white;
        background:hsla(41.4,0%,21%,1);
        border-radius: 0px;
        border-bottom: 1px solid black;
        border-top: 1px solid black;
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
        font-size: 16px;
        margin: 0px 0px 0px 0px;
        ">
            NPC Combat Status
        </div>
        <div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-auto-flow:columns; grid-template-rows: 1fr; grid-template-columns:1fr 1fr;background:white; border-radius:4px;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:rows; grid-template-rows: repeat(4, 1fr);background:white; border-radius:4px;'><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-auto-flow:rows; grid-template-rows: repeat(4, 1fr);background:white; border-radius:4px;'><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div><div style='background:red; height:1fr;display:grid; grid-gap:2px; grid-template-columns: 1fr;height:100%; width:100%;'><div style='background:red; height:auto;display:grid; grid-gap:2px; grid-auto-flow:row; grid-template-rows: 30px 1fr 30px; grid-template-columns:1fr;background:white; border-radius:4px;'><div style='display:grid; grid-gap:2px; grid-auto-flow:column; grid-template-rows:1fr; grid-template-columns:5fr 4fr 2fr;background:white; border-radius:4px;'><div style='background:white; border-radius:4px; border:solid 1px black;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr 12px 12px 12px 20px; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Con.</div>
            <div style='background:white; border-radius:0px 0px 0px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black;'></div>
            <div style='background:var(--Dmg-1); border-radius:0px; border-left:1px solid black; border-right:1px solid black;'></div>
            <div style='background:var(--Dmg-2); border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:center;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr; border:solid 1px black; background:black;'>
            <div style='background:black; color:white; display:flex; align-items:center; font-size:8px; font-weight:700; border-radius:4px 0px 0px 4px; padding:2px 4px 2px 2px;'>Will</div>
            <div style='background:white; border-radius:0px 4px 4px 0px; display:flex; align-items:center; justify-content:flex-end;; padding:2px 18px 0px 2px; font-weight:700; font-size:14px; color:black;'></div>
        </div>
        </div><div style='background:black;border-radius:4px; padding:0px;display:grid; grid-template-rows:auto 1fr; grid-auto-flow:row; grid-gap:0px 1px; border:solid 1px black;'><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px 4px 0px 0px; padding:1px 1px 1px 5px; display:flex; align-items:flex-end; justify-content:left;'><b>Body Area</b></div><div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:var(--Dmg-2); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Wound</b></div><div style='background:var(--Dmg-4); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div><div style='background:var(--Dmg-5); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>C</b></div><div style='color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Conditions</b></div></div><div style='display:grid; grid-template-rows:1fr; grid-template-columns:80px 45px 42px 67px 42px 15px ; grid-auto-flow:column; grid-gap:1px;'><div style='background:white; color:black; border-radius:0px 0px 0px 4px; display:flex; flex-direction:row; align-items:flex-start; justify-content:start; font-size:10px; padding-top:5px; padding-left:15px; font-size:12px;'><b>Vitals</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'><div style='display:flex; align-items:top;'></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div><div style='background:white; color:black; border-radius:0px 0px 4px 0px; display:flex; flex-direction:row; align-items:center; justify-content:center; font-size:10px;'></div></div></div><div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:2px;'>
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:1fr 1fr 1fr; grid-gap:1px; border:solid 1px black;'>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; 
        border-radius:4px 0px 0px 4px; padding:1px 1px 1px 1px; display:flex; align-items:start; justify-content:center;'>
            Item
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; border-right:solid; border-color:black; border-width:1px; background:var(--Gray-1);
        border-radius:0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Dmg
        </div>
        <div style='background:white; color:black; font-size:7px; font-weight:700; background:var(--Gray-2);
        border-radius:0px 4px 4px 0px; padding:1px 2px 1px 1px; display:flex; align-items:end; justify-content:flex-end;'>
            Brk
        </div>
    </div>
    </div></div></div></div></div>    </div>
</div>




</body>
</html>