<html>
<head>
    <title>Region Compendium</title>
    <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style></head>
<style type='text/css'>
    
        body { width: 800px;}
        page {
            height: 11in;
            width: 8.5in; /*825px;*/
            background: white; 
            box-sizing: border-box;
            border-radius: 0px;
            border-style: solid;
            /*Print Helper Borders*/
            /*border-color: <?=HSL('Red',true,90)?>;*/
            /*border-width: 0.125in 0.25in 1.20in 0.25in;*/
            /*Display Borders*/
            border-color: white;
            border-width: 0.125in 0.25in 1.20in 0.25in;
            margin: 1px;
            /*overflow: hidden;*/
                
            position: relative;
            display: grid;
            grid-auto-flow: row;
            grid-auto-rows: min-content;
            grid-gap: 2px;
            
            color: black;
            font-size: 10px;
        }
        RegionPage {
            display:grid;
            grid-template-columns:1fr 1fr;
            grid-auto-flow: column dense;
            grid-gap:1px;
        }
        RegionTitle {
            border: solid 0px black;
            border-radius: 4px 4px 0px 0px;
            padding: 1px 2px 1px 2px;
            font-size: 20px;
            font-weight: 700;
            grid-column: 1/-1;
            background:  var(--Purple-4);
            color: white;
        }
        InnerTitle {
            border: solid 0px black;
            border-radius: 0px 0px 0px 0px;
            padding: 0px 1px 1px 1px;
            font-size: 15px;
            font-weight: 700;
            grid-column: 1/-1;
            background:  var(--Purple-4);
            color: white;
        }
        InnerContainer {
            border: solid 3px var(--Purple-4);
            border-radius: 4px;
            /*padding: 1px 2px 1px 2px;*/
            margin:0px 2px 0px 2px;
            display:grid;
        }
        InnerSectionContainer {
            /*padding: 1px 2px 1px 2px;*/
            width: 100%;
            padding:1px;
            display:grid;
            grid-template-columns:1fr 1fr;
            grid-auto-flow: column dense;
            grid-gap:1px;
        }
        SectionContainer {
            border: solid 3px var(--Purple-3);
            border-radius: 4px;
            /*padding: 1px 2px 1px 2px;*/
            width: 100%;
        }
        SectionTitle {
            display: inline-block;
            font-size: 12px;
            font-weight: 600;
            background:  var(--Purple-3);
            color: white;
            width: 100%;
            padding-left: 5px; 
            padding-bottom: 2px; 
            margin-bottom:1px;
            /*right:0px;*/
        }
        gf { 
            font-weight: 700;
            font-size: 80%;
        }
        innerforage { 
            font-weight: 500;
            font-size: 10px;
            display:grid;
            grid-template-columns:auto 1fr;
            grid-gap:2px;
        }
        tabDiv {
            padding-left: 5px;
            margin-bottom: 1px;
            display: flex;
        }
        
        .green1bg {
            background: var(--Green-1);
        }
        .green1border {
            border-color: var(--Green-1);
        }
        
        .green2bg {
            background: var(--Green-2);
        }
        .green2border {
            border-color: var(--Green-2);
        }
        
        .green3bg {
            background: var(--Green-3);
        }
        .green3border {
            border-color: var(--Green-3);
        }
        
        .green4bg {
            background: var(--Green-4);
        }
        .green4border {
            border-color: var(--Green-4);
        }
        
        .turqouise3bg {
            background: var(--Turquoise-3);
        }
        .turqouise3border {
            border-color: var(--Turquoise-3);
        }
        
        .turqouise4bg {
            background: var(--Turquoise-4);
        }
        .turqouise4border {
            border-color: var(--Turquoise-4);
        }
        
        .yellow2bg {
            background: var(--Yellow-2);
        }
        .yellow2border {
            border-color: var(--Yellow-2);
        }
        
        .yellow3bg {
            background: var(--Yellow-3);
        }
        .yellow3border {
            border-color: var(--Yellow-3);
        }
        
        .yellow4bg {
            background: var(--Yellow-4);
        }
        .yellow4border {
            border-color: var(--Yellow-4);
        }
        
        .purple4bg {
            background: var(--Purple-4);
        }
        .purple4border {
            border-color: var(--Purple-4);
        }
        
        .blue2bg {
            background: var(--Blue-2);
        }
        .blue2border {
            border-color: var(--Blue-2);
        }
        
        .blue3bg {
            background: var(--Blue-3);
        }
        .blue3border {
            border-color: var(--Blue-3);
        }
        
        .blue4bg {
            background: var(--Blue-4);
        }
        .blue4border {
            border-color: var(--Blue-4);
        }
        
    </style>

<body style='background:black;'>
    <div style='font-weight:700; margin:5px 5px 5px 5px; color:white; font-size:25px;'>General Regions</div>
    <div style='display:grid; grid-gap:10px; grid-auto-flow:rows;'><RegionPage style='background:white; color:black;'><RegionTitle class='blue3bg'>Alpine <f10>Temperate, Severe</f10></RegionTitle><SectionContainer class='blue3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A high and cold biome usually found on steep mountain ranges and plateaus.</SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Summer:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>1S:</sc> Cold 2. <sc>2S:</sc> Cold 3.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 2. <sc>1S:</sc> Cold 3.
</div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Only available in Forage Bonus <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Large Stoney Cliffs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass lands and Numerous Cliffs cut across mountains.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliffs. Falling Rocks, Dangerous Path</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Snowy Peaks</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Rocks and snow, crest the sharp peaks.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliffs.</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Icy Summit</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>High over the world, these cliffsides are almost entirely ice, with wind howling along the cliffside below.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Dangerous Path</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Volcanic Rock</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Ash and Sharp Volcanic rocks from ancient lava flows. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Glacial Tongue</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A Glacier, dirty with gravel and rock, creeps down a mountain valley</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Jump Over: Ravine/Crevise.</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Icy Caves</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A giant glacial mass scrapes through the rock causing a maze of frozen caves to cut into the ice.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ice Cave.</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Mountain Tops</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Rocks and thin section of shrubbs grow on the mountain top with a view far down into the distance on either end.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Geysers</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A section of the cliff stinks of sulfur and has geryser which occasionaly spouts hot steam which falls into the surrounding pool.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dormant Volcano</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A seemingly dormant volcano lies at the top of the mountain with an empty crater sloping deeper into the earth.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Gravel Slopes</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Granite boulders and gravel slopes dominate the rocky landscape.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Plateau</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A single cliff creates a long fla plateau in which the cliffside traces the horizon.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Shallow Cliff</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Spires</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Among the thin grass, rocky spires jut out at odd angles from the sloped terrain above and below.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cold Stream</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Fresh from the icecaps a small stream starts to trickle down the mountain here.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>High Mountain Meadow</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Green flowery meadow, with grand views of valleys and stony cliffs</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Meadow Ponds</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grassy ponds with large boulders, nessled at the top of a high valley</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shrub Slopes</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Brushes and Rocks cover the slopes</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> </div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue Waterfall</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large waterfull pours down from cliffs above creating a blue pool agaisnt the cliffside.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Alpine Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A flatter section of the cliffs is home to an exapnse of tress which grow among the cliffs.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mirror Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Flat smooth lake resting in a rocky bowl.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mossy Spring</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A mossy spring emmerges from under a large boulder creating a green path down the mountain.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 11 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 - 14 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter/Fall</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hail falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>15 - 17 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Blizzard:</b>  <span style='padding: 0px 2px;'>A terrible onslaught of sleet and snow pounds the area. <b>Wet</b>, <b>+2 Cold Exposure</b>, <b>+1 Travel Fatigue</b>,<b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b></span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Rocky Area:</b>  <span style='padding: 0px 2px;'>The way is difficult to cross and the path is partialy blocked. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Deep Snow:</b>  <span style='padding: 0px 2px;'>Heavy snowfall has caused the path forward to be difficult to cross. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 - 9 : </span></b></div><div><b>  Dangerous Path:</b>  <span style='padding: 0px 2px;'>The path comes to a narrow passage around the cliffside. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge <fc>0S:</fc> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Ravine:</b>  <span style='padding: 0px 2px;'>In order to proceed a crack in the rocks must be jumped.
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Falling Rocks:</b>  <span style='padding: 0px 2px;'>While moving among the cliffs, rocks slide down upon the party. Characters attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenge. <sc>2S:</sc> Avoid Rocks. <sc>1S:</sc> Take <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> Take <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Cave:</b>  <span style='padding: 0px 2px;'>A dark entrance in the rock</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Mine:</b>  <span style='padding: 0px 2px;'>Carved out, rubble left by the entrance.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 - 9 : </span></b></div><div><b>  Monster Burrow:</b>  <span style='padding: 0px 2px;'>A dug out hole with bits of fur/feather/scales on the outside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Volcanic Crevice:</b>  <span style='padding: 0px 2px;'>Though warmer that the surrounding area, this entrance into the mountain may contain other creatures.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Hole through the Mountain:</b>  <span style='padding: 0px 2px;'>A stange strait passage through the mountain.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Subterranian Lake:</b>  <span style='padding: 0px 2px;'>A river waterfall snakes into a deeper cave which is almost entirely filled with icy water.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Mountain's Cure:</b>  <span style='padding: 0px 2px;'>A Flower that only grows in rare spots can help cure the stranges illnesses</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Fallen Adventurer:</b>  <span style='padding: 0px 2px;'>Man who has fallen great height, leaving most of his gear.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Spectacular View:</b>  <span style='padding: 0px 2px;'>Though dangerous, the veiw below feels like standing on the roof of the world. Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Morale and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Inspiration.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Hillside Plants:</b>  <span style='padding: 0px 2px;'>Rare flowers survive agaisnt the wind on the cliffside. Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs adn <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Medicine.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Lodge, old miner/Lumberjack lives a secluded life</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Druid scouting edges of cliffs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>An outpost built to watch the cliff passes is staffed by the local military</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Outpost:</b>  <span style='padding: 0px 2px;'>Barbarian's A temporary village, the move depending on food and season.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>A few men and thier Ox are working their way up and over the pass.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>2 guides and 4-5 Donkeys are scaling the tight path up the mountain.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Traveler:</b>  <span style='padding: 0px 2px;'>Mountain Climbers collecting cliff eggs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Mountain Peak Water Tower</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A party of 2 to 5 wolves will follow and hunt the party for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Getting to close to it's cave will cause the bear to attack to protect its home and even bring home it's dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Avens:</b>  <span style='padding: 0px 2px;'>3 to 5 Avens use this area as rest point for their travels and will attack the party if threatened.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Harpys:</b>  <span style='padding: 0px 2px;'>A Harpy nest is nearby and 2 to 5 Harpys will attack the party as prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 19 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Yeti:</b>  <span style='padding: 0px 2px;'>A dangerous Yeti makes this part of the mountain it's home and is very terriorial.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>20 - 22 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Griffin:</b>  <span style='padding: 0px 2px;'>A griffin keeps it's nest in the high mountain cliffs and often glides overhead looking for prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 - 25 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogre:</b>  <span style='padding: 0px 2px;'>Typically hibernating in a neaby cave, those that wander to close may end up as part of it's bone shrine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>26 - 28 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Rock Troll:</b>  <span style='padding: 0px 2px;'>A rock troll can sleep for decades but will be awoken by those who come to close or make too much noise.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 - 31 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Wyvern:</b>  <span style='padding: 0px 2px;'>A nest of 2 or 3 wyverns nearby use this as their hinting area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Mountain Giant:</b>  <span style='padding: 0px 2px;'>Living far from society in the vallys between the highest mountains, the mountain giant sleeps.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Wyrm:</b>  <span style='padding: 0px 2px;'>Gaint Dragon Snake, can scale cliffs and burrow through soft dirt, a party should be weary of a sneaking Wyrm.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>34 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Dragon:</b>  <span style='padding: 0px 2px;'>A dragon makes i's nest inside the mountain, where it keeps a horde of rare treasure.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hungery Dragon:</b>  <span style='padding: 0px 2px;'>Dragon has been flying down valleys and stealing sheep.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Alter to Other Space:</b>  <span style='padding: 0px 2px;'>This peak has an acient alter, of forbidden magic sealing a horror beneath. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Treasure of the Mountain Giant:</b>  <span style='padding: 0px 2px;'>In order to break a curse of endless winter, a mountain giant from the distance peaks must be convinced to give up a prized peice of jewelery.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Aven Summit:</b>  <span style='padding: 0px 2px;'>Only by climbing the highest peak in the region, a deadly and dangerous climb, can you gain the respect of the Aven tribes, so they may allow you passage into their sky cities.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='yellow4bg'>Badlands <f10>Arid</f10></RegionTitle><SectionContainer class='yellow4border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>An area made up of mostly uneven rocks with little vegitation.</SectionContainer><SectionContainer class='yellow4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Winter:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Heat 1 + Cold 1. <sc>1S:</sc> Heat 1 + Cold 2. <sc>2S:</sc> Heat 2 + Cold 3.
    <br>
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Heat 1 + Cold 1. <sc>1S:</sc> Heat 2 + Cold 2. <sc>2S:</sc> Heat 3 + Cold 3.
    <br>
    <b>Summer:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Heat 1 + Cold 1. <sc>1S:</sc> Heat 2 + Cold 1. <sc>2S:</sc> Heat 3 + Cold 2.
</div></div></SectionContainer><SectionContainer class='yellow4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow4bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Only available in Forage Bonus <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shadow Smoke Ravine</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A Canyon, with rocky spikes climbing out of dark smoke.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>Cliffs</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sandstone Rock Canyon</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A narrow, passage through sandy rock</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Gravel Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hills, of Gravel dirt and sand seem to climb up and down for eternity.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>+1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sulfer Fields</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The many cracks and spires here formcolumns and small shelved pools of steaming sulfer. The liquid itself smells awful and shimmers a hundred colors in the sun.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Obsidian Pit</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The rocks here are oily and pitch black. Most of the landscape is covered in sharp spires and crevices among the blankened fields.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Volcanic Fissure</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>An open volcanic crack is found and runs for leagues in multiple directions. From it steam and even pockets of molten rock are emitted.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Black Water</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A rancid smell comes from most of the water here, and only some small pools look remotely drinkable. All plantlife seems dead for miles</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Stone Pillars</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hundreds of thousands stone pillars and connectors reach to the sky</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rock Hole Canopy</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large stone pillars support a rocky swiss cheese holed ceiling letting light and motes of sand down.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Knife Canyon</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A pit of jagged rocks creates a forest of narrow crevices which decend into deep jagged cracks.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Scorched Rocks</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Some recent volcanic activity has burned the jagged rocks which make up the landscape into an ashen color.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grey Water</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Some murky grey color has formed among the pools here, and the local plants all seem a strange color as well.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dead Coral Mountains</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>White, grey and dead gaint coral reef, Hard sharp rocks and odd shapes choke the path.  </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ancient Stone</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Up and down Short steep hills, Littered with large rocks, boulders and, some stone fossils</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Forest Columns</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large columns of rock form a maze in the valley. The columns often have greenery around them and tress growing in the cracks.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Fog</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Stone Bowl Ponds</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>From the seldom rain water, large stone bowls collect. The water sits waiting to dry out.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Stream</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Moving through the cracks of the rocky horizon, a small stream flows from an eventualy back into the earth.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Red Rock Cliff Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Green Trees and vines drap down Large stoney rocks and cliff side, carved caves and paths connect the whole cliff together.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Crystal Geode Lakes</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Up and down the sides of the canyon large purple crystals protrude, at the base a clear lake, filled in with geodes sparkles and shines.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Waterfall Spires</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large flat cliff ends in series of spires, with water tumbling down through the spiky incline into a clear pool below.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='yellow4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow4bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer</div> Drought:</b>  <span style='padding: 0px 2px;'>All Forage Hunt Bonuses are reduced a Level (Ex: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.) Areas with water only offer <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Water instead.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Heatwave:</b>  <span style='padding: 0px 2px;'>It is even hotter than normal, with the sun beating down through a cloudless sky.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Earthquake:</b>  <span style='padding: 0px 2px;'>Earthquakes shake the earth. In Combat each Round roll <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <cs>2S:</cs> Ground is Difficult 2.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Dust Storm:</b>  <span style='padding: 0px 2px;'>
        Wind kicks up a hige clud of dust in the area making it difficult to see and breathe.
        <br> <b>+1 Travel Fatigue</b>, Characters attempt Sense Challenge: <sc>0S:</sc> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> if not in Shelter. <sc>2S:</sc> Find shelter from the Dust. 
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hail falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Sandstone tubes:</b>  <span style='padding: 0px 2px;'>a hive of tubes poking out of the stone.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Rock Creavous:</b>  <span style='padding: 0px 2px;'>A Large Crack in the Rock leads into deep depths.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Volcanic Cave:</b>  <span style='padding: 0px 2px;'>A partial volcano has created an opening into the earth. The way is partially lined with pools of flowing lava.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Obsiddian Grotto:</b>  <span style='padding: 0px 2px;'>Oily black crevices form a network of dark and shiny caves with pools of deep dark water.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Dead Adventurer:</b>  <span style='padding: 0px 2px;'>Looks like he either starved or ran out of water.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Bandits Stash:</b>  <span style='padding: 0px 2px;'>A stash of gold under some rocks.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Rocky Garden:</b>  <span style='padding: 0px 2px;'>Some rocks form around a garden of rare plants. <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fizzyn, <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Medicine, and <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Rare Minerals:</b>  <span style='padding: 0px 2px;'>Thursting from the earth is a spire of rare and valuable minerals. <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spell Materials and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gems.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Off-Road</div> Village:</b>  <span style='padding: 0px 2px;'>A group lives in house carved into canyon walls, bridges and tunnels connecting areas.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Off-Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>And oild burned out stone tower. Few men still stand vigil</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/</div> Outpost:</b>  <span style='padding: 0px 2px;'>A rare trading outpost where humans and goblins do actual trade. While always weary of each other, surviving the harsh conditions seems to come first.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>A mage of immense power lives far from civilization as it gives him space to attempt his bizzare experiments.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'><div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hobgolbin/Orc/Shaman</div> Golbins:</b>  <span style='padding: 0px 2px;'>Goblin bands attempt to eek out an existense here, though they seem to prefer the robbign of the rare traveler instead.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Scorpian:</b>  <span style='padding: 0px 2px;'>The party crosses too cloese to nest and 2 or 4 Large Scorpians attack the intruders.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Centuars:</b>  <span style='padding: 0px 2px;'>A group of 4 to 5 centuars is passing through and may offer trade or battle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Lizard Men:</b>  <span style='padding: 0px 2px;'>A hunting party of 3 to 5 lizardmen is stationed nearby and will attack the party if they look weak.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Scorpian Men:</b>  <span style='padding: 0px 2px;'>A warband of 2 to 4 Scorpian Men is walking through the desert and decide the party seems like easy prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 - 23 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Minatuar:</b>  <span style='padding: 0px 2px;'>The Bull head man, short temper and all muscle. It's charge into a party can break even the most vetern teams.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 - 26 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Dung Beetle:</b>  <span style='padding: 0px 2px;'>A giant dung beetle has a nearby lair and attacks anyone who interrupts it's work.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>27 - 29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Rock Troll:</b>  <span style='padding: 0px 2px;'>A rock troll sleeps among the nearby boulders, but will awake if it senses something it can eat.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 - 32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hill Gint:</b>  <span style='padding: 0px 2px;'>Hill Giants can be found here, typically sleeping in one of the many rock caves formed by the landscape.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Giant Scorpian:</b>  <span style='padding: 0px 2px;'>Getting too close to the liar of Giant Scorpian, it decides to feed the party to it's children (2 to 4 Large Scorpians).</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>34 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Dragon:</b>  <span style='padding: 0px 2px;'>Dragons often make their liars in the area, typically in places of high volcanic activity.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>35 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Lich:</b>  <span style='padding: 0px 2px;'>From an age long forgotten, a lich mkes it's liar here far from civilizations, but may see the party as an opportunity for experimentation.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Fungal Creep:</b>  <span style='padding: 0px 2px;'>A fungal net of red, purple gunk is steching over the area like a demon spider web. The creatures and monsters skeltons seam to be the first attacked. As you move further in The Skeltons and carcasses become animated like puppets by the fungal creep.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Blood Moon:</b>  <span style='padding: 0px 2px;'>As the full moon, crests its pericing red hue baths the land in crimson. Dark clouds patch over the sky letting loose thick globby red rain. The screams of the damned fill the night, has horrors decend. Survive till morning to see the cleansing light of day.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  The Lich's Tomb:</b>  <span style='padding: 0px 2px;'>Legend has it a ancient lich built a palce for himself here, surrrounded in magic items and treasure, but booby trapped. Some even say it sits on an island in a sea of mercury.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Color From Space:</b>  <span style='padding: 0px 2px;'>Some comet has crashed into the area. The closer to the impact site the more warped and disturbing the landscape becomes, eventually into something resembing a nightmare.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='green2bg'>Chaparral <f10>Temperate, Arid</f10></RegionTitle><SectionContainer class='green2border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A dry area with scattered shrubbery.</SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Summer:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Heat 1. <sc>2S:</sc> Heat 2.
</div></div></SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green2bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Scorched Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dusty Charred black hills, with black twigs of bushes.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dry River Wash</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A Sandy snaking bouldered path through the hills, After it rains in the mountains the wash runs.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sandstone, Gravel hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large sandstone rocks hills climbing up 500 feet, and back down row after row.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Still Water Quarry</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>An old quarry stretched for miles and is filled with a dark colored still water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dust Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Long hills of dust and sparse tufts of grass stretch into the distance.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>High Brush</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dry tall brush, dense with sticks.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>+1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sandstone Pillars</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Sandstone rocky pillars break up the sloping hills.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Boulder Field</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A field of boulders is scattered around, some saller than a fist, and others larger than a house.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Cliffs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large rock formations break through the hills and valleys.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mud Pit</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dry riverbed is covered with cracked muddy earth and small pools of dirty water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Green Shrubs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A hilly landscape, rolling with short small green shrubs.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Golden-Green Hills</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills roll into the horizon with various shades of green and gold.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky River</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A river speeds down the hillside through the rocks and crevices.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flowery Shrubs</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The shrubs are in bloom and petals of several colors dot the hillsides.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Small Trees</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The landscape is lined with many small trees scattered across the land.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Green Canyon Creek</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Cutting through dusty brushy hills, a creek surrounded by ak trees and green brush.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ravine</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Small River</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Not a large river, but it makes its way through the hills, brush and trees.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Vine Gardens</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grape vines, song birds and shady trees, nestle in this small pocket.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lush Hillside</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hills rich with trees and other plants roll into the horizon.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Valley Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Several steams pool into a large blue lake nesteled between the mountains.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green2bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer/Fall</div> Wildfires:</b>  <span style='padding: 0px 2px;'>A fire nearby has filled the area with smoke and ash. Resist 2 Fatigue w/ Endr. Visibility 2R.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Thick Underbursh:</b>  <span style='padding: 0px 2px;'>Dense trees and foilage make travel in this area difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Rocky Area:</b>  <span style='padding: 0px 2px;'>The way is difficult to cross and the path is partialy blocked. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 - 9 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek cross through a rocky hillside with swift white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Sandstone Cliff Cave:</b>  <span style='padding: 0px 2px;'>Worn/Dug into the sandstone rock, soft sand leads further in.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Rocky Ravine:</b>  <span style='padding: 0px 2px;'>A rocky creavous plunges into the dark, faint sounds of live echo from below. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Hill Cave:</b>  <span style='padding: 0px 2px;'>A rocky cave opens up into the hills. Foul smells of rot and human bone indicate it could possibly be the home of ogres.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Rock Pit:</b>  <span style='padding: 0px 2px;'>A ravine reaches down into the earth from the spaces between some rocky spires.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Hidden Alcohol:</b>  <span style='padding: 0px 2px;'>Tucked into of Rocks in a shaded spot is some Wine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Medicinal Plant:</b>  <span style='padding: 0px 2px;'>With a succussful Nature/Survivalist Check Players can find a plant thats comparable to a Healing potion or Medicine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Abandoned Camp:</b>  <span style='padding: 0px 2px;'>A recently abadoned camp was left behind along with <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food, 3 Arrows and a Round Shield.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Cooled Grotto:</b>  <span style='padding: 0px 2px;'>Some rocky areas open up to reveal fresh water, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs, Shelter (1 Warm/Cool Dice), and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>An old Mine, a couple residents still live here.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>Old Tan Hermit Meditating ontop of large round rocks.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>A man dragging a sickly horse pulling a small wagon of supplies</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>A village has grown up in this area and is welcome to travelers with money to spend.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>A carvan is working it's way to the next reagion and contains everything you could find in a village.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Bandits:</b>  <span style='padding: 0px 2px;'>A gang of bandits, 1 to 3 Bandits and 1 to 3 Bandit Archers, try to extract tolls from hapless travelers. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Bandit Leader</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A party of 2 to 5 wolves will follow and hunt the party for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Getting to close to it's cave will cause the bear to attack to protect its home and even bring home it's dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Goblins:</b>  <span style='padding: 0px 2px;'>A group of 3 to 7 Goblins has taken residense here and like to rob and eat those weak enough for them to catch. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Goblin Rider, Hobgoblin, Goblin Shaman, Orc.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Harpies:</b>  <span style='padding: 0px 2px;'>A nest of 3 to 5 Harpys is nearby and those who enter may become their food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 - 23 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Slime:</b>  <span style='padding: 0px 2px;'>1 or 2 slimes make a home in a remote part of the land.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 - 26 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogre:</b>  <span style='padding: 0px 2px;'>Typically hibernating in a neaby cave, those that wander to close may end up as part of it's bone shrine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>27 - 29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Centaurs:</b>  <span style='padding: 0px 2px;'>A hunting party of 2 to 5 centuars may see the aprty as a threat and decide to attack.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 - 32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Soldiers:</b>  <span style='padding: 0px 2px;'>3 to 5 Soldiers, either deserters or udner orders, is threatening the local populance and any who enter the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 - 35 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Adventures:</b>  <span style='padding: 0px 2px;'>A groud of humans (ex: Bard, Mercenary, Theif, Cleric, Mage) is traveling through and may decide to test the party's mettle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>36 - 38 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Minotaur:</b>  <span style='padding: 0px 2px;'>A minotaur wanders the area with a hunger for battle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>39 - 41 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Gorgon:</b>  <span style='padding: 0px 2px;'>A gorgon lives in nearby cave and may attempt to lure nearby travelers to their doom.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>42 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Sphinx:</b>  <span style='padding: 0px 2px;'>The liar of the phinx is nearby, she will not attack unless provoked, but may vex the party in other ways.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>43 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Manticore:</b>  <span style='padding: 0px 2px;'>A deadly Manticore makes this part of the desert it's home and guards it at all costs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>44 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Chimera:</b>  <span style='padding: 0px 2px;'>A rare chimera stalks the hillside for prey.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cattle Canyon:</b>  <span style='padding: 0px 2px;'>Down a narrow canyon and roaring can be heard up ahead. A Stamped of Cattle and Minotaur come barreling down the canyon path.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Stone Sculptor:</b>  <span style='padding: 0px 2px;'>A man has been collecting beautiful stone statues statues, and wants to find the hermit sculptor, who lives in the hills. Find the Nearby Gorgon.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Mercenary Band:</b>  <span style='padding: 0px 2px;'>An elite mercenary band feels it was not paid what it was owed by a nearby town and is preparing to inact their revenge.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Chimeric Contagion:</b>  <span style='padding: 0px 2px;'>Some awful ancient magic has been unleashed and is combining men into minotaurs, wild animals into chimeras, and other unspeakable horrors.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='green4bg'>Coniferous <f10>Temperate, Severe</f10></RegionTitle><SectionContainer class='green4border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A forest often made of tall evergreen trees and typically in higher and mountainous areas.</SectionContainer><SectionContainer class='green4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Spring/Summer/Fall:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>1S:</sc> Cold 2. <sc>2S:</sc> Cold 3.
</div></div></SectionContainer><SectionContainer class='green4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green4bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Burned Forest</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Chared Trees, with new grass growing</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>Wild Fires</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Withering Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A Rot is taking most trees, logs are piling up </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rotten Forest</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Thich with some kind of fungus, the trees in this area seem to be dying, and have sweet and sickly smell to them.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Fungal Creatures</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Teped Pond</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Among dirt and sparse trees a small pond filled with dirty water is found in a valley between the surrounding hills.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dense Steep Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A thick Grove of trees climbs up the hill side, up and over boulders and rocks</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'>><b>Suggested:</b>Steep Hills: +1 Travel Fatigue, Cliff</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Cliffs</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Cliffs of rocks and the occasional tall tree which clings to the steep cliffside.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Misty Cliffs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dense fog covers the tree covered hillsides and little can be seen in any direction.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Mist</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Fern Bush</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The undergrowth is chocked with ferns, </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Thick Underbrush: +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dirty Stream</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A thin stream makes it's way through the roots of the tress forming muddy banks at the bottom of the hillside.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ancient Fell Tree</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A giant tree has fallen and seems to extend for leagues. It's emmense body forms many openings as well birdges across rock and ridges.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>White Water Rapids</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A river rushes through the rocks and crashes through the crevices of the mountains.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Moss Covered</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Boulders, trees, and everything is dripping in moss </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Fog</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Great Wood</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Trees are massive only pine needles yet live on the forest floor.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Old Wood</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The trees feel immeasurably old, moving and swaying slowly together, </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cliff Waterfall</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Waterfall tumbles over a cliff into a pool of large boulders.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliff, Dangerous Path</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grassy Pond</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A calm pond of mossy water is ringed by a vally of large trees.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dark Woods</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A thick patch of giant trees extend into the air, so thick they blot out the sun except for shining rays amongst the dirt and branches.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shaded Waterfall</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A waterfall hidden among the trees, logs of past trees can be found in the pool below </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'>><b>Suggested:</b> Rapids, Short Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Clear Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large Granit bowl, holds the melt of snow, trees on the far bank mirrored in the water.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'>><b>Suggested:</b> Steep Hills: +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Hillside Grove</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Tucked into a soft valley, soft grass and tall trees form a peaceful grove.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Meadow of Herbs</div></div>
        </div></div></div></SectionContainer><SectionContainer class='green4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green4bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer/Fall</div> Wildfires:</b>  <span style='padding: 0px 2px;'>A fire nearby has filled the area with smoke and ash. Resist 2 Fatigue w/ Endr. Visibility 2R.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hsil falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Thick Underbursh:</b>  <span style='padding: 0px 2px;'>Dense trees and foilage make travel in this area difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Rocky Terrain:</b>  <span style='padding: 0px 2px;'>Rock form crevices making travel more tiring and slow. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 15 : </span></b></div><div><b>  Dangerous Path:</b>  <span style='padding: 0px 2px;'>The path comes to a narrow passage around the cliffside. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge <fc>0S:</fc> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>16 - 18 : </span></b></div><div><b>  Wide River/Lake:</b>  <span style='padding: 0px 2px;'>A wide river can only be crossed by swimming or going a Travel Space around. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>19 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek cross through a rocky hillside with swift white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>20 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>A large river comes through the trees. Must go around $1S<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>22 : </span></b></div><div><b>  Falling Rocks:</b>  <span style='padding: 0px 2px;'>While moving among the cliffs, rocks slide down upon the party. Characters attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenge. <sc>2S:</sc> Avoid Rocks. <sc>1S:</sc> Take $1S<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> Take <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cliff Cavern:</b>  <span style='padding: 0px 2px;'>The rocky face gives way to a underground cavern.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Ravine:</b>  <span style='padding: 0px 2px;'>A rocky ravine with mossy logs fallen in leads deep underground.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Giant Tree Cavern:</b>  <span style='padding: 0px 2px;'>A tree is so large, that characters can climb inside it, with its inside forming a tower upward among it's branches and roots decending deep into the earth.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Waterfall Cave:</b>  <span style='padding: 0px 2px;'>Behind a rocky waterfull, a cave decends into the rocky wall. The inside is damp and only partially submerged.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Small Rock Cave:</b>  <span style='padding: 0px 2px;'>A small shallow hole in a cliff, provides shelter.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Man Turned to Tree:</b>  <span style='padding: 0px 2px;'>Corpse of a man turned to a tree, a strange empty bottle lays nearby along with damaged armor</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 - 9 : </span></b></div><div><b>  Gorgeous View:</b>  <span style='padding: 0px 2px;'>Clear view of the valley, and forest below, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 - 12 : </span></b></div><div><b>  Target Practice:</b>  <span style='padding: 0px 2px;'>Trees nearby have wooden targets nailed to them with Arrows, Med. Climbing challenge. Might be other weaposn nearby.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b>  Tree Cache:</b>  <span style='padding: 0px 2px;'>Seemingly forgotten, <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold as well as some cheap weapons and armor have been stashed into a hole inside a tree.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>14 : </span></b></div><div><b>  Meadow of Herbs:</b>  <span style='padding: 0px 2px;'>Hidden among the trees is a dense area of valuable herbs. Gain <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>15 : </span></b></div><div><b>  Druid Grave:</b>  <span style='padding: 0px 2px;'>A long dead druid has died and been absorbed into a large tree. Nearby are a Stamina Potion, a Healing Potion, and a Medicine.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Druid, with hut made of ferns and fungi</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Old Fisherman, sitting by a stream.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Wizard secluded in his wizard's tower</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Old Ent, standing watching the wood.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Lumberjacks, with mules, pulling wagon of lumber. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Traveler:</b>  <span style='padding: 0px 2px;'>Hunter, out searching for a buck</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Old Run down Stone Tower, old guard vetern keeping the signal ready</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Fortification:</b>  <span style='padding: 0px 2px;'>Bandit Tree hideout</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>Forest Elves, have built large network of treehouses</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>Old Lumbermill, small patch of stumps, with many trails leading deeper into the wood.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>Old Mine, humans piling up large piles of crushed rock outside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>Party of Dwarvn Traders, with wagons</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>Giant Wood logs being dragged to town by group of lumbers and domesticaed Giant Ground Sloths</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>4 to 6 hungry wolves decide the party is ripe for hunting. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> 1 Dire Wolf</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>2 or 3 bears consider this area their territory and will attack those who enter.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'><div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Bandit Leader</div> Bandits:</b>  <span style='padding: 0px 2px;'>Runaway outlaws (2 to 3 Bandits and 2 to 3 Bandit Archers) have made this place their home and prey on those caught anawares.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Forest Elves:</b>  <span style='padding: 0px 2px;'>A group of Forest Elves (2 to 4 Eleves and 2 to 3 Elf Rangers) consider this area forbidden to outsiders and may attack anyone passing through unless persuaded not to.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Harpies:</b>  <span style='padding: 0px 2px;'>3 to 6  Harpies roam the cliffs on this area, taking anyone they think weak enough back ot their nest ofr feeding.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'><div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hobgoblin, Orc</div> Goblins:</b>  <span style='padding: 0px 2px;'>4 to 8 Goblins have created a hovel from which they attack and rob anyone they find nearby.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>22 - 24 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Owl:</b>  <span style='padding: 0px 2px;'>A Dire Owl hunts in the area at night, and may even consider the party as food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>25 - 27 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dryad:</b>  <span style='padding: 0px 2px;'>A Dryad (perhaps 2 or 3) lives amongst the trees and, while sometimes peaceful, may decide to fool trick or attack the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>28 - 30 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Bear:</b>  <span style='padding: 0px 2px;'>A monsterous Dire Bear calls this area it's home and becomes enraged when approached.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>31 - 33 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Wolves:</b>  <span style='padding: 0px 2px;'>A Dire Wolve, howls and summons its pack. These giant hounds are a ferocious pretator. Will attack and stalk the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>34 - 36 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ent:</b>  <span style='padding: 0px 2px;'>A ground of 1 to 3 Ents consider this area normally forbidden to outsiders and will attack those who do not leave when asked.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>37 - 39 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogre:</b>  <span style='padding: 0px 2px;'>An ogre makes it's home in cave amongst the cliffs. Often sleeping, but occasionaly leaves to feed.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>40 - 42 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Ground Sloth:</b>  <span style='padding: 0px 2px;'>A family of 1 or 2 Giant Ground Slothes live in the area, and while mostly peaceful will attack anyone who attacks them.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>43 - 45 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Fungal Creatures:</b>  <span style='padding: 0px 2px;'>In a part of the forest infected by fngal growth, 2-6 Fungal Monsters attack anyone inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>46 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Amphithere:</b>  <span style='padding: 0px 2px;'>1 The Rare massive Amphithere can fly snaking around trees with realtive ease, any party should be careful when on its trail. Probably lives on cliffs and mountain tops. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>47 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Hill Giant:</b>  <span style='padding: 0px 2px;'>1 Large and dumb, a party would be wise not to mess with, prefers to boil the party alive before eating.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>48 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Roc:</b>  <span style='padding: 0px 2px;'>1 The Roc perches and nests on high rocky cliffs, its piercing screach can be heard for miles. It glides over the forest, before swooping through the trees at its prey. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>49 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ghosts:</b>  <span style='padding: 0px 2px;'>2-3 Ghosts heavy fog sets in and moans can be head. before shapes can be seen floating through the trees. </span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Forest of Wooden Men:</b>  <span style='padding: 0px 2px;'>A grove of Wooden trees all made from dead humans. Transformed by and evil presence or a druid gaurding thier land.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Bleeding Tree:</b>  <span style='padding: 0px 2px;'>The Oldest tree's sap is a dark red blood that is leaking from a knife and pooling around the tree.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Dryad's Call:</b>  <span style='padding: 0px 2px;'>A Dryad wants some destructive bandits who have moved into the area killed, and will offer a reward for those that help her.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Blood Forest Moon:</b>  <span style='padding: 0px 2px;'>A group of Dryads and Ents in this part of the forest practice a ritual in which they sacrifice a living creature to Ernok.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='yellow3bg'>Desert <f10>Arid</f10></RegionTitle><SectionContainer class='yellow3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A dry arid area with little plantlife.</SectionContainer><SectionContainer class='yellow3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> Heat 1 + Cold 1. <sc>2S:</sc> Heat 2 + Cold 1. <sc>3S:</sc> Heat 3 + Cold 1.
    <br>
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Heat 1 + Cold 1. <sc>1S:</sc> Heat 2 + Cold 1. <sc>2S:</sc> Heat 3 + Cold 1.
    <br>
    <b>Summer:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Heat 1 + Cold 1. <sc>1S:</sc> Heat 2 + Cold 1. <sc>2S:</sc> Heat 3 + Cold 1. <sc>3S:</sc> Heat 4 + Cold 1.
</div></div></SectionContainer><SectionContainer class='yellow3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Only available in Forage Bonus <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Salt Flats</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Flat ground, with crusty white earth.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dried Bones</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large pit of dired out bones is formed among the rocks. Nothing living is anywhere in sight.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Gravel Plains</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large flat land with nothing but small graveled pebbles..</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mirrage Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Not too far away the party sees what looks like a lake.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cresting Dune</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Sandy dunes, create large hills.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sandy plains</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Sand is blown into rippleing patterns, across and endless lanscape.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Red Dunes</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Waves of red sand roll endlessly into the horizon below the beating sun.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dried Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Small pools of tepid water can be found in the small pools which surround a vast lake of dried mud.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cracked Mud Plain</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Cracked mud packed with sand and dust.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Ridges</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The dirt horizon is broken up by small cliffs of rocks and gravel.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Mountain</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Rocks merge from the dusty landsacpe and climb upwards.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>Steep Hills: +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Red Rock Canyons</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Smooth red striped rock, canyons with bowls of trapped water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Rocky Area: +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shrugs and Cacti</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Short shrubs with a smatering of cacti.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sparse Trees</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A couple trees are formed here and stand out far into the falt horizon.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Small Stream</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A tiny stream makes its way down the hillside, barely a foot wide in some places.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dry River bed</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A wash, where water might have flown at some point in the past. small stagnit ponds remain</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cactus Field</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A field of cactii goes on for miles with little to no oher plantlife.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Oasis</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Some water comes though a collection of rocks with shrubberies ringing it on all sides.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Desert Bloom</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Through Cracks in the dried mud, flowers sping forth.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Small Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A small lake lies in a rocky valley, animals can be seen coming to drink in the water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='yellow3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer</div> Drought:</b>  <span style='padding: 0px 2px;'>All Forage Hunt Bonuses are reduced a Level (Ex: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> becomes <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.) Areas with water only offer <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Water instead.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Heatwave:</b>  <span style='padding: 0px 2px;'>It is even hotter than normal, with the sun beating down through a cloudless sky.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Dust Storm:</b>  <span style='padding: 0px 2px;'>
        Wind kicks up a hige clud of dust in the area making it difficult to see and breathe.
        <br> <b>+1 Travel Fatigue</b>, Characters attempt Sense Challenge: <sc>0S:</sc> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> if not in Shelter. <sc>2S:</sc> Find shelter from the Dust. 
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Burrial Mounds:</b>  <span style='padding: 0px 2px;'>Large earthen mounds, made by some intellegent creature, with a small sinking depression at the top.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Sand Trap:</b>  <span style='padding: 0px 2px;'>A large inverted cone of sand and dust, pull the party into a subterrian chamber.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Dried Lake Cave:</b>  <span style='padding: 0px 2px;'>Near a dried lake, a cave opens into the ground below. It seems their could be water inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Cactus Pass:</b>  <span style='padding: 0px 2px;'>A giant grove a cactii has grown together to form a passage through a narrow valley. It is unclear what made this.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Scavenging Vultures:</b>  <span style='padding: 0px 2px;'>Circling birds, have gathered around a carcus of a fallen knight.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Sandstone Cave:</b>  <span style='padding: 0px 2px;'>Wind has slowly carved a notch out of the rock big enought to lay down and escape the heat.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Red Cactus:</b>  <span style='padding: 0px 2px;'>A highe red and pick cactus is found. By picking it's fruit the party can gain 1 Water, 2 Trip, and 1 Medicine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Dead Camp:</b>  <span style='padding: 0px 2px;'>An abandoned camp can be found, and among them <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> water. Whatever killed them it seems it wasn't thirst.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>Druid with desert wear, wandering vast distance, and story about the night sky.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>A miliraty fort is here made te oresist incusions from Scorpian Men.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>A small village is built near a spring, and relies on passing trade for sustenance.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Scorpian:</b>  <span style='padding: 0px 2px;'>The party crosses too cloese to nest and 2 or 4 Large Scorpians attack the intruders.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Centuars:</b>  <span style='padding: 0px 2px;'>A group of 4 to 5 centuars is passing through and may offer trade or battle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Venemous Snake:</b>  <span style='padding: 0px 2px;'>Passing too close to a snake nest causes 2-5 Scnakes to attack the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Lizard Men:</b>  <span style='padding: 0px 2px;'>A hunting party of 3 to 5 lizardmen is stationed nearby and will attack the party if they look weak.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Giant Fire Ants:</b>  <span style='padding: 0px 2px;'>The party passes too close to a nearby hill of Fire Ants,which send 3 to 5 to dispatch them, and possibly more if they continue to advance toward them.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 - 24 : </span></b></div><div><b>  Scarab Sworm:</b>  <span style='padding: 0px 2px;'>A Scarab Sworm is making it's way through the area and the party gets caught up inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>25 - 28 : </span></b></div><div><b>  Scorpian Men:</b>  <span style='padding: 0px 2px;'>A warband of 2 to 4 Scorpian Men is walking through the desert and decide the party seems like easy prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 - 31 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Tortoise:</b>  <span style='padding: 0px 2px;'>A giant tortoise slowly makes it's way across the desert. It will likely leave the party alone unless attacked.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>32 - 34 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Minatuar:</b>  <span style='padding: 0px 2px;'>The Bull head man, short temper and all muscle. It's charge into a party can break even the most vetern teams.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>35 - 37 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Dung Beetle:</b>  <span style='padding: 0px 2px;'>A giant dung beetle has a nearby lair and attacks anyone who interrupts it's work.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>38 - 40 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Rock Troll:</b>  <span style='padding: 0px 2px;'>A rock troll sleeps among the nearby boulders, but will awake if it senses something it can eat.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>41 - 43 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Gila Monster:</b>  <span style='padding: 0px 2px;'>A giant Gila Monster emerges from the sand intent on making the party into dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>44 - 46 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Land Shark:</b>  <span style='padding: 0px 2px;'>A Land Shark traveling through the sand below may attack the party if the come too close.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>47 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Giant Scorpian:</b>  <span style='padding: 0px 2px;'>Getting too close to the liar of Giant Scorpian, it decides to feed the party to it's children (2 to 4 Large Scorpians).</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>48 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Sand Wurm:</b>  <span style='padding: 0px 2px;'>A giagnatic San Wurm comes through the sand. If not careful it will decend on the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>49 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Sphinx:</b>  <span style='padding: 0px 2px;'>The liar of the phinx is nearby, she will not attack unless provoked, but may vex the party in other ways.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>50 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Manticore:</b>  <span style='padding: 0px 2px;'>A deadly Manticore makes this part of the desert it's home and guards it at all costs.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Man Shapped Cacti:</b>  <span style='padding: 0px 2px;'>Twisted horror, frozen into cacti faces. Listen closely and hear there plight.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Ghost Mining Village:</b>  <span style='padding: 0px 2px;'>Deserted Village and all the mining equipement, looks like everyone disapeared yesterday.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Carved Obelisk:</b>  <span style='padding: 0px 2px;'>Standing alone, and Obelisk with acient writing depics and evil sealed.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  The Hill That Follows:</b>  <span style='padding: 0px 2px;'>Behind the party every day the wake up, they see the same hill a mile or so behind them. With a secret dungeon underneath.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Moonlight Oasis:</b>  <span style='padding: 0px 2px;'>At midnight, grass, and flowers sprout, streams and rivers begin to flow, Trees reach into the sky, and fireflies light the night. Follow the lush path ahead of you.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Riddle of the Sphinx:</b>  <span style='padding: 0px 2px;'>A nearby Sphinx will offer the party a valuable piece of information, but only if they can solve a dangerous riddle.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='green3bg'>Forest <f10>Lush, Severe</f10></RegionTitle><SectionContainer class='green3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A standard forest, typically in cool temperatures.</SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Spring/Summer/Fall:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
    <br>
    <b>Winter:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
</div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Charred Wood</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large ashen trees with black wood. New green sprouts are peeking through the burned ruined trees.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Fire</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dry Earthen Desolation</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A gap in the trees that nothing seems to be able to grow in, animals stay away.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Still Water Pool</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Rain runoff has collected in a dirty basen in a rocky part of the forest where few trees grow.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rotted Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Some kind of rot is killing the trees in the area, causing them to be weak and lined with damp and dark stains.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dark Tall Wood</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Very tall trees reach very high, choking out near all light from the forest floor.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Gloomy Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A chill at the forest floor sits there, creating a low fog, the canopy creates large dark shadows on the forest floor.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b><div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ghost</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Forest</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Trees grow around the many boulders that lay around the forest floor.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Wooded River Bank</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Tree roots held the banks firm as the water carved away the dirt leaving a ravine behind.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ravine</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dried Creek</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dry creakbed is full of rocks and weeds.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grassy Meadow</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass surrounded by forest. ground water sweeps up and keeps the grass lush.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Pond</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Pond, sided with tall grass and sunken logs</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Forest Stream</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>rocks and boulders breakup the stream, causing it to burble through the trees.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Damp moss</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Moss hanging like curtains over trees. small pools collect dripping water. </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mushroom Undergrowth</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dark shadow trees covered in a variety of plants and mushrooms, of all shapes and colors.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dense Underbrush</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dense bushes line the area along with several tall tress.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Heavy Underbrush</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Forest spring</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A glowing spring in the deep dark of the wood.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Trees, with carved Faces</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>These acient trees have faces carved into them, they feel differnet.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ent Corpse</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large tree emberging from a old dead ent.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ents</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A lake of a deep blue color creates a break in the trees.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Wide Lake</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Waterfall</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A stream falls through some rocks creating a small waterfall.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer/Fall</div> Wildfires:</b>  <span style='padding: 0px 2px;'>A fire nearby has filled the area with smoke and ash. Resist 2 Fatigue w/ Endr. Visibility 2R.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Heavy Underbrush:</b>  <span style='padding: 0px 2px;'>The ground has tough shrubbery making travel difficult. +1 Travel Fatigue.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Rooted Gnarls:</b>  <span style='padding: 0px 2px;'>Trees Choke the path, roots tangle and hop along the ground making walking difficult. +1 Travel Fatigue</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Boulder Field:</b>  <span style='padding: 0px 2px;'>Large Boulders, covered in moss and trees litter the landscape. +1 Travel Fatigue</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Wide/Calm River:</b>  <span style='padding: 0px 2px;'>A dark river cross the calmly trees. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek with quick moving white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Shallow Cliff (Up):</b>  <span style='padding: 0px 2px;'>Tree roots tangle up a rocky cliff. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Shallow Cliff (Down):</b>  <span style='padding: 0px 2px;'>Tree roots tangle up a rocky cliff. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cavernous Hole:</b>  <span style='padding: 0px 2px;'>A Large hole opened up in the world casting light and roots down into the deep dark depths.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Mossy Cave:</b>  <span style='padding: 0px 2px;'>Mossy and water drip down the entrance, creating a small muddy puddle, at the threshold.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Gargantuan Cavern:</b>  <span style='padding: 0px 2px;'>Large trees complete to obscure the Cavern entrance, High Rocky walls, with Numerous large boulders littering the inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Underground River Cave:</b>  <span style='padding: 0px 2px;'>Emerging from underground and river has cut a tunnel through the earth.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Grotto:</b>  <span style='padding: 0px 2px;'>A small creavous leading underground, it's a tight squeeze.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Root Hollow:</b>  <span style='padding: 0px 2px;'>Base of a tree slowly failing gravity's claim, a small earthen hollow wrapped in roots, and mossy lays.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Abandoned Shack:</b>  <span style='padding: 0px 2px;'>An old hunting shelter, long since lost and abandoned, roof and walls, falling in, a thick layer of dirt reclaiming what it can.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Small Mushrooms:</b>  <span style='padding: 0px 2px;'>Similar effect to trip.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Tree Stash:</b>  <span style='padding: 0px 2px;'>Hollowed out Tree stash, +5-10G.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Grand Old Tree:</b>  <span style='padding: 0px 2px;'>A giagnatic tree in the middle of the forest is such that it's bark provides 3 Spell Materials and gives all <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Moral and Inspiration.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Forest Meadow:</b>  <span style='padding: 0px 2px;'>A beatiful meadow of rare plants provides <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Medicine.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Forester Village:</b>  <span style='padding: 0px 2px;'>A village within the forest consisting mostly of loggers.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>A local hermit lives here and offers Healing Potions for a price.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Cabin in the woods:</b>  <span style='padding: 0px 2px;'>An old woman lives here, and offers players place to stay the night.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Merchant Caravan:</b>  <span style='padding: 0px 2px;'>A group of merchants pass. They have the wares of a Town General Store as well as 10 Food and 20 Water for sale.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Band of Forest Elves:</b>  <span style='padding: 0px 2px;'>Group of 2-4 Elfs and 1-2 Elf Rangers are encountered. The elves may be willing to trade, but are weary of humans.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Bandits:</b>  <span style='padding: 0px 2px;'>A group of Bandits Tents, supplies, camp fire. 2-4 Bandits, 1-3 Archers, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Bandit Leader</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Boars:</b>  <span style='padding: 0px 2px;'>Attacked by several angry boars. 3-7 Boars <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Dire Boar</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Goblin Camp:</b>  <span style='padding: 0px 2px;'>A group of Goblins using some trees as a hideout. 3-6 Goblins, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Goblin Mage, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Orc, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hobgoblin</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A group of wolves are in the area and are hunting the party. 3-6 Wolves, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Goblin Rider, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Direwolf, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Werewolf</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Bears attack a party. Will stand down if Players flea unless they are very hungry. 1-2 Bears, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Direbear</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 - 23 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Centaurs:</b>  <span style='padding: 0px 2px;'>Wanding hunting party. 1-3 Warriors, 1-3 Archers.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 - 26 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dryads:</b>  <span style='padding: 0px 2px;'>Dryads protect this part of the frest and may attack trespassers. 1-3 Dryads.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>27 - 29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giants Spiders:</b>  <span style='padding: 0px 2px;'>Spiders create ambush in caves and dense areas of the forest. 3-6 Giant Spiders, tend to Protect Treasure A.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 - 32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Forest Fairies:</b>  <span style='padding: 0px 2px;'>Fairies will cast Sleep (Resist 2 Sleep w/ Spirit) on Players and rob them of any gold and treasure they possess.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ents:</b>  <span style='padding: 0px 2px;'>Ents are mostly friendly but will exact revenge on anyone who tries to Chop Wood in the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>34 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ogres:</b>  <span style='padding: 0px 2px;'>Ogres may attack those who get too close to their cave.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>35 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Spriggan:</b>  <span style='padding: 0px 2px;'>This creaureguards this aprt of the forest with murderous intent.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>36 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Living Plants:</b>  <span style='padding: 0px 2px;'>This part of the forest is alive and will attack those who enter. Possessed Tree/Living Bramble Bush/Shambling Mound</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>37 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Fungal Bloom:</b>  <span style='padding: 0px 2px;'>This part of the forest is overrn with fungus and is comming alive. 1-4 Mushroom Men</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>38 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ghosts:</b>  <span style='padding: 0px 2px;'>A section of the forest is hanted with spirits. 1-3 Wraiths/Shades/Spirits</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Broken Tree Path:</b>  <span style='padding: 0px 2px;'>A line of pushed over and destroyed trees, something large has been through (suggest: Ogre, Giant, etc)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Fleeing Critters:</b>  <span style='padding: 0px 2px;'>The birds and woodland critters are running away from where the party is headed, (suggest: Ogre, Fire, Living Plants, Spiders)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Singing in the Air:</b>  <span style='padding: 0px 2px;'>A soft lovely voice be carried by the wind, (Suggestion: Elves, Fairies, Dryads, Ghosts)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Dead Adventurer:</b>  <span style='padding: 0px 2px;'>The journal of a dead adventure speaks of a jewel he means to bring his family in a nearby Town. It is worn around his neck.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='blue3bg'>Ice Field <f10>Severe</f10></RegionTitle><SectionContainer class='blue3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>An area consisting of massive ice shelves, often with fissures. Extremely dangerous.</SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>    
    <b>Summer:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>1S:</sc> Cold 2. <sc>3S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 2. <sc>1S:</sc> Cold 3.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 2. <sc>1S:</sc> Cold 3. <sc>2S:</sc> Cold 4.
</div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in only Forage Bonus on <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen Ice Spikes</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Jaged Icy Spikes reach upwards, small narrow paths cut through.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ice Penitentes</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Flat Icey walls, line up into large standing plates, creating a near maze of paths.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frackured Ice</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Disjointed Ice pedestals, small to large gaps that you need to hop between. </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ravines</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ice Shelf</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Unstable cliff of ice</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliff</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen Shards</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Small chuncks of broken ice are piled across the land like a field of small shards of glassy ice.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The lansdcape forms a giant frozen basin among a deep and thickly frozen lake deep under the ice.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Pink Pools</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A strange and thick pink algae has ovetaken the mostly still water in the cratered pools among the rocky hillsides.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Glacial Overhangs</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A glacier has been seemingly slowly carved out, causing it to form wide tunnels and overhangs with the rocky cliffs.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue-Green Glacier</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Partially submerged in snow, crystalline glaciers shining various shades of blue and green can be seen all acorss the landscape.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocks and Ice</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills are covered in half jagged dark rocks and half smooth white ice creating a patchy horizon.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Slush Marsh </b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A muddy, snowy ice crusted flat land, small muddy ponds dot the area.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Glacial Runoff</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A giant glacier rests across the elevated hills, but below it small trickles of fresh glacial runoff begin to from a frigid stream.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dead Trees</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Some long dead and frozen trees can be found pushing up through the ice and snow.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen WaterFall</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Cold hard rocks hold up a frozen waterfall system.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'>Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grassy Patch</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Small tufts of grass are found among a rocky field among the ice.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Freezing River</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The shores of the river are building ice, small chunks are being pulled downstream.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>River</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cool Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A small and almost clear lake covers the area, allowing some small growth of plants around it.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue Ice Caves</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large cavern of Ice, form blue walls, and dripping icy columns.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lush Valley</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Trapped within an Icey bowl, a lush humid garden grows. Follow a short icey cave into the valley, Large ice spikes can be seen overhead.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>Warmer Climate.</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Thermal Pool</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A deep underwater rift has created a comparitively heated pool where wild life thrives.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Hot Springs</div></div>
        </div></div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter/Fall</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hail falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Blizzard:</b>  <span style='padding: 0px 2px;'>A terrible onslaught of sleet and snow pounds the area. <b>Wet</b>, <b>+2 Cold Exposure</b>, <b>+1 Travel Fatigue</b>,<b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b></span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Rocky Area:</b>  <span style='padding: 0px 2px;'>The way is difficult to cross and the path is partialy blocked. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Deep Snow:</b>  <span style='padding: 0px 2px;'>Deep snow makes travel especially difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Dangerous Path:</b>  <span style='padding: 0px 2px;'>The path comes to a narrow passage around the cliffside. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge <fc>0S:</fc> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 - 10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Frozen River:</b>  <span style='padding: 0px 2px;'>A Frozen river may be crossed, but may break. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Cross River:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> (2 times) <cs>2S:</cs> Cross fine. <cs>1S:</cs> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet) <cs>0S:</cs> Resist 4 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Ice Carved Fortress:</b>  <span style='padding: 0px 2px;'>A Ice Sculture of massive porportions, someone must have been defending something here.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Rock Cave:</b>  <span style='padding: 0px 2px;'>Entrance to the cave has large icicles dripping over and snow is trying to push its way in.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Icy Borehole:</b>  <span style='padding: 0px 2px;'>Something has seemingly drilled or merely broken a jagged unnel straight down into the ice.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Crystal Caves:</b>  <span style='padding: 0px 2px;'>Seemingly made if icy crystals, a seemingly endless series of caves and catacombs spirals ever deeper into the ice.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Green Sprout:</b>  <span style='padding: 0px 2px;'>A sole plant is thriving, in the ice, a rare Herb.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Hot Springs:</b>  <span style='padding: 0px 2px;'>Coming from some volcanic shaft deep below, the water here is actually warm, and a nearby cave even somewhat heated. +2 Warming Dice.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 - 10 : </span></b></div><div><b>  Frozen Outpost:</b>  <span style='padding: 0px 2px;'>It's unknown why they were here, or how long ago they died, but the skeletal remains hint they died at each others throats. They have left behind Rusty Weapons and Armor as well as 3 Medicine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Fresh Camp:</b>  <span style='padding: 0px 2px;'>The people who manned this camp have died not too long ago. They leave behind <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold and 1 Food. (Though the meat of the frozen campers seems like it could be 12 Food all on it's own.)</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Off-Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>Small group of igos, of nomadic hunters.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>Crazed Lunitic, who fled/exiled to the wastes, to aton for thier crimes.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>The cold and bitter soldiers, though really a penal colony, were sent here to guard from something, though very few have any idea what.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>A small whaling village is formed here by people with little contact with the outside world.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 5 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A party of 2 to 5 wolves will follow and hunt the party for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 - 10 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Getting to close to it's cave will cause the bear to attack to protect its home and even bring home it's dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 - 15 : </span></b></div><div><b>  Dire Penguin:</b>  <span style='padding: 0px 2px;'>A trive of dire penguins protect this part of the ice as a nesting ground.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>16 - 18 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Yeti:</b>  <span style='padding: 0px 2px;'>A dangerous Yeti makes this part of the mountain it's home and is very terriorial.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>19 - 21 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Roc:</b>  <span style='padding: 0px 2px;'>A huge Roc occaisonlly can be seen hunting in this area, flying far overhead and swooping down on it's prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>22 - 24 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Mammoth:</b>  <span style='padding: 0px 2px;'>A heard of 3 to 6 mammoths are crossign this path, and will attack the party if angered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>25 - 27 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Skeletons:</b>  <span style='padding: 0px 2px;'>Animated by some long past magic, these 3 to 6 skeletons are cursed to protect the secrets of the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>28 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Mountain Giant:</b>  <span style='padding: 0px 2px;'>Living far from society in the vallys between the highest mountains, the mountain giant sleeps.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ice Dragon:</b>  <span style='padding: 0px 2px;'>Very little known and even rarer seen, Ice Dragons can occaisonally be found in the deepest reaches of the ice.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Giant Skeletons:</b>  <span style='padding: 0px 2px;'>Large Frozen Skeletons Lay across the land. Within an cyrstal ice skull devels a hidden dungeon.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Old North Spirits:</b>  <span style='padding: 0px 2px;'>At night, blue glowing eyes can be seen above the treeline. A thick ice fog distorts and blurs the lights. Colourful lights dance between floating ice crystals. You feel like you are being watched. Old echos call out from the fog.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Belly of the Frozen Kraken:</b>  <span style='padding: 0px 2px;'>Legend has it a teasure ship travelling from the far east was swallowed whole by a giant kraken, and that kraken was then frozen while hibernating in an icy slumber in the far reaches of the ice.
        Traveling intos it's frozen maw to claim the treasures of the ship may be ludicrously profitable, or just plain ludicrous.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  The Icy Damned:</b>  <span style='padding: 0px 2px;'>Somehow a long frozen army of the undead has awakened, and is marching from the icy wastelands into the green lands.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='turqouise4bg'>Jungle <f10>Lush</f10></RegionTitle><SectionContainer class='turqouise4border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>An area of very dense trees and plantlife, often warm and humid.</SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Winter/Fall/Spring:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Heat 1.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Summer:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Heat 1. <sc>2S:</sc> Heat 2. <sc>3S:</sc> Heat 3.
</div></div></SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='turqouise4bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dense Underbrush</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The Ferns and leafy plants are 10ft tall and choke many of the paths forward</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested: +1 Travel Fatigue/ Barrier: Dense Foliage</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mangrove Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Tree roots and vines branching out like spiders legs, create a maze of waterways and forested tunnels. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested: +2 Travel Fatigue</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Cliffs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A series of rocky cliffs break the layers of jungle canopy and tear across the land.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Shallow Cliff</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Volcanic Crevice</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Crevices of earth tear the land and small rivers of lava creep down from the ashen mountain above.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Deep Forest</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Layers and layers of leaves and branches arch above. Leaving the bottom choked with roots and darkness</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested: Visibility 1R, +1 Travel Fatigue</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Giant Vines</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Long Rope Vines weave through the trees dripping down and around everything.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested: +1 Travel Fatigue</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flooded Jungle</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Water from elsewhere has flooded into this jungle valley causing several feat of water and has drowned many of the local plants.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Pools</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Puddles of vines and mud lie under a tall jungle camopy.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lush Canopy</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The thick canopy overhead casts a deep shodow on the forest floor and is filled with animals at all levels.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>White River</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Down a rocky pass, some white rapids rush into the jungle floor.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Rapids</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Moss Drenched</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Moss covers and drenches every surface. Drips and due rain down contantly</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy River</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large river, so dirty and muddy it conceals all that swim under its surface.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Barrier: River</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Webbed Forest</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Gaint Spider webs cover the jungle, dew drops form on the webs, Wonder what else can be found on the webs.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Spider Encounter </div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Volcanic Hot Springs</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>On the side of a volcanic mound sulfiric bubbling volcanic warm hot springs can be found, steams flow down the mountain, and rotten egg smell can be smelled a bit off. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Morale </div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Crystal Blue Pools</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Inside a rocky valley a lake of shining blue water glitters in the sun.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Vine Maze</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The vines of the local trees from a tangled maze and curve high into the air and down again.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Hidden Waterfall</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A cliff shelters a small waterfall and pond. Water pours around many rocks and plants to create many small falls.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sunken Jungle</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The jungle floor has been flooded with 10-20 feet of clear water, large tropical fish swimming through vines and roots</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Cenote</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A pool of water, at the bottom of a shallow cave. The water hides a submerged cave system.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Morale</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Deep Glow Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The Sky is only plants. Large mushrooms, glowing spores, and fungus, old vines, and roots decend form above. Dark water running underfoot.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Morale</div></div>
        </div></div></div></SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='turqouise4bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Summer/Fall</div> Wildfires:</b>  <span style='padding: 0px 2px;'>A fire nearby has filled the area with smoke and ash. Resist 2 Fatigue w/ Endr. Visibility 2R.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Flooding:</b>  <span style='padding: 0px 2px;'>Area is covered in water. <b>Wet</b>. 
    <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>2S:</cs> Find Shelter and must spend next <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Days waiting out Flood.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>1S or Less:</cs> Characters not Sheltered get Washed down 1 World Space and Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> and Resist 2 Impact Wound w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 5 : </span></b></div><div><b>  Leeches:</b>  <span style='padding: 0px 2px;'>Leeches attempt to stick to the party to suck their blood. <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> <cs>OS or Less:</cs> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 - 10 : </span></b></div><div><b>  Mosquitos:</b>  <span style='padding: 0px 2px;'>Blood sucking misquitos spread disease throughout the jungle. Resist 1 Illness w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 - 13 : </span></b></div><div><b>  Giant Mosquitos:</b>  <span style='padding: 0px 2px;'>A larger type of mosquitos with particulalry dangerous diseases. Resist 2 Illness w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>14 - 18 : </span></b></div><div><b>  Thick Underbursh:</b>  <span style='padding: 0px 2px;'>Dense trees and foilage make travel in this area difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>19 - 22 : </span></b></div><div><b>  Quicksand:</b>  <span style='padding: 0px 2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge. Any who fail are trapped in Quicksand. 
    	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Escape Quicksand:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge. Any who can reach can help and add <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>.
    		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <sc>0S:</sc> Sink Deeper. If this happens three times the Character fails.
    		 <sc>1S/2S:</sc> No Effect.
    		 <sc>3S:</sc> Escape 
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 - 25 : </span></b></div><div><b>  Wide River/Lake:</b>  <span style='padding: 0px 2px;'>A wide river can only be crossed by swimming or going a Travel Space around. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>26 : </span></b></div><div><b>  Dangerous Path:</b>  <span style='padding: 0px 2px;'>The path comes to a narrow passage around the cliffside. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge <fc>0S:</fc> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>27 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek cross through a rocky hillside with swift white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>28 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>A large river comes through the trees. Must go around $1S<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 : </span></b></div><div><b>  Falling Rocks:</b>  <span style='padding: 0px 2px;'>While moving among the cliffs, rocks slide down upon the party. Characters attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenge. <sc>2S:</sc> Avoid Rocks. <sc>1S:</sc> Take $1S<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> Take <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>31 : </span></b></div><div><b>  Dense Foilage:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Machete to Pass. If so Becomes Travel Difficulty 3 per Space.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>32 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Deep Forest:</b>  <span style='padding: 0px 2px;'>Walls of wood and vines, the deep forest may be the real forest floor, but feels more like a living cave.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Cenote:</b>  <span style='padding: 0px 2px;'>A clear underwater cave. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Jungle Cave:</b>  <span style='padding: 0px 2px;'>A mossy cave lined with vines and insects cuts deep into the rocky face of a mountain.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Ant Hill:</b>  <span style='padding: 0px 2px;'>A giant ant colony seem to go forever, digging deep into the jungle floor. Some areas are big enough to walk through single file, but others must be crawled.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Rare heart fruit:</b>  <span style='padding: 0px 2px;'>Said that eating from the fruit can help cure wounds, and disease.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Small Mushrooms:</b>  <span style='padding: 0px 2px;'>Similar effect to trip.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 11 : </span></b></div><div><b>  Fermented jungle Fruit:</b>  <span style='padding: 0px 2px;'>Similar effect to Wine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Valuable Flowers:</b>  <span style='padding: 0px 2px;'>A spot where particualrly rare flowers is found which van be used for medicinal purposes. Gain <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Medicine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b>  Abandoned Camp:</b>  <span style='padding: 0px 2px;'>Several members of the camp lay long dead throughout the torn tents and bags. Gain <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold, 1 Machete, 6 Arrows, and 3 Ale.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>A shaman lives in the deep forest and may heal those who ask for a price.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>A young man, lives in the trees in a tree house.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Outpost:</b>  <span style='padding: 0px 2px;'>A research otpost has been established to study the jungle as well as promote trade.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>The Secret village of the Forest elves, high up in the canopy, with many waterfalls.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Frogs:</b>  <span style='padding: 0px 2px;'>A group of 3 to 4 Poison Frogs and a Dire Frog attack ap arty too close to their watering nest.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Corpse Flower:</b>  <span style='padding: 0px 2px;'>2 to 3 Corpse Flowers have bloomed over the remains of recently dead travel party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Basalisks:</b>  <span style='padding: 0px 2px;'>3 o 4 Minro Basalisks tak the party for food. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Major Basalisk</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Vipers:</b>  <span style='padding: 0px 2px;'>2 to 3 Vipers decide to bit the party as warning to stay away.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Monkeys:</b>  <span style='padding: 0px 2px;'>2 to 5 Chimps and a Gorilla callthis section of the forest their home and guard it jealosly.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Spiders:</b>  <span style='padding: 0px 2px;'>A colony of 2 to 5 Spiders and 2 to 4 Giant Spiders considers this their home and will eat those who wnader into the nest.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>22 - 25 : </span></b></div><div><b>  Hippos:</b>  <span style='padding: 0px 2px;'>The local waterign hole is home to 2 to 3 dangerous and angry hippos.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>26 - 29 : </span></b></div><div><b>  Giant Ants:</b>  <span style='padding: 0px 2px;'>A swarm of 3 to 6 giant ants has decided to take the party back to it's layer for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 - 32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Anaconda:</b>  <span style='padding: 0px 2px;'>A giant anaconda will attempt to pull any who get to cose to its nest into into it's jaws.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 - 35 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Lizardmen:</b>  <span style='padding: 0px 2px;'>A band of lizardmen will attempt to capture the party for their slave markets.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>36 - 38 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Naga:</b>  <span style='padding: 0px 2px;'>These snake people will have 3 to 5 guards planted at any entrance to their subterrain palaces.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>39 - 41 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Venus Fly Trap:</b>  <span style='padding: 0px 2px;'>This part of the forest is home to a giant Venus Fly Trap that eats those who enter.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>42 - 44 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Shambling Mound:</b>  <span style='padding: 0px 2px;'>Animated forest membrane seemingly made from vines and leaf detritus attacks any near.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>45 - 47 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Centipede:</b>  <span style='padding: 0px 2px;'>A giant centipede is passing through the vines and the forest when it decides to take the party as a meal.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>48 - 50 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Cat:</b>  <span style='padding: 0px 2px;'>1 to 3 jungle cats ambush the party when they are in a weak position.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>51 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ancient Spider:</b>  <span style='padding: 0px 2px;'>In the deepest section of the forest an Ancient Spider makes it home and feed on all who enter.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>52 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Hydra:</b>  <span style='padding: 0px 2px;'>The rare and deadly hydra leaves deep in the dark jungle and is always hungry.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Swallowing Jungle:</b>  <span style='padding: 0px 2px;'>The jungle's roots and vines move and morph to drag the party down into the jungle deeps, a land of living wood caves.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Flat Topped Trees:</b>  <span style='padding: 0px 2px;'>No tree grows over 50ft high, all the branchs and leaves, seem to push up against an invisible ceiling creating a world above the treess cut off from life below. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Grand Central Tree:</b>  <span style='padding: 0px 2px;'>The Sentient Heart of the forest, guides the players too it. IOts connect to all life in the jungle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Black Ooze:</b>  <span style='padding: 0px 2px;'>A black sticky ooze, is slowly covering every living thing in this part of the forest. Weakening some, driving others mad. The jungle creatures are no longer the same.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Reptile War:</b>  <span style='padding: 0px 2px;'>A new local Dragonborn King of the Lizardmen is rising up against the Naga Empress and both sides are sacking human settlements and using them as frontline fodder for their bloody wars.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Rot Blood:</b>  <span style='padding: 0px 2px;'>A disease called Rot Blood spread my mosquitos turns those it bites in Zombies and Ghouls after 3 days of wretching and vomitin. It can also spread through blood and into water suppilies.
        Local leaders have decided to get help to masscare the quarentined populations and burn out the infected parts of the forest.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='green2bg'>Pastoral <f10>Temperate, Severe</f10></RegionTitle><SectionContainer class='green2border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>Cool area with long fields and some trees.</SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Fall/Summer/Spring:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> None. <sc>2S:</sc> Cold 1.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
</div></div></SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green2bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Boulder Wastes</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Boulders small cliffs and hills topped with long coarse grass.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Barrows</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Few plants grow among the fields of earth barrows, likely dug as ancient mass graves.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Cliffs</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The green horizon is broken by cliffs and rocky plateaus.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Short Cliffs</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Abandoned Quarry</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Abandoned quarry lines the area, with deep dusty hollow pits cut into the earth.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sheep Fields</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Green grassy fields with bunches of sheep. 2 Large dogs can be seen watching over the folk.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Holy Fields </b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass as been littered with mounds of dirt from unseen burrowers</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ruins</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Long past ruins of ancient walls and buildings line an otherwise empty plain.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Ponds</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Water has pooled between the hills into a collection of ponds with muddy water and muddier embankments.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sheer Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Steep hills rise from the earth, breaking up the green of the horizon.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Brook</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Water flows though a rocky brook among small vallys in the hills.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Fields of Leaves</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Trees in the area have shed leaves all along the he grassy meadows.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shaded Grove</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Breaking up the green grassy fields is a small dark forest. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Brushy Gully</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dense with a thicket of bramble, a small streem can be reached </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to get water. </div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mossy Spring</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The moss gross and creeps over boulders a trees, a small trickle of water can be hear nearby.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Ancient Worn Wall</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A cobble stone wall covered in grass and moss barely chest high.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Pristine Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A cool and calm blue lake spreads into the horizon and glints in the sun.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Wide Lake</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>River Valley</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A wide and slow river works its way through a valley in the grassy hills.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> River</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flower Bloom Fields</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b>Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills are alive with flowers, song birds singing. sweet smell in the air</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Fairy Pools</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b>Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Crystal clear pools, with short wide falls dribbling water.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Secret Gardens</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Secluded in nature, a garden with many different strange plants grow.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='green2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green2bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter/Fall</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hail falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Flooding:</b>  <span style='padding: 0px 2px;'>Area is covered in water. <b>Wet</b>. 
    <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>2S:</cs> Find Shelter and must spend next <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Days waiting out Flood.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>1S or Less:</cs> Characters not Sheltered get Washed down 1 World Space and Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> and Resist 2 Impact Wound w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Thick Underbursh:</b>  <span style='padding: 0px 2px;'>Dense trees and foilage make travel in this area difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Rocky Area:</b>  <span style='padding: 0px 2px;'>The way is difficult to cross and the path is partialy blocked. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Stoney Castle:</b>  <span style='padding: 0px 2px;'>Old forgotten castle</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Dilapidated Fort:</b>  <span style='padding: 0px 2px;'>An fort thats been overgrown and taken over by new residents</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Dirt Burrow:</b>  <span style='padding: 0px 2px;'>A creature burrowed this out and it leads underground.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Mineshaft:</b>  <span style='padding: 0px 2px;'>A mine in the hills creates a dark and stony cavern cutting deep into the rocky interior.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Well:</b>  <span style='padding: 0px 2px;'>Inside a well is an underground river that flows through into the earth.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Fairy Ring:</b>  <span style='padding: 0px 2px;'>Ring of mushrooms, restores the parties stamina.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Archer Feild:</b>  <span style='padding: 0px 2px;'>Wood targets with scattered arrows nearby.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 11 : </span></b></div><div><b>  Old Battle Field:</b>  <span style='padding: 0px 2px;'>Can find bad quality weapons in the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Idyllic Meadow:</b>  <span style='padding: 0px 2px;'>A beautiful meadow gives water, <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs, as well as <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale and Inspiration to those who find it.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b>  Abadonded Holfast:</b>  <span style='padding: 0px 2px;'>No longer in use, the remains of an old holdfast hold <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold and <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>Druid of the wood, old and wise, doesnt like company of otehrs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Old Sell sword, with a missing eye.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Wood and stone fort</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>An old mage lives in a cottage in the hills and sells scrolls and teach magic to those deemed worthy of his time.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>A caravan on it's way to the city sells all kinds of wares, including weapons and armor.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>One of many farming villages found all over he area.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Bandits:</b>  <span style='padding: 0px 2px;'>A gang of bandits, 1 to 3 Bandits and 1 to 3 Bandit Archers, try to extract tolls from hapless travelers. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Bandit Leader</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A party of 2 to 5 wolves will follow and hunt the party for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Getting to close to it's cave will cause the bear to attack to protect its home and even bring home it's dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Goblins:</b>  <span style='padding: 0px 2px;'>A group of 3 to 7 Goblins has taken residense here and like to rob and eat those weak enough for them to catch. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Goblin Rider, Hobgoblin, Goblin Shaman, Orc.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 20 : </span></b></div><div><b>  Giant Rats:</b>  <span style='padding: 0px 2px;'>An infestation of 3 to 7 Giant Rats threatens travelrs who come near.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>21 - 23 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Slime:</b>  <span style='padding: 0px 2px;'>1 or 2 slimes make a home in a remote part of the land.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 - 26 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogre:</b>  <span style='padding: 0px 2px;'>Typically hibernating in a neaby cave, those that wander to close may end up as part of it's bone shrine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>27 - 29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Centaurs:</b>  <span style='padding: 0px 2px;'>A hunting party of 2 to 5 centuars may see the aprty as a threat and decide to attack.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 - 32 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Soldiers:</b>  <span style='padding: 0px 2px;'>3 to 5 Soldiers, either deserters or udner orders, is threatening the local populance and any who enter the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>33 - 35 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Adventures:</b>  <span style='padding: 0px 2px;'>A groud of humans (ex: Bard, Mercenary, Theif, Cleric, Mage) is traveling through and may decide to test the party's mettle.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>36 - 38 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Wasps:</b>  <span style='padding: 0px 2px;'>A nearby nest of 3 to 7 Giant Wasps creates a hazard to anyone nearby.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>39 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Hippogriff:</b>  <span style='padding: 0px 2px;'>Far away from civilization, a Hippogriff amkes it's home in a prestine meadow.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>40 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Ghost:</b>  <span style='padding: 0px 2px;'>A collectiosn of ghost type monsters haunts an abdoned village and any wo come near.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>41 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Cockatrice:</b>  <span style='padding: 0px 2px;'>A cockatrice stalks these lands, and sees those not carfl as potential prey.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>42 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Kelpie:</b>  <span style='padding: 0px 2px;'>A kelpie lives in a deep pond nearby and occasionlly emerges to hunt for food.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cursed Church:</b>  <span style='padding: 0px 2px;'>A holy ground, made unholy, the towns folk have been twisted. Mutliated victims, disapearances and conspiracy hide shadows of a forbidden cult.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Singing childern in the fog:</b>  <span style='padding: 0px 2px;'>A low deep fog setts in from time to time, childen of the village disapear for a few days. follow the hums and singing to hind out where they go.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  The Beast:</b>  <span style='padding: 0px 2px;'>A creature comes at night and kills those from the local villages. Some claim it's a Direwolf, others a Lycanthrope. There is a reqard for any who can end the killings.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  War:</b>  <span style='padding: 0px 2px;'>An invading army is burning the fields and killing the villagers. Those sent to defend the land are hardly better. Even if they don't take a side, the party can find themselves caught in-between.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='yellow2bg'>Plains <f10>Arid, Temperate</f10></RegionTitle><SectionContainer class='yellow2border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>Area of sparse woodlands along with grass and shrubs.</SectionContainer><SectionContainer class='yellow2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Fall/Spring/Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> No Exposure. <sc>1S:</sc> Heat 1. <sc>2S:</sc> Heat 2. 
    <div style='height:1px;'></div>
    <b>Summer:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S/1S:</sc> Heat 1. <sc>2S:</sc> Heat 2. <sc>3S:</sc> Heat 3.
    <div style='height:1px;'></div>
    <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> No Exposure. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2. 
</div></div></SectionContainer><SectionContainer class='yellow2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow2bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rolling Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>slow rounded hills, curve over the landscape, dusted with dirt and grass.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dusty Plains</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Once grassy feilds, now lay endless dirt and dust, rare to even find a large rock.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Dust Storm</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Plains</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A long stretch of muddy hills and pits seem to go on for miles.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dirt Plains</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A flat expanse of dirt with small and sparse patched of grass goes on for miles.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Bone Field</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A valley of bones and rocks where many anials came to die.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Grass</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Green grass land, small sharp rocky cliffs and boulders break up the blankets of green. A small mossy spring,  trickles down part of a rocky cliff.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Short Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lone Oak</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Soft grassy hills, with a lone Okay tree atop a large hill</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Geyser</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The plains are broken by a small pool and geyser. Many birds make this palce their home.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sparse Fields</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large patches of dense grass are broken up by rocks, hills, and dirt.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Granite Pillars</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Granite Stones reach for the sky, popping out of green grassy feilds.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dense Grass</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dense files of grass go on as far as the eye can see.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Winding River</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A winding river walks it's way through the hill side rocks and grass.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Rapids</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Ponds</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Swallow Ponds surrounded by tall brush, the earth squishes underneath, the ponds all but disapear in the summer.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>Muddy Ground: +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grown Over battlefeild</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass has all but hidden the war, rusted weapons and earthen bodies are strewn about.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Shrubbery Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hills covered in dense shrubs and other plants roll into the horizon.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue-Green Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large blue green lake covers the horizon. Many animals come to drink the cool water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Wide Lake</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lush Grassland</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dense grass covers the rolling hillsides. Animals can be heard moving through it.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flower Fields</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Sprinled through the green grass are bright purples, whites and yellows of new sprouting flowers</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Rich Grasses</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Wandering River</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A cool, deep river slips through the grassy hills. The current can be quiet quick.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> River barrier</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Babbling Creeks</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Small creeks move through the grass, coupled with a a few trees</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='yellow2border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='yellow2bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Spring/Winter/Fall</div> Lightning Storm:</b>  <span style='padding: 0px 2px;'>
        The sky is filled with rain and clouds. Thunder and lightining periodically crash down.
        <br> <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Each Shift: <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>4S:</sc> Lightning starts fire nearby. <sc>5S:</sc> Random Character outside takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Dust Storm:</b>  <span style='padding: 0px 2px;'>
        Wind kicks up a hige clud of dust in the area making it difficult to see and breathe.
        <br> <b>+1 Travel Fatigue</b>, Characters attempt Sense Challenge: <sc>0S:</sc> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> if not in Shelter. <sc>2S:</sc> Find shelter from the Dust. 
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Tornado:</b>  <span style='padding: 0px 2px;'>
        A swirl of wind and dust creates a tornado powerful enough to lift large rocks and animals alike. 
        <br> <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b> 
        <br> Characters attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenge: <sc>2S:</sc> Avoid Tornado. <sc>1S or Less:</sc> Must outrun Tornado.
        <br> Outrun Tornado: 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge <sc>0S:</sc> Get pulled into Tornado. Impact: <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wounds. <sc>1S:</sc> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge to reduce Impact: <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound from debris.

    </span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Muddy Ground:</b>  <span style='padding: 0px 2px;'>The ground is covered in thick mud, making travel difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 - 10 : </span></b></div><div><b>  Wide River/Lake:</b>  <span style='padding: 0px 2px;'>A wide river can only be crossed by swimming or going a Travel Space around. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek cross through a rocky hillside with swift white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>Must go around $1S<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Small Earthen crack:</b>  <span style='padding: 0px 2px;'>The earth seemingly opened up in this spot revealing whats below</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Burrow:</b>  <span style='padding: 0px 2px;'>A Med sized creature has been digging, a large amount of piled dirt sits outside the burrow.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Sink Hole:</b>  <span style='padding: 0px 2px;'>A circlur hole jutting down.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Muddy Cave:</b>  <span style='padding: 0px 2px;'>Rocks and mudd form a half collapsed cave. The ground is rough and uncertain and little light enters.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Bone Structure:</b>  <span style='padding: 0px 2px;'>A structure mostly made of bones and rocks is built around a rocky cave. It feels very old.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Old Campsite:</b>  <span style='padding: 0px 2px;'>Firepit with wood, if searching around can find some arrows, and old knife</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Fake Rock:</b>  <span style='padding: 0px 2px;'>Large rock can be opened up and gold found inside. Stick around and bandits might show up.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Rich Grasses:</b>  <span style='padding: 0px 2px;'>A patch of earth has vibrant plantlife containing some rare herbs. Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Abandoned Kill:</b>  <span style='padding: 0px 2px;'>A creature has died recently but the hunter never claimed his kill for some reason. Gain 7 Raw Meat.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>An old practitioner of shamanistic practices lives in the fileds far from civilization.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Group of 4 Adventures, heavy wounded, one missing a leg, another missing a hand. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Hunter and son, out searching for game for a few days.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>3 Dwarves pulling a wagon full of rocks</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Soldiers riding horses, protecting the land</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Farming Family, with everything they own and 1 sickly horse looking worse for wear.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Fancy Carriage with 2 Good Horses, 4 heavily armed gaurds, escort a noble of high standing</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Highway Bandits have created a "Toll road"</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Kings Soldiers, defending the road established a "Toll"</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Fortification:</b>  <span style='padding: 0px 2px;'>Bandits Hidden Hideout</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Village:</b>  <span style='padding: 0px 2px;'>A small collection of huts is built around a watering hole. Some pasture animals wander the outskirts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b>  Outpost:</b>  <span style='padding: 0px 2px;'>A small fort is dug into the earth, with various soldiers patrolling the nearby area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Caravan:</b>  <span style='padding: 0px 2px;'>2 Mechants, 3 Gaurds, and 3 horse loaded up.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Hell Pig:</b>  <span style='padding: 0px 2px;'>A pack of 3 to 7 Hell Pig salks the party, hoping ofr a meal.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Giant Cat:</b>  <span style='padding: 0px 2px;'>1 to 3 Giant Cats stalk the area, and may find the party a source of food if they are not careful.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Gnolls:</b>  <span style='padding: 0px 2px;'>A band of 3 to 6 Gnolls moves throuhg this area, robbing and killing anyone to weak to stop them</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 16 : </span></b></div><div><b>  Dire Elephants:</b>  <span style='padding: 0px 2px;'>1 Massive Dire Elephant, likes to keep its distance, but if the party gets close will charge them down.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 19 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Lizardmen:</b>  <span style='padding: 0px 2px;'>A hunting party of 2 to 5 Lizardmen stalks through the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>20 - 22 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Terror Bird:</b>  <span style='padding: 0px 2px;'>This area is hunting ground for a ground of 2-6 Terror Birds which chase their quary across the plains.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 - 25 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Rhino:</b>  <span style='padding: 0px 2px;'>1-2 Dire Rhinos like to silently grass, butt will charge if provoked.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>26 - 28 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Chimera:</b>  <span style='padding: 0px 2px;'>1 best not lock eyes with one, will hunt the party down, for a meal or sport.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Cyclops:</b>  <span style='padding: 0px 2px;'>A cyclops has a cave in the area which he occasionaly leaves to hunt on anyone unlucky enough to be nearby.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Drake:</b>  <span style='padding: 0px 2px;'>A nest of 2-4 Drakes has been made on the cliffs nearby, and they may hunt the party for food if seen.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>31 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Skeletons:</b>  <span style='padding: 0px 2px;'>A slaughtered village has cursed the men who attacked it, who now hold a barren fort as undead guardians.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='yellow2bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Traveler's Scream:</b>  <span style='padding: 0px 2px;'>Traveler is under attack by bandits.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Localized Storm:</b>  <span style='padding: 0px 2px;'>On the horrizon the party spots dark clouds that seem to stay unmoving above a certain point. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Slave Trade:</b>  <span style='padding: 0px 2px;'>Party encounters a group of slaves being carted off by some guards</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Burning Village:</b>  <span style='padding: 0px 2px;'>A village is being ravaged by a band gnolls, possible uner orders from a local warlord.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Hunting Party:</b>  <span style='padding: 0px 2px;'>A nearby settlement has decided to hunt a nearby Dire Elephant, hoping it's tusks will being good fortune. They are willing to pay those who wish to come along for the fight.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='blue3bg'>Tundra <f10>Severe</f10></RegionTitle><SectionContainer class='blue3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A barren area found in very cold climates.</SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>    
    <b>Summer:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>1S:</sc> Cold 2. <sc>3S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Fall/Spring:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>1S:</sc> Cold 2. <sc>2S:</sc> Cold 3. <sc>3S:</sc> Cold 4.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 2. <sc>1S:</sc> Cold 3.
</div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in only Forage Bonus <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lichen Fields</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Crusts of Lichen cover the ground, softening up the hard boulders.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen Earth</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The Ground remains hard and cold near year round, plants have trouble growing.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dirt Snow</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The snowy ground is a slushy mess of dirt mud and snow.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Tidal Salt Marsh</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Shallow Salty water fills, in a large flat sandy grass clumped plain.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Frozen Mud</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A shallow muddy lanke has completely frozen over, creating a brown white sprawlin every direction.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Endless Snow</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Nothing can be seen in any direction other than endless fields of barren snow.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Snow and Stones</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>head sized stones cover a snowy landscape</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Bare Granite Plains</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Granite rocks with little to no grass or dirt</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sinkhole</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large crater like depression has fallen through into the murky groundwater below.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Snowy Hills</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Steep rocky hills snake through the tundra, all covered in thin layers of snow.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Shallow Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Icy Grass</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A mixture of white snow and thin brown grass covers the area into the distance.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>White Horizon</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Thin blankets of snow go on into the distance as far as the eye can see, only oocasionly broken by small rocky hills.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flower Gravel</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large Gravel feilds, willed with sharp rocks, flowers pushing through the harsh gravel. </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Green Mossy Sponge</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Mossy ground can get up to 2 feet thick making the ground feild like a large soft springy bed.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Recovery</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Thin Trees</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Patches of tall thin tress eek out an existense among the rocky hillsides.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grassy Ponds</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Cold Marshy shallow ponds, break up large grassy feilds. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rock Fields</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Large rocks and small sections of grass and shrubs strecth into the horizon.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Glacial Tongue</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large block of ice crawing out of the mountains, rests easy on the plains.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Icey Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Icy Islands float around the lake. </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b></div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Pristine Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A crystal clear lake covers the rocks and is surrounded by trees and shrubbery.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 21. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Red-Green Fields</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills roll into the horizon shifting between various shades of red, gold, and green.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='blue3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='blue3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter/Fall</div> Hail Storm:</b>  <span style='padding: 0px 2px;'>Hail falls through the trees and pelts the groudn below. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b>, Impact: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound if not sheltered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Blizzard:</b>  <span style='padding: 0px 2px;'>A terrible onslaught of sleet and snow pounds the area. <b>Wet</b>, <b>+2 Cold Exposure</b>, <b>+1 Travel Fatigue</b>,<b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b></span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 3 : </span></b></div><div><b>  Rocky Area:</b>  <span style='padding: 0px 2px;'>The way is difficult to cross and the path is partialy blocked. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 - 6 : </span></b></div><div><b>  Steep Hills:</b>  <span style='padding: 0px 2px;'>The hills ahead are rocky and steep, and slow down travel. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 - 9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Path</div> Shallow Cliff:</b>  <span style='padding: 0px 2px;'>A rocky hillside requires characters to either go around or climb. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b>  Cliff:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires 100’ of Rope and Climbing Gear to Pass. Resist 1-3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Frozen River:</b>  <span style='padding: 0px 2px;'>A Frozen river may be crossed, but may break. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Cross River:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> (2 times) <cs>2S:</cs> Cross fine. <cs>1S:</cs> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet) <cs>0S:</cs> Resist 4 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Snowed in Cave.:</b>  <span style='padding: 0px 2px;'>Snow has mostly covered and slipped into the entrance of this cave. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Ice Ravine:</b>  <span style='padding: 0px 2px;'>A large crack in the ice opens to unknown depths.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Crater:</b>  <span style='padding: 0px 2px;'>At the bottom of a giant crater a tunnel leads straight down into the darkness.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Ice Water Cave:</b>  <span style='padding: 0px 2px;'>A partially frozen water source flows from an icy and partially submerged cave.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Overlook:</b>  <span style='padding: 0px 2px;'>Look over a large untamed land, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> morale.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Dead Camp:</b>  <span style='padding: 0px 2px;'>Though they died of hunger, they've left behind <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold, 6 Arrows, and some rusty weapons and armor.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 - 10 : </span></b></div><div><b>  Hot Spring:</b>  <span style='padding: 0px 2px;'>Hidden away and partially underground this provides +2 Warming Dice and Water.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b>  Fairy Circle:</b>  <span style='padding: 0px 2px;'>Ring of green Herbs.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Lone Tower overlooking the large plains, staffed by just a couple of gaurds.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Off-Road</div> Traveler:</b>  <span style='padding: 0px 2px;'>Bundled up traveler, not much in the way of words.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Village:</b>  <span style='padding: 0px 2px;'>Scraping by from pelts and other local resources this village survives in this difficult land.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>The rulers of the land have set an outpost here to watch, though what they are watching for is shrouded in mystery.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 5 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A party of 2 to 5 wolves will follow and hunt the party for food.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 - 10 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Getting to close to it's cave will cause the bear to attack to protect its home and even bring home it's dinner.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 - 13 : </span></b></div><div><b>  Wraiths:</b>  <span style='padding: 0px 2px;'>3 to 5 Ghosts stalk this area, intent on draining the life from the living.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>14 - 16 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Yeti:</b>  <span style='padding: 0px 2px;'>A dangerous Yeti makes this part of the mountain it's home and is very terriorial.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>17 - 19 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Mammoth:</b>  <span style='padding: 0px 2px;'>A heard of 3 to 6 mammoths are crossign this path, and will attack the party if angered.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>20 - 22 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogre:</b>  <span style='padding: 0px 2px;'>Typically hibernating in a neaby cave, those that wander to close may end up as part of it's bone shrine.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 - 25 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Rhino:</b>  <span style='padding: 0px 2px;'>A herd of 2 to 4 Dire Rhinos consider this area their terriorty and will attack any who enter.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>26 - 28 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Skeletons:</b>  <span style='padding: 0px 2px;'>Animated by some long past magic, these 3 to 6 skeletons are cursed to protect the secrets of the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>29 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Mountain Giant:</b>  <span style='padding: 0px 2px;'>Living far from society in the vallys between the highest mountains, the mountain giant sleeps.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>30 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Lich:</b>  <span style='padding: 0px 2px;'>From an age long forgotten, a lich mkes it's liar here far from civilizations, but may see the party as an opportunity for experimentation.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='blue3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Black Ice:</b>  <span style='padding: 0px 2px;'>Ice the color of Ink. Its more than just cold. Its sucks the heat out of anything nearby. Harsh winds blow towards the ice. If you follow the winds far enough the Black Ice Castle can be found.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Unthawed Monsters:</b>  <span style='padding: 0px 2px;'>Large frozen monsters trapped within icewalls, frozen for eons, but one has broken free...</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Polaris:</b>  <span style='padding: 0px 2px;'>North at night, and uncaany light shines down, staring at the star as you fall asleep lowers a bewitching astral staircase into the sky.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Ice Palace:</b>  <span style='padding: 0px 2px;'>Never in the same spot for more than a week. An elaborate frozen building with a welcoming assortment of buttles, and maids. Its owner likes too keep distant.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Aura's Eye:</b>  <span style='padding: 0px 2px;'>At night a large Aura spans the heavens, some say its the gods dancing, But for those young and all alone, the dancing lights never stop. Thiers eyes become clouded over with a mirror of the aura living on. 
        Those afflicted become deaf and mute. Only staring up. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Giant's Lament:</b>  <span style='padding: 0px 2px;'>A mountain giant has been chained in a deep cave. He must be freed in order to gain access to the enchanted secrets below, but he will attempt to kill any who free him.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Lich Fields:</b>  <span style='padding: 0px 2px;'>Far away from civilization, a Lich has been performing experiments with undeath, creating a menagerie of nightmares in the area.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='turqouise4bg'>Wetlands <f10>Temperate, Lush</f10></RegionTitle><SectionContainer class='turqouise4border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A colder flooded area of trees and shallow water.</SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Summer/Fall/Spring:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2.
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> None. <sc>1S:</sc> Cold 1. <sc>2S:</sc> Cold 2. <sc>3S:</sc> Cold 3.
</div></div></SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='turqouise4bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> Available in all Spaces.</div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dead Tree Meadow</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>In a sunken dry lake, old dead trees still stand.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sunken Battle Grounds</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Diry Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Decaying Corpses persvered in the muck and shallow water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Dry Swamp</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>An area with the water dried out, most eveything here is dead or dying and the ground is thick runny mud.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rotten Pools</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Dead trees and a strange smelling moss cover the mostly submerged area.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Flooded Marsh</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass, knee high water and mud</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b>+2 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Mudded Forest</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Spare wooded Forest, soaked with soft mud and grass.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Bubbling Mud pots</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A fowl gas burps up among the water and mud. </span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Damp Rocks</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Covered with a due, the area is mostly rocks among the tall grass of the local fauna.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Tree Swamp</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Several trees grow directly out of the swampy water along with patched of moss and algae.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Grasland</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Grass with soft earth. </span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Land of Ponds</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager/Disgusting/Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The flat grass fields are dotted with hundreds of ponds</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Red Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A lake is covered in a thick layer of red algae which seems to go deep below the surface.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Fallen Trees</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A creaky and old part of the land is marked by fallen trees with hollow insides.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Wet Reeds</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Tall thin reads cover the wet and partiall submerged ground.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lily Pad Wetlands</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Gaint Sturdy Lily pads, you can jump between, with lotus flowers.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Root tangle waterways</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A forest of trees, roots, and vines. create narrow tunnels and passageways</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Muddy Geyser</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A fowl eruption of gas, bursts water and mud into the air.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue-Green Lake</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large lake shunes blue and green in the light and is surrounded by thick trees and rocky shores.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Lush Trees</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A collection of new fersh trees has grown from the fertile soil in the area.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>River Valley</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Disgusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Between some deep green hills and wide river genetly comes down the hillsides.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Wide RIver</div></div>
        </div></div></div></SectionContainer><SectionContainer class='turqouise4border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='turqouise4bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 - 10 : </span></b></div><div><b>  Drizzling Rain:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 - 13 : </span></b></div><div><b>  Fog:</b>  <span style='padding: 0px 2px;'>A dense fog appears amongst the trees and hills. <b>Visibility 1R (Day)</b> and <b>Visibility 1 (Night)</b> </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>14 : </span></b></div><div><b>  Storm:</b>  <span style='padding: 0px 2px;'>A wet drizzle makes starting a fire impossible. <b>Wet</b>, <b>+1 Cold Exposure</b>, <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>15 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Flooding:</b>  <span style='padding: 0px 2px;'>Area is covered in water. <b>Wet</b>. 
    <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>2S:</cs> Find Shelter and must spend next <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Days waiting out Flood.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>1S or Less:</cs> Characters not Sheltered get Washed down 1 World Space and Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> and Resist 2 Impact Wound w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Leeches:</b>  <span style='padding: 0px 2px;'>Leeches attempt to stick to the party to suck their blood. <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> <cs>OS or Less:</cs> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Mosquitos:</b>  <span style='padding: 0px 2px;'>Blood sucking misquitos spread disease throughout the jungle. Resist 1 Illness w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Giant Mosquitos:</b>  <span style='padding: 0px 2px;'>A larger type of mosquitos with particulalry dangerous diseases. Resist 2 Illness w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 - 12 : </span></b></div><div><b>  Muddy Ground:</b>  <span style='padding: 0px 2px;'>This area has a lot of sinking ground, making it hard to move. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 15 : </span></b></div><div><b>  Thick Underbursh:</b>  <span style='padding: 0px 2px;'>Dense trees and foilage make travel in this area difficult. <b>+1 Travel Fatigue</b></span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>16 - 18 : </span></b></div><div><b>  Quicksand:</b>  <span style='padding: 0px 2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge. Any who fail are trapped in Quicksand. 
    	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Escape Quicksand:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge. Any who can reach can help and add <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>.
    		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <sc>0S:</sc> Sink Deeper. If this happens three times the Character fails.
    		 <sc>1S/2S:</sc> No Effect.
    		 <sc>3S:</sc> Escape 
    </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>19 - 22 : </span></b></div><div><b>  Dense Foilage:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Machete to Pass. If so Becomes Travel Difficulty 3 per Space.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>23 : </span></b></div><div><b>  Wide River/Lake:</b>  <span style='padding: 0px 2px;'>A wide river can only be crossed by swimming or going a Travel Space around. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 : </span></b></div><div><b>  Large River:</b>  <span style='padding: 0px 2px;'>Must go around <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces. Requires Water Vessel to Pass. Resist 1-3 Fatigue per Space (See Water Vessel).</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Old Rot Tree:</b>  <span style='padding: 0px 2px;'>A large Split in a tree, leading deep within.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Whirlpool:</b>  <span style='padding: 0px 2px;'>A swirling vortex of water and mud pulls creatures down into subterrain caverns.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Flooded Mineshaft:</b>  <span style='padding: 0px 2px;'>What once was a prosperous mine is now been flooded by a diverged river, the inside is dark and mostly subbmerged.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Muddy Sinkhole:</b>  <span style='padding: 0px 2px;'>A wet and earthen sinkhole has opened into the ground revealing a vast and damp cavern.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Mushroom of Dreams:</b>  <span style='padding: 0px 2px;'>A crop of mushrooms and other plants can be found, with similar effects to Trip/ Fizzyn.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 7 : </span></b></div><div><b>  Abandon Tree Camp:</b>  <span style='padding: 0px 2px;'>Shelter in the trees from the wet ground.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Overgrown Outpost:</b>  <span style='padding: 0px 2px;'>The building here has been reclaimed by the wilderness and is covered in vies, but offers rusted weapons and <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Flooded Flower Meadow:</b>  <span style='padding: 0px 2px;'>Many rare and valuable plants are growing out of the shallow water here. Includes <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Medicine, <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Sleet, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fizzyn, and <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Herbs.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Village:</b>  <span style='padding: 0px 2px;'>A small village is built on stilts above the damp ground. Row boats are the primary means of getting around.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Fortification:</b>  <span style='padding: 0px 2px;'>Mud Brick walls, and wooden spikes</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Outpost:</b>  <span style='padding: 0px 2px;'>A nearly overgrown outpost is maintiained here to try to keep tabs on the area and local travel.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off-Road</div> Hermit:</b>  <span style='padding: 0px 2px;'>A master of druidic magic lives here, and may be persuaded to heal the party for a price.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 - 4 : </span></b></div><div><b>  Frogs:</b>  <span style='padding: 0px 2px;'>A group of 3 to 4 Poison Frogs and a Dire Frog attack ap arty too close to their watering nest.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 - 8 : </span></b></div><div><b>  Basalisks:</b>  <span style='padding: 0px 2px;'>3 o 4 Minro Basalisks tak the party for food. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Major Basalisk</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 - 12 : </span></b></div><div><b>  Vipers:</b>  <span style='padding: 0px 2px;'>2 to 3 Vipers decide to bit the party as warning to stay away.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>13 - 15 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Spiders:</b>  <span style='padding: 0px 2px;'>A colony of 2 to 5 Spiders and 2 to 4 Giant Spiders considers this their home and will eat those who wnader into the nest.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>16 - 19 : </span></b></div><div><b>  Crocadiles:</b>  <span style='padding: 0px 2px;'>Several crocadiles lurk under the shallow water of this area, ready to eat travelers.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>20 - 23 : </span></b></div><div><b>  Giant Leeches:</b>  <span style='padding: 0px 2px;'>This area contains giant leechs that will attack the party who gets too close.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>24 - 27 : </span></b></div><div><b>  Oozes and Slimes:</b>  <span style='padding: 0px 2px;'>Living oozes and slimes emerge from the muck ot feed on the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>28 - 31 : </span></b></div><div><b>  Zombies:</b>  <span style='padding: 0px 2px;'>Some dark magic has animated some dead travelers into zombies and wraithes who attackanyone nearby. <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Tar-Zombie</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>32 - 34 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Anaconda:</b>  <span style='padding: 0px 2px;'>A giant anaconda will attempt to pull any who get to cose to its nest into into it's jaws.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>35 - 37 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Lizardmen:</b>  <span style='padding: 0px 2px;'>A band of lizardmen will attempt to capture the party for their slave markets.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>38 - 40 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Naga:</b>  <span style='padding: 0px 2px;'>These snake people will have 3 to 5 guards planted at any entrance to their subterrain palaces.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>41 - 43 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Dire Crocadile:</b>  <span style='padding: 0px 2px;'>A giant dire crocadile calls the local lake his home and is always hungry.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>44 - 46 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Giant Ooze:</b>  <span style='padding: 0px 2px;'>A giant ooze has congealed in this area and attempts to trap any who enter inside it.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>47 - 49 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Wisps:</b>  <span style='padding: 0px 2px;'>This area is home to wisps which will attempt to control the party and inact violent deeds.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>50 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Hydra:</b>  <span style='padding: 0px 2px;'>The rare and deadly hydra leaves deep in the dark jungle and is always hungry.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>51 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Draco-Lich:</b>  <span style='padding: 0px 2px;'>An ancient undead dragon has lived here since times long forgotten. Those who pass nearby can feel it's dark and evil energy in their bones.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='turqouise4bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Flames of the Swamp:</b>  <span style='padding: 0px 2px;'>At night large flashes can be seen deep in the wood. Flaming eruptions and pillars, surround a small area, where blacken ruins stand. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Chanting Wood:</b>  <span style='padding: 0px 2px;'> Chanting echos and distorts through the trees, gas taking forms of hooded men, then fading, lines of moving flames march into the wood, at dusk a large group of hooded figures chant a summoning ritual. </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Land of Flesh:</b>  <span style='padding: 0px 2px;'>The Soft Muddy ground becomes warm, squishing out a reddish black ooze, coils of warm soft slimmy something replace the undergrowth, trees become masses of pulsing muscle and tentrils, Giant eyes and mouths float on the surface.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  The Mist:</b>  <span style='padding: 0px 2px;'>A low dense fog seems to move around the area as if alive. Wherever it decends, those caught in it have intense visions and can possibly lose their minds. And sometimes things can be seen moving within it.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Slime Spawn Season:</b>  <span style='padding: 0px 2px;'>Every 30 years, slimes enter a spawnning season, causing the area to fill with slimes and oozes of all kind, including giant acid slimes, which can devour entire towns.</span> </div></div></div></div><div></div></SectionContainer></RegionPage></div>    <div style='font-weight:700; margin:10px 5px 5px 5px; color:white; font-size:25px;'>Specific Regions</div>
    <div style='display:grid; grid-gap:10px; grid-auto-flow:rows;'><RegionPage style='background:white; color:black;'><RegionTitle class='green3bg'>Giant's Glen </RegionTitle><SectionContainer class='green3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>A secluded area in Eastern Ersonia where it is said giants still roam the lands, though they are rarely seen.</SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'>
    <b>Spring/Summer/Fall:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>2S:</sc> Cold 2. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Winter:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Cold 1. <sc>2S:</sc> Cold 2. <sc>3S:</sc> Cold 3.
</div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> </div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills create craggy gaps that make travel difficult.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sparse Woods</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Several thin trees line the flat plain.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Boulders</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Strangely shaped boulder are strewn about the grass, though seemingly few other rocks are in sight.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 4. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Still Pond</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dip in the hills creates mools of brackish water.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 5. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Trenches</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Dirty Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Several rocky trenches seem torn into the earth. A few have small pools of water.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 6. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Giant Bones</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A patch of dirty hills contains very old giant bones jutting out of the earth.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 7. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Caves</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills become steep rocky mountains which seem lines with caves.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Ogre Cave</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 8. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Cliffs</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills become rock cliffs jutting into the sky.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliffs</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 9. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Vally</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Meager:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A deep crag seperate the land, requiring a difficult climb to get through..</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Cliffs</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 10. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Sparse Stream</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A small stream comes through some rocks hiddden in the hills.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 11. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rolling Hills</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hills of seemingly endless grass roll up and down.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 12. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rocky Crevices</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The hills are intersprersed with rocky boulders.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 13. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Hill Stream</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A small stream makes it ways through the hills.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 14. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Endless Hills</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>Hills go on as far as the eye can see.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 15. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Grassy Ruins</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>The ruins of an old village are buried in the grass.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 16. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rushing River</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A large river breaks through the rocky hills.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> River Rapids</div></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 17. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Calm Meadow</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Mystery</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A calming meadow is nestled between two large hills and contains a clear pond.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 18. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Giant Mound</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Meager</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A dead giant has formed a hill, with plants growing out of his body.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 19. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b>Blue Lake</b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>A huge and deep blue lake is cast into the hills, some forming islands across it.</span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> Lake</div></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 20. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b>Rock Waterfall</b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'><div style='display:inline; background: lightblue; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Water</div> <div style='display:inline; font-size:7px;'><b>Forage/Hunt:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Rummage:</b> Digusting</div> </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'>From the rocky hills and cliffs water falls into a deep pool.</span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'><div style='display:inline; font-size:7px;'><b>Suggested:</b> +1 Travel Fatigue</div></div>
        </div></div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Heavy Wind:</b>  <span style='padding: 0px 2px;'>Winds shake the trees causing leaves to blow about violently for <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Drizzle:</b>  <span style='padding: 0px 2px;'>Light rain causes the ground to be damp and the air to be filled with water for <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Dense Fog:</b>  <span style='padding: 0px 2px;'>Visibility 1R (Day) and Visibility 1 (Night) for <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts. +1 Dangerous.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Rainstorm:</b>  <span style='padding: 0px 2px;'>A pouring rain has begun. +1 Rain Exposure for next <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Fall/Winter/Spring</div> Light Snowfall:</b>  <span style='padding: 0px 2px;'>Snow if falling, sounds become soft and muted.  +1 Cold Exposure for next <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Winter</div> Heavy Snowfall:</b>  <span style='padding: 0px 2px;'>Heavy snows fall covering the grond and trees. +2 Cold Exposure for next <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Boulder Field:</b>  <span style='padding: 0px 2px;'>Large Boulders, covered in moss and trees litter the landscape. +1 Travel Fatigue</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road/Path</div> Slippery Trail:</b>  <span style='padding: 0px 2px;'>Area is particularly difficult to Travel. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge (Failure: <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Wound to random limb.)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Wide/Calm River:</b>  <span style='padding: 0px 2px;'>A dark river cross the calmly trees. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> River Rapids:</b>  <span style='padding: 0px 2px;'>A creek with quick moving white water. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jump across boulders:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> (2 times) <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)  <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Frozen River:</b>  <span style='padding: 0px 2px;'>A Frozen river may be crossed, but may break. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cross River:  <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> (2 times) <sc>2S:</sc> No Effect. <sc>1S:</sc> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet)  <fc>0S:</fc>  Resist 4 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Wet)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Shallow Cliff (Up):</b>  <span style='padding: 0px 2px;'>Tree roots tangle up a rocky cliff. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> +1 Fatigue	<sc>1S:</sc> +1 Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +2 Fatigue. +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Very Rough</div> Shallow Cliff (Down):</b>  <span style='padding: 0px 2px;'>Tree roots tangle up a rocky cliff. 
        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <sc>2S:</sc> No Effect.	<sc>1S:</sc> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound. <fc>0S:</fc> +1 Fatigue. +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Wound.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Barrier</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Rushing River:</b>  <span style='padding: 0px 2px;'>Dangerous river rushes through the hills for <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> in two directions.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Steep Cliff:</b>  <span style='padding: 0px 2px;'>Rock wall with roots, and vines for <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> in two directions.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Rocky Crag:</b>  <span style='padding: 0px 2px;'>20-50ft of sharp, rocky face for <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> in two directions.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cavernous Hole:</b>  <span style='padding: 0px 2px;'>A Large hole opened up in the world casting light and roots down into the deep dark depths.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Mossy Cave:</b>  <span style='padding: 0px 2px;'>Mossy and water drip down the entrance, creating a small muddy puddle, at the threshold.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Gargantuan Cavern:</b>  <span style='padding: 0px 2px;'>Large trees complete to obscure the Cavern entrance, High Rocky walls, with Numerous large boulders littering the inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Underground River Cave:</b>  <span style='padding: 0px 2px;'>Emerging from underground and river has cut a tunnel through the earth.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Abandoned Shack:</b>  <span style='padding: 0px 2px;'>An old hunting shelter, long since lost and abandoned, roof and walls, falling in, a thick layer of dirt reclaiming what it can.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Bone Cave:</b>  <span style='padding: 0px 2px;'>A cave deep into the rock is lined with huge bones of many creatures large and small.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Boon</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Dead Campers:</b>  <span style='padding: 0px 2px;'>Several campers have died there leaving behind their possessions. Treasure B, Treasure C, and Treasure E x2.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Cool Spring:</b>  <span style='padding: 0px 2px;'>A refreshing spring grants <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale when drinking from it for the first time.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Abandoned Camp:</b>  <span style='padding: 0px 2px;'>A camp had been mysterouly abandonded. Treasure C x3</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Inhabitants</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Village:</b>  <span style='padding: 0px 2px;'>A village within among the hills. The people here are very tall and strong, and claim to have giant's blood.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Hermit:</b>  <span style='padding: 0px 2px;'>A local hermit lives here and offers Healing Potions for a price.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Road</div> Merchant Caravan:</b>  <span style='padding: 0px 2px;'>A group of merchants pass. They have the wares of a Town General Store as well as 10 Food and 20 Water for sale.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Bandits:</b>  <span style='padding: 0px 2px;'>A group of Bandits Tents, supplies, camp fire. 2-4 Bandits, 1-3 Archers, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Bandit Leader</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Boars:</b>  <span style='padding: 0px 2px;'>Attacked by several angry boars. 3-7 Boars <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Dire Boar</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Goblin Camp:</b>  <span style='padding: 0px 2px;'>A group of Goblins using some trees as a hideout. 3-6 Goblins, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Goblin Mage, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Orc, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hobgoblin</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A group of wolves are in the area and are hunting the party. 3-6 Wolves, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Direwolf, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Werewolf</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>Bears attack a party. Will stand down if Players flea unless they are very hungry. 1-2 Bears, <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Direbear</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Ogres:</b>  <span style='padding: 0px 2px;'>Ogres may attack those who get too close to their cave.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Harpys:</b>  <span style='padding: 0px 2px;'>2-5 Harpays may hnt n the natura vallys formed by the hills and cliffs.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Hill Giant:</b>  <span style='padding: 0px 2px;'>A roaming and hubgry Hill Giant. They can be avoided if careful</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Griffin Nest:</b>  <span style='padding: 0px 2px;'>Small trees and rocks have been piled into a bird like nest. Up to 3 Griffins may be here and looking to hunt.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>10 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Uncommon</div> Barbarians:</b>  <span style='padding: 0px 2px;'>A group of Skellvar pirates is looking for food on the mainland. As likely to just rob instead of fight.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>11 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Mountain Giant:</b>  <span style='padding: 0px 2px;'>Mountain Giants rarely leave their hidden caves and are extreamly dangerous. They can sometimes be reasoned with.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>12 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Rare</div> Roc:</b>  <span style='padding: 0px 2px;'>The nest of huge Roc. Those captured would be fed to the creature's young.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  A Booming Cry:</b>  <span style='padding: 0px 2px;'>The cry of a huge creature can be heard in the distance. It sounds both distressed and incredibly dangerous. (Suggest: Ogre, Giant, etc)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Dead Adventurer:</b>  <span style='padding: 0px 2px;'>The journal of a dead adventure speaks of a jewel he means to bring his family in a nearby Town. It is worn around his neck.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Skelvar Help:</b>  <span style='padding: 0px 2px;'>Skelvar barbarians are looking to recruit help to deal with a problem in their homeland. The job is dangerous, but the rewards may be plentiful.</span> </div></div></div></div><div></div></SectionContainer></RegionPage><RegionPage style='background:white; color:black;'><RegionTitle class='green3bg'>Erson Plains <f10>Meadowlands</f10></RegionTitle><SectionContainer class='green3border' style='font-size:10px; grid-column:1/-1; padding:1px 4px 1px 4px;'>
    A series of sprawling fields in central Ersonia.
    The area is filled with farms, town, and villages, but also includes untamed areas where bandits, goblins, and other monsters can be found.
</SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Temperature</div><div style='padding:1px 2px 1px 2px; font-size:9px;'></div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>Scenery</SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:1fr;'><div class='' style='font-size:9px; background:lightgrey; padding:1px;'><b>Grass (Horse Feed):</b> </div><div style='padding:0px 0px 1px 0px; font-size:9px;'><div style='display:grid; grid-gap:2px 0px; grid-template-columns:auto auto auto 1fr 120px;'>
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 1. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b></b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'>  </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'></span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:lightgrey; border-radius:0px; padding:1px 3px 0px 3px;'><b> 2. </b></div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><b></b></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 4px 0px 0px;'>  </div>
            <div style='background:lightgrey; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'></span></div> 
            <div style='background:lightgrey; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        
            <div style='display:flex; background:white; border-radius:0px; padding:1px 3px 0px 3px;'><b> 3. </b></div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><b></b></div> 
            <div style='background:white; border-radius:0px; padding:1px 4px 0px 0px;'>  </div>
            <div style='background:white; border-radius:0px; padding:1px 3px 0px 0px;'><span style='padding: 0px 2px;'></span></div> 
            <div style='background:white; border-radius:0px; padding:1px 0px 0px 0px;'></div>
        </div></div></div></SectionContainer><SectionContainer class='green3border' style='grid-column:1/-1; display:grid; grid-gap:2px;'><SectionTitle class='green3bg' style='font-size:14px;'>
                    Events
                    <span style='font-size:9px;'>&nbsp;&nbsp; 1-8 None,&nbsp;&nbsp; 9-10: Weather,&nbsp;&nbsp; 11-12: Obstacle,&nbsp;&nbsp; 13: Interior/Entrance,&nbsp;&nbsp;
                    14-15: Boon,&nbsp;&nbsp; 16-17: Inhabitants,&nbsp;&nbsp; 18-19: Encounters,&nbsp;&nbsp; 20: Hooks</span>
                </SectionTitle><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px; flex-direction:column;'>
                            <div>Weather</div>
                            <div style='font-size:7px; display:inline-block;'>
                                <div>
                                    Daily Progression (d6)
                                    <br>1/2: End Event
                                    <br>3: Less Severe
                                    <br>4/5: No Change
                                    <br>6: More Severe
                                </div>
                            </div>
                        </div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Rainstorm:</b>  <span style='padding: 0px 2px;'>A pouring rain has begun. +1 Rain Exposure for next <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Dense Fog:</b>  <span style='padding: 0px 2px;'>Visibility 1R (Day) and Visibility 1 (Night) for <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Shifts. +1 Travel Fatigue.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Obstacle</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b> <div style='display:inline; background: lightgrey; border: none; border-radius: 4px; padding: 0px 2px; font-size:7px; font-weight:600;'>Off Road</div> Heavy Underbrush:</b>  <span style='padding: 0px 2px;'>The ground has tough shrubbery making travel difficult. +1 Travel Fatigue.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Rooted Gnarls:</b>  <span style='padding: 0px 2px;'>Trees Choke the path, roots tangle and hop along the ground making walking difficult. +1 Travel Fatigue </span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Slippery Trail:</b>  <span style='padding: 0px 2px;'>Area is particularly difficult to Travel. Characters may all choose to gain +1 Travel Fatigue or attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> Challenge (Failure: <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Wound to ramdom limb.)</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Barrier</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Rushing River:</b>  <span style='padding: 0px 2px;'>Resist 3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> to Swim across.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Ravine:</b>  <span style='padding: 0px 2px;'>A difficult to climb ravine blocks the chosen space. Must either travel around or brave a difficult climb.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'><div style='text-align:center;'>Interior/ Entrance</div></div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Cavernous Hole:</b>  <span style='padding: 0px 2px;'>A Large hole opened up in the world casting light and roots down into the deep dark depths.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Mossy Cave:</b>  <span style='padding: 0px 2px;'>Mossy and water drip down the entrance, creating a small muddy puddle, at the threshold.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Gargantuan Cavern:</b>  <span style='padding: 0px 2px;'>Large trees complete to obscure the Cavern entrance, High Rocky walls, with Numerous large boulders littering the inside.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Underground River Cave:</b>  <span style='padding: 0px 2px;'>Emerging from underground and river has cut a tunnel through the earth.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Grotto:</b>  <span style='padding: 0px 2px;'>A small creavous leading underground, it's a tight squeeze.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Root Hollow:</b>  <span style='padding: 0px 2px;'>Base of a tree slowly failing gravity's claim, a small earthen hollow wrapped in roots, and mossy lays.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>7 : </span></b></div><div><b>  Hollow Tree:</b>  <span style='padding: 0px 2px;'>...</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>8 : </span></b></div><div><b>  Abandoned Shack:</b>  <span style='padding: 0px 2px;'>An old hunting shelter, long since lost and abandoned, roof and walls, falling in, a thick layer of dirt reclaiming what it can.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>9 : </span></b></div><div><b>  Lone Cabin:</b>  <span style='padding: 0px 2px;'>...</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Crossing</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Woven Vine Bridge:</b>  <span style='padding: 0px 2px;'>Bridge is made of old rope and blows in the wind when crossed.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Long Very Old Rope Bridge :</b>  <span style='padding: 0px 2px;'>Bridge has a chance <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> chance of breaking if crossed my 3 or mroe Characters at once.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Tree Trunk Bridge:</b>  <span style='padding: 0px 2px;'>Bridge is primaitve and consists of little more than a tree trunk crossing the divide.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Encounters</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Wolves:</b>  <span style='padding: 0px 2px;'>A group of wolves (3-6) are in the area and are hunting the party.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Giants Spiders:</b>  <span style='padding: 0px 2px;'>Spiders tend to create an ambush for the player, particularly in caves and dense areas of the forest, and attack in groups of 2-4. Tend to Protect Treasure A.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>3 : </span></b></div><div><b>  Band of Forest Elves:</b>  <span style='padding: 0px 2px;'>A group of 2-4 Elf Rangers and 1 Elf Mage are encountered. The Elves are unfriendly to humans. But willing to let them go for a toll of 3G per Human.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>4 : </span></b></div><div><b>  Bears:</b>  <span style='padding: 0px 2px;'>1 to 2 Bears attack a party. Will stand out in Players flea unless they are very hungry.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>5 : </span></b></div><div><b>  Ents:</b>  <span style='padding: 0px 2px;'>Ents are mostly friendly but will exact revenge on anyone who tries to Chop Wood in the area.</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>6 : </span></b></div><div><b>  Forest Fairies:</b>  <span style='padding: 0px 2px;'>Fairies will cast Sleep (Resist 2 Sleep w/ Spirit) on Players and rob them of any gold and treasure they possess.</span> </div></div></div></div><div style='display:grid; grid-gap:2px; grid-template-columns:100px 1fr;'><div class='green3bg' style='color:white; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:11px; padding:2px; margin-left:2px;'>Hooks</div><div style='padding:1px 2px 1px 2px; font-size:9px;'><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>1 : </span></b></div><div><b>  Broken Tree Path:</b>  <span style='padding: 0px 2px;'>A line of pushed over and destroyed trees, something large has been through (suggest: Ogre, Giant, etc)</span> </div></div><div style='display:grid; grid-gap:2px; grid-template-columns:auto 1fr;'><div style='display:flex; '><b><span style='color:darkgrey;'>2 : </span></b></div><div><b>  Dead Adventurer:</b>  <span style='padding: 0px 2px;'>The journal of a dead adventure speaks of a jewel he means to bring his family in a nearby Town. It is worn around his neck.</span> </div></div></div></div><div></div></SectionContainer></RegionPage></div>
</body>
</html>