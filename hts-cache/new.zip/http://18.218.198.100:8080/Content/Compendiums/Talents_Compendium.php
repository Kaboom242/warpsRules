<html>
    <head>
        <title>Talents Compendium</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
         width: 100%;
        }
        .linkHead0
        {
            font-weight: 900;
            padding-bottom: 5px;
            font-size: 14px;
        }
    </style>
    <body style='background:hsla(0,0%,40%,1);'>
    <div style='position: fixed; left: 0px; top: 0px; display: flex; flex-direction: column; height: 100%; background: white; padding: 5px;'>
        <a class=linkHead0 href='#Athletics'>Athletics</a>
        <a class=linkHead0 href='#Skills'>Skills</a>
        <a class=linkHead0 href='#Intellectual'>Intellectual</a>
        <a class=linkHead0 href='#Organizational'>Organizational</a>
        <a class=linkHead0 href='#Doctrines'>Doctrines</a>
    </div>
    <div style='margin-left: 130px;'>
<div style='display: grid;grid-template-rows: 1fr;grid-template-columns: repeat(auto-fill, 356px);grid-gap: 8px 8px;grid-auto-flow: row;'><div id='Athletics' style='grid-column: 1 / -1;font-size: 25px;font-weight: 900;color: white;margin-bottom:-6px;'>Athletics</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Athlete <f7>Athletics</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            An <keywordGray>Athlete</keywordGray> is physcially fit and can enhance their physcial skills.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Runner 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Dash:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        	<br> <b>Catch Breath:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Runner 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Dash:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        	<br> <b>Catch Breath:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'style='border-radius:4px 0px 0px 0px;' >
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Climber 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Climbing:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        	<br> <cs><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>  Stamina Loss</cs><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Climbing Check.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Climber 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Climbing:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        	<br> <cs><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stamina Loss</cs><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Climbing Check.
        	<br> May do Defensive Action while Climbing
        </abilitysection><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Swimmer 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Swim</div></div> <actionSubtitle style='margin-left:3px;'>Full: Swimming</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Move 1 Space. 
                    <br><sc>1S:</sc> Attempt Active and/or Defensive Action.
                    <br><b>OR</b> 
                    <br><sc>2S:</sc> Attempt Full Action with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>.
                    <br><sc>3S:</sc> Attempt Full Action.
                    </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Swimmer 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Air Loss Resist: </b>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Swim</div></div> <actionSubtitle style='margin-left:3px;'>Full: Swimming</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Move 1 Space. 
                    <br>May attempt Active and/or Defensive Actions.
                    <br><b>OR</b> 
                    <br><sc>2S:</sc> Attempt Full Action.
                    </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Gray-4);'>
            <div>Horse Rider <f7>Athletics</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            <b>Horse Rider</b> allows the use of Horses for transportation and even Combat.
        </abilitysection><abilitysection class='asecGray'>
            A Horse may be represented be a NPC Card.
            <br> A Horse is required to Train this Ability.
        </abilitysection><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:flex; align-items:center; font-size:9px; border:solid 1px black; padding:2px;'>
                <div style='text-align:center;'><b>Panicking</b></div>
            </div>
            <div style='font-size:8px; border:solid 1px black; padding:2px;'>
                If a Horse is Attacked (Hit or Miss) becomes Panicked.
                <br> <b>Panicked:</b> Each Round moves 2 Spaces away from danger if possible and attempts Contest of <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> (Horse) vs <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> (Rider).
                <br> <b>Horse Wins:</b> Rider falls 1 Space in random direction from Horse and takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Damage.
            </div>
        </div>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rider 1
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Horse Travel:</b> May Ride Horse. Horse Resists Travel Fatigue.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Saddle Soreness:</b> You gain +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue whenever Horse Resists Fatigue.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Clamber</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Get on/off Horse. <sc>0S:</sc> Fall Prone.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rider 2
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Saddle Soreness:</b>  You gain +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue for every unresisted Fatigue Horse receives.
            <br> <b>Skilled Mount/Dismount:</b> Can Mount or Dismount Horse as an Active Action.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Horse Care</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Horse gains 1 Morale. 
                    <br><cs>1S:</cs> Horse loses 1 Fatigue.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Calm Horse</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>When a horse would become panicked,</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Horse is not panicked.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rider 3
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Riding Maneuver</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Attempt tricky manuever while riding horse.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Horse Bond</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>2S:</sc> You are Bonded with Horse.</div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecGray'>
            <b>Saddled Rider:</b> Can Ignore Saddle Soreness w/ Bonded Horse.
            <br> <b>Brave Horse:</b> Bonded Horse does not panic unless 4 Mental Dmg.
            <br> <b>Nimble Rider:</b> Bonded Horse has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dash.
            <br> <b>Horse Call:</b>Bonded Horse may come at your command and follow simple instructions.
        </abilitysection></rulecard></div><div id='Skills' style='grid-column: 1 / -1;font-size: 25px;font-weight: 900;color: white;margin-bottom:-6px;'>Skills</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Survivalist <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Survivalist</b> is able to survive off the land and manage dangerous terrain.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Survivalist 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 2
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Arid: <br><f7>Chaparral, Plains, Desert, Badlands</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Lush: <br><f7>Wetlands, Forest, Coniferous, Jungle</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Temperate: <br><f7>Plains, Pastoral, Chaparral, Wetlands, Alpine</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Severe: <br><f7>Pastoral, Forest, Coniferous, Alpine, Tundra, Ice Field</f7></div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                Survialist 3
            </abilitysubtitle>
        </div>
        <div style='display:grid; grid-gap:1px; grid-template-columns:1fr 1fr 1fr;'>
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Alpine:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Badlands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Chaparral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Coniferous:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Desert:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Forest:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Ice Field:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Pastoral:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Plains:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Jungle:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Tundra:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            
            <div style='display:grid; grid-template-columns:1fr;'>
                <abilitysection class='asecGray' 
                style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Wet Lands:</div>
                    <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/3<div style='display:inline; color:black; font-weight:800;'>AP</div><f8><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                </abilitysection>
            </div>
            </div><abilitysection class='asecGray'>
            <b>Forage/Hunt/Find Shelter/Use Tinder:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Knowledge (Nature):</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection><div style='height:3px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Survialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Forage</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                    &nbsp;&nbsp;&nbsp;  <b>Attempt Additional Forage:</b> Resist <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div>.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Region</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> 1 Rummage. <cs>1S:</cs> 2 Herbs. <cs>2S:</cs> 1 Food </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Hunt</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>Attempt to hunt within region. Cannot be done in Darkness.</f7>
                    <br><sc>2S:</sc>Kill Small(2 Meat) Creature. 
                    <br><sc>3S:</sc>Medium(4 Meat). <sc>4S:</sc>Large(6 Meat + Cloak).
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Find/Make<div style='height:1px;'></div> Shelter</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><b>Skill Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> +1 Warmth/Cool Dice.
                    <br><sc>2S:</sc> +2 Warmth/Cool Dice. <sc>2S:</sc> +1 Comfort.
                </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Specialist
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Gather Tinder</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Refill Tinderbox.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Terrain Expert
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Fire By Hand</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist:</b><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>&nbsp;&nbsp;&nbsp;&nbsp; Create a Fire without using any tools.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Guide</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Party's Resist Travel Fatigue check.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Musician <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Musician</b> is someone skilled inplaying an instrument or singing.
        </abilitysection>
        <div style='display:grid; grid-template-columns:150px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Musician 1
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Perform Bonus:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Can Write up to 6 Songs.
        </abilitysection>
        <div style='display:grid; grid-template-columns:150px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Musician 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Perform Bonus:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>.
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Can Write up to 12 Songs.
        </abilitysection>
        <div style='display:grid; grid-template-columns:150px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Musician 3
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/20<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Perform Bonus:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Can Write up to 18 Songs.
        </abilitysection><div style='height:2px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Busk</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress.
                    <br><cs>1S:</cs> +1 Gold.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Perform</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    May attempt once per song. Song limit determined by instrument.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                    <div style='display: grid; grid-template-rows: auto 1fr; grid-gap:2px;'>
                        <div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>
                            <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b>Perform Bonus</b> ______ 
                            <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b>Locations Bonus</b> _______ 
                        </div>
                        <div style='text-align: left;'> 
                            <b>Location Bonus:</b> Village (<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>0<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>), Town (<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>), City (<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>)
                            <br><b>If Busking together:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                        </div>    
                    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><cs>1S:</cs> +1 Gold.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Write Song</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Spend some time to write out a song you have Inspiration for.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='background:white; border-radius;4px; background:var(--Gray-3); display:grid; grid-template-columns:3fr 1fr; border-radius:4px 4px 0px 0px; padding:1px;'>
            <div style='font-size:7px; color:white;'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Songs</b></div>
        </div>
        <abilitysection> When entering a Settlement / returning after some time, songs are no longer Stale. </abilitysection>
        <div style='background:white; border-radius;4px; border-color:var(--Gray-4); border-style:none solid solid solid; border-width:1px; border-radius:0px 0px 4px 4px;
        display:grid; grid-template-columns:1fr 1fr; padding:0px 2px 0px 3px;'>
            <div style='background:white; border-radius;4px; background:var(--Gray-3); grid-column: span 2; display:grid; grid-template-columns:3fr 1fr; border-radius:4px 4px 0px 0px; padding:1px;'>
                <div style='font-size:7px; color:white;'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Musician 1 Songs</b></div>
            </div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>1.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>2.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>3.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>4.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>5.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>6.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
            <div style='background:white; border-radius;4px; background:var(--Gray-3); grid-column: span 2;  display:grid; grid-template-columns:3fr 1fr; border-radius:4px 4px 0px 0px; padding:1px;'>
                <div style='font-size:7px; color:white;'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Musician 2 Songs</b></div>
            </div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>7.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>8.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>9.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>10.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>11.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>12.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
            <div style='background:white; border-radius;4px; background:var(--Gray-3); grid-column: span 2;  display:grid; grid-template-columns:3fr 1fr; border-radius:4px 4px 0px 0px; padding:1px;'>
                <div style='font-size:7px; color:white;'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Musician 3 Songs</b></div>
            </div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>13.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>14.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>15.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>16.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div>
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>17.</b></div> 
                <div style=''><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>18.</b></div> 
                <div style='grid-column:span 2; border-style:solid none none none; border-color:var(--Gray-4); border-width:1px;'></div></div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Gray-4);'>
            <div>Dog Trainer <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Dog Trainer</b> is someone who can form close and mutually beneficial relationships with dogs.
        </abilitysection><abilitysection class='asecGray'>
            All Trainer Abilities only work on Bonded Dogs. Unbonded Dogs may follow you around, but will act on their own agency.
            <br> Dog is represented by the Hound Card and tracked on a separate Status Sheet, do not use the Pet Card
            <br> A Dog must be present in order to Train this ability.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Trainer 1
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Bond</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>2S:</cs> You and dog are Bonded.</div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecGray'>
            <b>Companion:</b> Dog follows you around and listens to simple commands.
	        <br><b>Combat Movement:</b> Control Dog in Combat, but cannot Attack.
	    </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Play</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>2S:</cs> You gain 1 Morale. 
                    <br> <cs>1S:</cs> Dog gains 1 Morale.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Trainer 2
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Survival Skill:</b> If with Bonded Dog <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Forage, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hunt.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Guard</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Dog may attempt <sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> to warn of danger.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Track</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Dog may attempt <sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> to find and follow things.</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Trainer 3
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Combat Dog:</b> May control Dog in Combat. May attack.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Warn</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Reduce Dmg Dog takes this Round by 1.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Gray-4);'>
            <div>Sailor <f7>Skill</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <b>Sailor</b> is someone who knows how to handle watercrafts.
            <br> A Sailor may <b>Captain</b> a vessel as long as they have the permission of the owner (or support of the crew). This allows them to choose where the ship travels and what actions it takes in combat.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sailor 1
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            Can Captain a Sailboat
            <br> <b>Sea Legs:</b> You may move during ship in Combat as if -1 Difficult Terrain.
            <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Challenges and Boarding Challenges.
            <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Fishing.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sailor 2
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            Can Captain a Longboat or Caravel.
        	<br> May reroll wind check once per 3 days.
        	<br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Repair and to Hit w/ Cannons.
        	<br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Challenges and Boarding Challenges.
        	<br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Fishing.
        </abilitysection>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sailor 3
            </abilitysubtitle>
            <abilitysection class='asecGray' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	Can Captain a Galley or Frigate.
        	<br> May reroll wind check once per day.
        	<br> <b>Sea Legs:</b> You may move during ship in Combat as if -2 Difficult Terrain.
        	<br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Repair and to Hit w/ Cannons.
        	<br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Challenges and Boarding Challenges.
        	<br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Fishing. May reroll and take Highest once per day.
        </abilitysection><div style='height:5px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Sailor 2
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Ship Combat Assist</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Add <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to any Vehicle Combat Check you are close enough to effect. (Once per Vehicle Combat Action per Vehicle Combat Round).</div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Sailor 3
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Command Crew</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b><f7>Requires Crew to carry out Actions.</f7></b>
                    <br> May add up to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> spread among any Vehicle Combat Checks. (Once per Vehicle Combat Round).
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Intellectual' style='grid-column: 1 / -1;font-size: 25px;font-weight: 900;color: white;margin-bottom:-6px;'>Intellectual</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Scholar <f7>Intellectual</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            An <keywordGray>Scholar</keywordGray> is someone who has studied the knowledge of the world.
        </abilitysection><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Scholar 
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Knowledge</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    May check/use knowledge. Includes undersanding monster anatomy, history, etc.
                    <br> <b>Languages:</b> May attempt to comprehend other langauges.
                    <br> More successes indicates stronger knowledge/understanding.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr;'>
            <abilitysubtitle class='astGray' style='font-size:10px; border-radius: 4px 0px 0px 4px;'>
                Social Knowledge
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-weight:500; background:var(--Gray-1); border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-start; '>Languages, cultures, history, geography, etc.</div>
            </abilitysection>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Social Studies 1 <br><f7>Req: Scholar</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Social):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Social Studies 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Social):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Mage:</b> 3<div style='display:inline; color:black; font-weight:800;'>AP</div> towards Green/Yellow/Soul Schools.
        	<br> <b>Can Speak Common Lanagues</b> (Ex: Westron, Southron, Eastron, Elven, Dwarven.)
        	<br> <b>Basic Understanding of Rare Lanagues</b> (Ex: Monster Speak, Ancient Tongue)
        </abilitysection><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr;'>
            <abilitysubtitle class='astGray' style='font-size:10px; border-radius: 4px 0px 0px 4px;'>
                Nature Knowledge
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-weight:500; background:var(--Gray-1); border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-start; '>Nature, anatmoy, biology, etc.</div>
            </abilitysection>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Nature Studies 1 <br><f7>Req: Scholar</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Nature):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Nature Studies 2 
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Nature):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Mage:</b> 3<div style='display:inline; color:black; font-weight:800;'>AP</div> towards Death/Plague/Blue Schools.
        	<br><b>Surgery Checks:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:auto 1fr;'>
            <abilitysubtitle class='astGray' style='font-size:10px; border-radius: 4px 0px 0px 4px;'>
                Cosmolgical Knowledge 
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-weight:500; background:var(--Gray-1); border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-start; '>Aether, theology, prehistory, cosmology, etc.</div>
            </abilitysection>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Cosmolgical Studies 1 <br><f7>Req: Scholar</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Cosmolgical):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Cosmolgical Studies 2
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
             <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Knowledge (Cosmolgical):</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> &nbsp;&nbsp;&nbsp;  <f7><b>Mage:</b> 3<div style='display:inline; color:black; font-weight:800;'>AP</div> towards Purple/Void/Shadow/Red Schools.</f7>
        	<br><b>Sense Divine / Arcane:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
        </abilitysection><div style='height:3px;'></div>
        <div style='display:grid; grid-template-columns:160px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Writer <f7>Req: Scholar</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <f8>
        	<b>Completing a Novel:</b> Occurs at 20 Completion and 5 Inspiration.
        	<br> <b>Publishing a Novel:</b> Must be done in a City. Gain 20<b6>G</b6> + (<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> x 5<b6>G</b6>).
        	</f8>
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Write</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Knowledge Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b><f7>Req: Writing/Drawing Tools</f7></b>
                    <cs>1S:</cs> +1 Completion
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:110px 70px auto 1fr auto 30px; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Book:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Knowledge:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Completion</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> /20</div></abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Inspiration</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp/5<f8></div></abilitysection>
        </div><div style='display:grid; grid-template-columns:110px 70px auto 1fr auto 30px; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Book:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Knowledge:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Completion</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> /20</div></abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Inspiration</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp/5<f8></div></abilitysection>
        </div><div style='display:grid; grid-template-columns:110px 70px auto 1fr auto 30px; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Book:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Knowledge:</abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Completion</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> /20</div></abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'>Inspiration</abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp/5<f8></div></abilitysection>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Healer <f7>Intellectual</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            Speciailizes in healing with first aid.
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Nurse (1)
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Apply Bandage:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp <b>Give Treatment/Amputation/Aid:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            <br> <f8><b>Ally's After Combat Dying Resist:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Medic (2)<br><f7>Req: Scholar</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
            <b>Apply Bandage:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp <b>Give Treatment/Amputation/Aid:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            <br> <b>Craft:</b> Crutch (Req: Stick)
            <br> <f8><b>Ally's After Combat Dying Resist:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp  <b>Applying Medicine:</b> Add <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Doctor (3)<br><f7>Req: Nature Studies 1</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/15<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Apply Bandage:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <f8><b>Give Treatment/Amputation/Aid:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
            <br> <b>Craft:</b> Bandage (Req:Cloth+Herb), Crutch (Req: Stick)
            <br> <f8><b>Ally's After Combat Dying Resist:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp <b>Applying Medicine:</b> Add <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Surgeon (4)<br><f7>Req: Nature Studies 2</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/20<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray'>
        	<b>Apply Bandage:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
            &nbsp;&nbsp; <f8><b>Give Treatment/Amputation/Aid:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. +1 Fatigue to reroll.</f8>
            <br> <b>Craft:</b> <f7>Medicine (Req:Spell Material/3 Herbs), Bandage (Req:Cloth+Herb), Crutch (Req: Stick)</f7>
            <br>  <f8><b>Ally's After Combat Dying Resist:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp <b>Applying Medicine:</b> Add <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </abilitysection><div style='height:5px;'></div>
        <abilitysectiontitle class='astGray'>
            Actions
        </abilitysectiontitle>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Medic
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Drain Infection</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>Can only apply soon after Ally gains Infection.</f7>
                    <br><cs>1S:</cs> May reroll Infection Check and take lowest.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Set Bone</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>Can only apply once per Broken instance.</f7>
                    <br> <cs>1S:</cs> Reduce Broken by 1.
                    <div style='height:1px;'></div> <f7>The Patient Resists 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.</f7>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Craft Medical Supplies</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Craft up to 3 Medical Items.
                    </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Doctor
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Save Life</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>Can only apply soon after Ally gains Mortal Wound.</f7>
                    <br><cs>1S:</cs> May reroll Mortal Wound Check and take lowest.
                </div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Surgeon
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Limb<br> Reattachment</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    See City: Church (Limb Reattachment).
                    <br> <cs>1S:</cs> Reduce Infection by 1.
                    <br> May apply to fixing Lame limbs. If so count as 4 Rot. 
                    <div style='height:1px;'></div> <f7>The Patient Resists 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.</f7>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Last Resort</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>3S:</sc> Remove up to 3 Dying.
                    <fc>2S or Less:</fc> Patient Dies. Resist 3 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Organizational' style='grid-column: 1 / -1;font-size: 25px;font-weight: 900;color: white;margin-bottom:-6px;'>Organizational</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Merchant <f7>Organization</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns: 1fr;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Debtor (1)
            </abilitysubtitle>
        </div>
        <abilitysection class='asecGray' style='font-size:7px;'>
	        Banks may loan money to Debtor with a Debt of 110% of the Loan. 
	        <br> Failing to pay back on time will result in thugs, bounties, and attempts to Imprison you.
            <br> Banks may have smaller loans or extra penalties for those they dont trust. More convincing people may be able to get bigger loans and a better deal.
        </abilitysection><div style='display:grid; grid-template-columns:auto 1fr auto 1fr; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'><f11>Debt:</f11></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp<f8>  </div></abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'><f11>Date:</f11></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8><f8>  </div></abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Courier (2)
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray' style='font-size:7px;'>
            <b>Couriers</b> buy goods in Bulk and sell them with the assistance of the Trader's Guild
            <br> <b>Bulk Buy:</b> Buy Goods marked as Trade Goods from Trader's Union. (GM sets Type/Max Amount.)
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Bulk Sell</div></div> <actionSubtitle style='margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    Gain value of Bulk Goods after traveling them to another location.
                    <br> <cs>1S:</cs> Get 10% Back on Bulk Goods. (Round Down)
                    <br> <b>Easy Trip:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>. <b>Harsh Trip:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>. <b>Dangerous Trip:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.
                </f7></div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Manager (3)
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray' style='font-size:7px;'>
        	Managing a Business. Requires Asssets.
        	<br><b>Assets:</b> Help produce money for business. (Ex: Employees, Location, etc)
        	<div style='display:grid; grid-template-columns: auto auto auto 1fr; grid-gap:1px 5px; font-size:7px;'>
                <div><b><u><f7>Asset Type</f7></u></b></div>    <div style='display:flex; justify-content:center;'><u><b>Value</b></u></div>      <div style='display:flex; justify-content:center;'><u><b>Cost</b></u></div><div></div>
        	    <div><b>Minor Asset</b></div> <div style='display:flex; justify-content:center;'>1</div> <div style='display:flex; justify-content:center;'>5<b6>G</b6></div><div></div>
        	    <div><b>Medium Asset</b></div> <div style='display:flex; justify-content:center;'>3</div> <div style='display:flex; justify-content:center;'>13<b6>G</b6></div><div></div>
        	    <div><b>Major Asset</b></div> <div style='display:flex; justify-content:center;'>5</div> <div style='display:flex; justify-content:center;'>20<b6>G</b6></div><div></div>
        	</div>
        	<b>Temporary Assets:</b> Last a limited time (1 to 3 weeks). <f7>Ex: Quality Goods, Marketing Push</f7>
        	<br> Assets can be gained/improved through quests and other in game activities as well.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Revenue</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Weekly</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <fc>0S:</fc> <b>Loss</b> Must pay Total Assets x 5<b6>G</b6>.
                    <br><sc>1S:</sc> <b>Minor Profit</b> Gain Total Assets x 3<b6>G</b6>.
                </div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecGray' style='font-size:7px;'>
        	<b>Debt:</b> All Revenue Loss becomes a Debt to the Bank if not paid.
        	<br> If enough is owed to the bank they will come after you and your business.
        </abilitysection>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGray' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Investor (4)
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <abilitysection class='asecGray' style='font-size:7px;'>
            <b>Investments</b> Can be done at a Bank, Shipyard, Guild Hall, or other places of Business.
            <br> Characters may make an Investment of up to 200G. In 4 Weeks they roll an Investment Check and may pick up their rewards.
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Safe</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>0S:</sc>Lose All.    <sc>1S:</sc>Get equal value.        <sc>2S/3S:</sc>Get x2 value.    
                        <sc>4S:</sc>Get x3 value.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Risky</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>0S/1S:</sc>Lose All. <sc>2S/3S:</sc>Get x3 value. <sc>4S:</sc>Get x4 value.
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:auto 1fr auto 1fr; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'><f11>Stocks:</f11></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8><f8>  </div></abilitysection>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'><f11>Date:</f11></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8><f8>  </div></abilitysection>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Gray-4);'>
            <div>Business</div>
        </rulecardtitle><abilitysection class='asecGray'>
            This card can be used to track information abotu your business.
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f16><b>Business Name:</b></f16>
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>Business Description:</b></f13>
            <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div>
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>Assets</b></f13>
            <div style='display:grid; grid-template-columns: 3fr 1fr 1fr;'>
                <div><b>Asset Name</b></div> <div><b>Value</b></div> <div><b>Improvement</b></div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid gray; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
                <div style='border-bottom: 1px solid white; border-radius: 0px; grid-column-start: span 3;'> <f12> &nbsp </f12> </div>
            </div>
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>Management Style</b></f13>
            <f11><div style='height:1px;'></div> <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Safe</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Standard</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Risky</b></f11>
        </abilitysection><div style='display:grid; grid-template-columns:auto 1fr auto; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray'  style='font-weight:700; background:white;'><f10>Un-Collected Profits:</f10></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8><f8>  </div></abilitysection>
            <abilitysection class='asecGray'  style='font-size:8px;'>May pick up at Business or at Bank.</abilitysection>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Gray-4);'>
            <div>Noble <f7>Organization</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            A <keywordGray>Noble</keywordGray> is of high blood. They own land and have connections to the rulers of the land.
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f16><b>House Name:</b></f16>
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>House Crest:</b></f13>
            <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:2px;'></div>
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>House Motto:</b></f13>
            <div style='height:5px;'></div> <div style='height:5px;'></div> 
        </abilitysection><abilitysection class='asecGray' style='background:white;'>
            <f13><b>House Regon/History:</b></f13>
            <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div> <div style='height:5px;'></div>
        </abilitysection><abilitysection class='asecGray'>
            <b>Becoming a Noble</b>
            <br><f7>Noble can only be gained in Character Creation or in-world events.</f7>
            <br><f7>A Nobles position of Fallen/Low/Med/High takes into account the total power of their House as well as within their House.
            For example a Low Noble could be a low or disgraced member of the Royal Household, and a Mid Noble might be the head of lower house.</f7>
            <br> <b>Choose a Noble Rank</b>
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Fallen Noble:</b> +25<b6>G</b6>, 0 House Rank Points.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Lower Noble:</b> -5<div style='display:inline; color:black; font-weight:800;'>CP</div>, +65<b6>G</b6>, 10 House Rank Points.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Middle Noble:</b> -10<div style='display:inline; color:black; font-weight:800;'>CP</div>, +80<b6>G</b6>, 20 House Rank Points.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>High Noble:</b> -15<div style='display:inline; color:black; font-weight:800;'>CP</div>, +100<b6>G</b6>, 30 House Rank Points.
            <div style='height:2px;'></div> <b>5 <div style='display:inline; color:black; font-weight:800;'>CP</div> toward Dragon Blood / Celestial/Demon Blood / Ancestral Weapon OR 30<b6>G</b6></b>.
            <div style='height:2px;'></div> <b>-10G:</b> Horse Rider 1. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp <b>-15G:</b> Scholar.
        </abilitysection><abilitysection class='asecGray'>
            <b>House Rank Points</b>
            <br> A Noble's importance is determined by their House Rank Points. 
            More points mean a more impressive family, with better connections to the ruler of the realm.
            Fallen Nobles are those that have lost all glory, and are often in disgrace.
            <br> <b>House Rank Rewards</b>
                <br> Having House Rank Points not only means more wealth for you and your House, but also clout within the kingdom.
                    House Gold represents the portion of the wealth avaiable to you weekly, and can be retrieved from a bank.     
                <br> &nbsp;&nbsp;&nbsp;  <b>10-19:</b> 5<b6>G</b6> per Week.
                <br> &nbsp;&nbsp;&nbsp;  <b>20-29:</b> 10<b6>G</b6> per Week.
                <br> &nbsp;&nbsp;&nbsp;  <b>30 and over:</b> 15<b6>G</b6> per Week.
            <br> <b>Ways to gain Rank Points:</b>
        		<br> &nbsp;&nbsp;&nbsp;  Deliver a Message For The King, Impress at the Ball (1 House Rank Point)
        		<br> &nbsp;&nbsp;&nbsp;  Find a famous treasure for the house (3 House Rank Points)
        		<br> &nbsp;&nbsp;&nbsp;  Help win a major battle for the kingdom (4 House Rank Points)
        		<br> &nbsp;&nbsp;&nbsp;  Slay the Dragon terrorizing the kingdom (6 House Rank Points)
        	<br> <b>Ways to lose Rank Points:</b>
        		<br> &nbsp;&nbsp;&nbsp;  Losing Family Heirloom (-2 House Rank Points)
        		<br> &nbsp;&nbsp;&nbsp;  Embarrassing your family by looking poor at court (-2 House Rank Points)
        		<br> &nbsp;&nbsp;&nbsp;  Angering the king by saying the wrong thing (-2 House Rank Points)
        </abilitysection></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Gray-4);'>
            <div>Criminal <f7>Organization</f7></div>
        </rulecardtitle><abilitysection class='asecGray'>
            <keywordGray>Underworld</keywordGray> access to the Black Market and work from Gangs.
        </abilitysection>
        <div style='display:grid; grid-template-columns:150px 1fr auto;'>
            <abilitysubtitle class='astGray'  style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Underworld Access
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end; '><f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Black Market <f8>(All Cities)</f8>
            </abilitysubtitle>
        </div>
        <abilitysection class='asecGray'>
            <f7> 
            <b>Drugs/Poison/Lock Picks:</b> Trip <b>3<b6>G</b6></b>, Sleet <b>1<b6>G</b6></b>, Fizzyn <b>1<b6>G</b6></b>, Lock Picking Kit <b>5G</b>, Poison <b>15G</b>
            <br> <b>Other:</b> Caltrops <b>5<b6>G</b6></b>, Garrote <b>5<b6>G</b6></b>, Rumors <b>1<b6>G</b6></b>, Secrets <b>2 to 20<b6>G</b6></b>, Hit Attempt <b>30 to 100<b6>G</b6></b>
            <br> May know about and visit and other City Underworld Locations.
            </f7>
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Loans
            </abilitysubtitle>
        </div><abilitysection class='asecGray' style='font-size:7px;'>
	        Gangs may loan money with a Debt of 110% of the Loan. 
	         Failing to pay back on time will result in thugs, bounties, and attempts to Imprison you.
             Gangs may have smaller loans or extra penalties for those they dont trust. More convincing people may be able to get bigger loans and a better deal.
        </abilitysection><div style='display:grid; grid-template-columns:auto 1fr auto 1fr auto 1fr; grid-gap:1px; margin-left:00px;'>
            <abilitysection class='asecGray' style='font-weight:700; background:white;'><f9>Org:</f9></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp<f8>  </div></abilitysection>
            <abilitysection class='asecGray' style='font-weight:700; background:white;'><f9>Debt:</f9></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8>/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp<f8>  </div></abilitysection>
            <abilitysection class='asecGray' style='font-weight:700; background:white;'><f9>Date:</f9></abilitysection>
            <abilitysection class='asecGray' style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-end;'><div> <f8><f8>  </div></abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Fighting Pits
            </abilitysubtitle>
        </div><abilitysection class='asecGray' style='font-size:7px;'>
            On some days may fight a monster or another fighter. (Ex: Goblin, Bugbear, Bear.) 
        	<br> 10<b6>G</b6> per Difficulty. They offer bonuses for fighting without equipment etc. Commissioner will only allow fights they find interesting.
        	 Viewers might be able to bet money on the fight.
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Gambling
            </abilitysubtitle>
        </div><abilitysection class='asecGray' style='font-size:7px;'>
            <b>1.</b> Put starting value in pool.
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>2.</b> Roll <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and Keep Results Hidden.
            <br> <b>3.</b> Each Player may put more money in pool. (Must match highest amount to stay in.)
            <br> <b>4.</b> Reveal Hidden Dice and roll +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>5.</b> Most Successes Wins Pool. Tie <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> until broken.
        </abilitysection>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGray'>
                Gangs
            </abilitysubtitle>
        </div><abilitysection class='asecGray' style='font-size:8px;'>
            <f7>Doing quests for Gangs increases Rep by 1 to 5 points depeneding on difficulty.</f7>
        </abilitysection><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Job</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    Do one of the following (Random 1-4):
            		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>1: Disposal</b> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>. Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
            		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>2: Shake Down</b> May gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold. If so <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>1S:</sc> Lose <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rep.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>3: Beat Down:</b> Resist 3 Wound w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.
            		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>4: Grift:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>2S:</sc> Must get <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> on <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> or guards attempt to arrest you.
            		<br> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rep. Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold.
                </f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shmooze</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f7><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    <sc>1S:</sc> +1 Rep in Gang. Can't go above 15 this way.
                </f7></div></challengeText></challengeContainer></div></actionContainter>
        <div style='display:grid; grid-template-columns:200px 1fr;'>
            <abilitysubtitle class='astGray'>
                The Black Hand <f7>Gang</f7>
            </abilitysubtitle> 
            <abilitysection class='asecGray' 
            style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-start; border-radius:0px 4px 4px 0px;'>
                <div>
                    <f8>Reputation:<f8>
                </div>
            </abilitysection>
        </div><abilitysection class='asecGray'>
            <f7>Operates in illegal trades, including smuggling, drugs, and assassinations throughout Arthia.
            Ruled by the Lord of Secrets, a shadowy figure who manipulates entire empires to their own ends.
            <br><b>Initiation (10 Rep):</b> Must assassinate someone for the Black Hand. <b>Initated:</b> Gain 4<b6>G</b6> per week.
            <br><b>Made (30 Rep):</b> Special quest. <b>Reward:</b> Gain 10<b6>G</b6> per week. Free access to Spy Network. May ask for a favor from the Lord of Secrets.
            </f7>
        </abilitysection>
        <div style='display:grid; grid-template-columns:200px 1fr;'>
            <abilitysubtitle class='astGray'>
                Order of Shadow <f7>Gang</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-start; border-radius:0px 4px 4px 0px;'>
                <div>
                    <f8>Reputation:<f8>
                </div>
            </abilitysection>
        </div>
        <abilitysection class='asecGray'>
            <f7>Thought to be a secretive wing of the Eastern Governments but often seems to act on its own accord.
            Mostly involved in illegal trade and hired assassinations.
            <br><b>Initiation (10 Rep):</b> Lose Finger and do a job for Order of Shadow. <b>Initated:</b> Gain 4<b6>G</b6> per week.
            <br><b>Made (30 Rep):</b> Special quest. <b>Reward:</b> Gain 10<b6>G</b6> per week. May eat from the Black Lotus: +9AP, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Stealth Checks in darkness.
            </f7>
        </abilitysection>
        <div style='display:grid; grid-template-columns:200px 1fr;'>
            <abilitysubtitle class='astGray'>
                Shiah-Deem <f7>Gang</f7>
            </abilitysubtitle>
            <abilitysection class='asecGray' 
            style='display:flex; align-items:center; font-weight:700; background:white; justify-content:flex-start; border-radius:0px 4px 4px 0px;'>
                <div>
                    <f8>Reputation:<f8>
                </div>
            </abilitysection>
        </div>
        <abilitysection class='asecGray'>
            <f7>Thought to be mostly operated by non-humans such as Night Elves, Demon kin, and Fish People.
            Mostly operate in bloodsport, illegal magic, and drugs.
            <br><b>Initiation (10 Rep):</b> You/representative mst fight in pits and win. <b>Initated:</b> Gain 4<b6>G</b6> per week.
            <br><b>Made (30 Rep):</b> Special quest. <b>Reward:</b> Gain 10<b6>G</b6> per week. Gain a Magic Item.
            </f7>
        </abilitysection></rulecard></div><div id='Doctrines' style='grid-column: 1 / -1;font-size: 25px;font-weight: 900;color: white;margin-bottom:-6px;'>Doctrines</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Yellow-4);'>
            <div>Follower of Azeal <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astYellow' style='border-radius:4px 0px 0px 4px;'>
                Follower  
            </abilitysubtitle>
            <abilitysection class='asecYellow' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astYellow' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecYellow'>
                The <keywordYellow>Blessing of Light</keywordYellow>.
                <br><f7>Often involves being submerged in holy water and bathed in the light of Azeal.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astYellow' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecYellow'>
                <keywordYellow>Azeal</keywordYellow> <f7>is the God of Light, Order, and Justice.
                Azeal can be both merciful and cruel and values those who help the poor, fight for righteousness, and punish those who sin against him.</f7>
                <br><keywordYellow>The Church of Azeal</keywordYellow> <f7>is the God's primary force in the world. They are a large organization with chapters in almost every city in Ersonia.
                The Church of Azeal is made up of Bishops with the Head Bishop being named the <keywordYellow>High Inquisitor</keywordYellow>.
                Serving the church is <keywordYellow>The Centurion</keywordYellow> a group of the 100 most valorous Paladins in the land.
                <br>Serving Azeal's will most directly are <keywordYellow>The Messengers</keywordYellow> a group of angels rarely seen by mortals.
                Highest of these are <keywordYellow>The Pure Ones</keywordYellow> considered to be Azeal's voice in the world.
                <br><keywordYellow>Vile</keywordYellow> <f7>creatures are those that Azeal is particularly opposed to.
                These include the Undead (Zombies, Skeletons), Demons, and Desease Spawn. Azeal grants Valor for disposing of such creatures.
                <br><keywordYellow>Covenant</keywordYellow> with Azeal is best brought through holy sites and artifacts.
                </f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astYellow' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Valor
                </abilitysubtitle>
            </div>
            <abilitysection class='asecYellow'>
                <keywordYellow>Valor</keywordYellow> <f7> is the Favor of Azeal.
                <br> <b>Gaining Valor (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Valor (Deed):</b> Valor is granted to those who further Azeal's interests. This includes acts related to charity, order, and scourging the vile and wicked.
                <br> <b>Losing Valor:</b> Azeal takes Valor away for acts of disorder such a stealing. 
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astYellow' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecYellow'>
                <f7>
                <keywordYellow>Blasphemy</keywordYellow> is when Azeal punishes his followers with Stress or Dread for going against the Doctrine.
                Azeal deplores not helping those in need, disturbing order, and going against the church.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astYellow'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordYellow>Valor</keywordYellow>. 
                    <br><b>In a Church</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. <b>On Sunday</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. <f7>These may stack.</f7></div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecYellow'>
            <div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Valor</div> <b>Blessing</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> Check.
        </abilitysection><abilitysection class='asecYellow'>
            <div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Valor</div> <b>Azeal's Touch</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>Azeal hand is on your shoulder. You will remain steadfast.</i>
            <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Hunger/Thirst/Travel Fatigue Check.
        </abilitysection><abilitysection class='asecYellow'>
            <div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Valor</div> <b>Mercy of Azeal</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>You beg Azeal to have mercy on your companion. The holified water mixes with the tears of hope.</i>
                <br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Survive Check. Additional <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if pouring water over them.
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Yellow-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordYellow>Valor</keywordYellow> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Yellow-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><span style='color:var(--Gray-2)'></span> <keywordYellow>Valor</keywordYellow> (Deeds)</div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Red-4);'>
            <div>Bloodpact of Tyrannus <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astRed'  style='border-radius:4px 0px 0px 4px;'>
                Blood Sworn  
            </abilitysubtitle>
            <abilitysection class='asecRed' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astRed' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecRed'>
                <f7>The <keywordRed>Baptism of Blood</keywordRed>.
                <br>Often involves a test of strength or pain, and/or a fight to the death as well.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astRed' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecRed'>
                <keywordRed>Tyrannus</keywordRed><f7>, by the legends is a 2 Headed Eagle God while others feel Tyrannus as a surge of power in thier veins, a driving force behind thier actions. 
                Tyrannus is Bloodshed, War, and Destruction. Tyrannus is cruelity to others, Allegance to the group. Create order through the destrution of the weak. Tyrannus is mastery and success.
                Only respect the strong, and the weak should be culled. Those who follow Tyrannus find battle the highest of callings.</f7>
                <br><keywordRed>The Cabal of Tyrannus</keywordRed> <f7>is the God's primary force in the world. They don't hold regular meetings, but do have Blood Festivals, often with much combat.
                These are typically held outside the sway of civilization.
                The Cabal of Tyrannus usually has a leadership based on strength but some <keywordRed>Blood Shamans</keywordRed> commune the will of Tyrannus more directly.
                <br>The most powerful of Tyrannus's servents are called the <keywordRed>The Blood Champions</keywordRed>, demon warriors and warlords who reside in the underworld.
                Also serving Tyrannus are <keywordRed>The Maidens of War</keywordRed>, eitherial beings who favor the strong and who many prey to for victory.
                <br><keywordRed>Covenant</keywordRed> with Tyrannus is best achieved through blood sacrifice.
                </f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astRed' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Bloodpact
                </abilitysubtitle>
            </div>
            <abilitysection class='asecRed'>
                <keywordRed>Bloodpact</keywordRed> <f7> is the Favor of Tyrannus.
                <br> <b>Gaining Bloodpact (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Bloodpact (Deed):</b> Bloodpact is granted to those who further Tyrannus's interests. This may be acts related to bravery, mercilesness, and battlefield strength.
                <br> <b>Losing Bloodpact:</b> Tyrannus takes Valor away for acts of weakness and cowardice. 
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astRed' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecRed'>
                <f7>
                <keywordRed>Blasphemy</keywordRed> is when Tyrannus punishes his followers with Stress or Dread for going against the Doctrine.
                Tyrannus deplores cowardice, turning down a well met battle, and showing too much mercy.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astRed'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordRed>Bloodpact</keywordRed>. 
                    <br> <b>Drinking Blood of Enemies You Have Slain:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecRed'>
            <div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 1</div> <b>Blood Strength</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Check.
        </abilitysection><abilitysection class='asecRed'>
            <div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 2</div> <b>Tyrannus's Toughness</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>You will not fall. You will fight. Tyrannus demands blood.</i>
                <br> Remove <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Wounds and <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Illness.
        </abilitysection><abilitysection class='asecRed'>
            <div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 3</div> <b>Blood of Tyrannus</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>You cease feeling pain. Only bloodlust. BLOOD FOR THE BLOOD GOD!</i>
                <br> Ignore all Disabled Limbs for the next 3 Days.
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Red-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordRed>Bloodpact</keywordRed> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Red-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><keywordRed>Bloodpact</keywordRed> (Deeds)</div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Pink-4);'>
            <div>Revelation of Yavera <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astPink'  style='border-radius:4px 0px 0px 4px;'>
                Reveler  
            </abilitysubtitle>
            <abilitysection class='asecPink' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPink' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPink'>
                The <keywordPink>Draught of Revelry.</keywordPink>.
                <br><f7>Often invovles a debauched act of revelry and may require a feat a creativity as well.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPink' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPink'>
                <keywordPink>Yavera</keywordPink> <f7> some consider it to be a many faced god, while others feel it as a driving force that steers their actions. 
                Yavera is aligned with the mischievous, trickers, artists, and tortured souls. 
                It's a muse of art, or the passions of an eccentric serial killer. Yavera flourishes in chaos and languishes in order.
                <br><keywordPink>The Revelers of Yavera</keywordPink> are a decentralized organization devoted to Yavera that tend to have wild parties/orgies of debauchery. 
                May include drinking, dancing, and even sometimes human sacrifice led by a <keywordPink>Master of Ceremonies</keywordPink>. 
                These ceremonies are kep secret to outsiders and are called <keywordPink>Yavarra's Call</keywordPink> and happen outside of cities, often at Night or the early Morning.
                Yavera's most favored are called <keywordPink>Meastros</keywordPink> and arethose who have acheived complete mastery over their craft.
                <br><keywordPink>The Muses</keywordPink> are anglic beings who serve Yavera's will. They typically have special dominions such as the Muse of Harmony, Mischeif, Blood, Passion, etc.
                <br><keywordPink>Covenant</keywordPink> with Yavera is best acheived under the influence of powerful drugs and in the presense of revelry.
                </f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPink' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Revelation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPink'>
                <keywordPink>Revelation</keywordPink> <f7> is the Favor of Yavara.
                <br> <b>Gaining Revelation (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Revelation (Deed):</b> Revelation is granted to those who further Yavera's interests as well as provide entertain.  This includes acts related to art, mischeif, and debached and festive acts.
                <br> <b>Losing Revelation:</b> Yavera takes Revleations away from those found boring or stale.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPink' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPink'>
                <f7>
                <keywordPink>Blasphemy</keywordPink> is when Yavera punishes his followers with Stress or Dread for going against the Doctrine.
                Yavera deplores being uninteresting, living a too ordered life, or turning down a good time.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astPink'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordPink>Revelation</keywordPink>. 
                    <br> <b>Participate in Yavara's Call:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecPink'>
            <div style='display:inline-block; 
        color:var(--Pink-4); background:var(--Pink-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Revelation 1</div> <b>Vitality</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> Check.
        </abilitysection><abilitysection class='asecPink'>
            <div style='display:inline-block; 
        color:var(--Pink-4); background:var(--Pink-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Revelation 2</div> <b>Yavara's Luck</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> 
                <i>Pain dances within your moving body, like happy Fearies, Wounds glowing and shifting.</i>
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prevent <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>OR</b> Move up to <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> incoming Dmg to a different Body Area.
        </abilitysection><abilitysection class='asecPink'>
            <div style='display:inline-block; 
        color:var(--Pink-4); background:var(--Pink-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Revelation 3</div> <b>Yavara's Jubilee</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>
                <i>Fall into hallucinogenic trance, festive celebration all around...</i> May share with allies.
                <br> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale, Everyone can eat up to 3 Food. 
                <br> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Pink-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordPink>Revelation</keywordPink> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Pink-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><keywordPink>Revelation</keywordPink> (Deeds)</div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Green-4);'>
            <div>Witness of Ernok <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astGreen' style='border-radius:4px 0px 0px 4px;'>
                Witness  
            </abilitysubtitle>
            <abilitysection class='asecGreen' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:60px 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astGreen' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecGreen'>
                The <keywordGreen>Rite of Growth</keywordGreen>.
                <br><f7>Often involves finding a fairy circle deep in nature and perhaps a test of will.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:60px 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astGreen' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecGreen'>
                <keywordGreen>Ernok</keywordGreen> <f7>is the God of Nature, Beasts, and Trees.
                Ernok is pirimarly concerned with preservation of nature, though also values survival of the fittest and natural beauty.</f7>
                <br><keywordGreen>Hermitage's of Ernok</keywordGreen> <f7>can sometimes be found deep in nature, and sometiems populated by worhsippers of Ernok.
                These organizations tend to be small and loosely distributed.
                <br>Distributed around Urdun are <keywordGreen>Spirit Beasts</keywordGreen> and <keywordGreen>Life Trees</keywordGreen>, ancient undying beings representign the most primal foces of the natural world.
                <br><keywordGreen>Unnatural Areas</keywordGreen> <f7>such as cities and their encroachemnt into nature are disliked by Ernok, who would prefer nature to claim them.</f7>
                <br><keywordGreen>Valnoa</keywordGreen> <f7>is the second, darker face of Ernok, who represents the sea, the storms, and creatures of the deep.
                <f7><br><keywordGreen>Covenant</keywordGreen> with Ernok is best acheived through places far from civilizaion especially when near Life Trees and Spirit Beasts.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:60px 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astGreen' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Essence
                </abilitysubtitle>
            </div>
            <abilitysection class='asecGreen'>
                <keywordGreen>Essence</keywordGreen> <f7> is the Favor of Ernok.
                <br> <b>Gaining Essence (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Essence (Deeds):</b> Essence is granted to those who further Ernok's interests. This includes acts that further the beuty and power of nature.
                <br> <b>Losing Essence:</b> Ernok takes Essence away from those that harm nature or stray too far away from it for too long. 
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:60px 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astGreen' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecGreen'>
                <f7>
                <keywordGreen>Blasphemy</keywordGreen> is when Ernok punishes his followers with Stress or Dread for going against the Doctrine.
                Ernok deplores being hurting the forest, cruelity to animals, and spending too much time away from nature.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astGreen'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordGreen>Essence</keywordGreen>. 
                    <br> <b>At least 10 miles from road/civilization:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecGreen'>
            <div style='display:inline-block; 
        color:var(--Green-4); background:var(--Green-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Essence 1</div> <b>Invigorate</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Check.
        </abilitysection><abilitysection class='asecGreen'>
            <div style='display:inline-block; 
        color:var(--Green-4); background:var(--Green-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Essence 2</div> <b>Ernok's Gift</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>You are blessed but beauty and bounty of nature.</i>
            <br> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Meals.
        </abilitysection><abilitysection class='asecGreen'>
            <div style='display:inline-block; 
        color:var(--Green-4); background:var(--Green-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Essence 3</div> <b>Ernok's Spring</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>A spring of pure natural wonder. Blessed is nature, mother to us all.</i>
                <br> Small spring appears giving each Ally 2 Water, remove <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound, and remove <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue. 
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordGreen>Essence</keywordGreen> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><keywordGreen>Essence</keywordGreen> (Deeds)</div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Purple-4);'>
            <div>Servant of Morgeth <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                Servant  
            </abilitysubtitle>
            <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPurple' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPurple'>
                The <keywordPurple>Sacrament of Death</keywordPurple>.
                <br><f7>Involves going deep into a pit of death and complete darkness. Not all survive.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPurple' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPurple'>
                <keywordPurple>Morgeth</keywordPurple> <f7>is the God of Death, Darkness, and Rot.
                Morgeth values the extermination of life and well as the cycle of renewel. Most who worship Morgeth do so for greed of the power he may grant.</f7>
                <br><keywordPurple>The Sect of Darkness</keywordPurple> <f7>operates as a secret society, only showing itsef rarely to potential members.
                It is favored by mages who practice dark magic, as well as assassins and others seaking the power of death.
                It also includes the <keywordPurple>The Council of Darkness</keywordPurple> consisting of an archmage from each school of dark magic.
                <br>Adminstrating the process of death and the collection of the souls are groups of ghosts and demons.
                <keywordPurple>The Silent Guides</keywordPurple> act as harvesters, pointing the way for new spirits. 
                More powerful <keywordPurple>The Pale Riders</keywordPurple> are used for resistant souls or particularly large events of death. 
                The most powerful are the <keywordPurple>Keepers of the Abyss</keywordPurple>, who guard and maintain the Soulfonts deep in the underworld.
                <br><keywordPurple>Communion</keywordPurple> with Morgeth is best acheived in palces of extreme death or even entering a death like state.
                </f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPurple' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Umbra
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPurple'>
                <keywordPurple>Umbra</keywordPurple> <f7> is the Favor of Morgeth.
                <br> <b>Gaining Umbra (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Umbra (Deeds):</b> Umbra is granted to those who further Morgeth's interests. This includes acts related to death, power, and the extermination of light.
                <br> <b>Losing Umbra:</b> Morgeth takes Umbra away from those who turn away from death. 
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astPurple' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecPurple'>
                <f7>
                <keywordPurple>Blasphemy</keywordPurple> is when Morgeth punishes his followers with Stress or Dread for going against the Doctrine.
                Morgeth deplores helping the forces of light, not embracing darkness, and fearing death.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astPurple'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <keywordPurple>Umbra</keywordPurple>. 
                    <br> <b>In a place with lots of death:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecPurple'>
            <div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 1</div> <b>Resurgence</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Check.
        </abilitysection><abilitysection class='asecPurple'>
            <div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 2</div> <b>Morgeth's Insomnolence</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>  <i>The darkness is but a window into the truth. Nightmares are messages from the night.</i>
            <br> May see additional 2 Spaces in Darkness. 
            <br> May both do Day Action and Rest that Day. 
            <br> May remove <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound and gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread that night.
        </abilitysection><abilitysection class='asecPurple'>
            <div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 3</div> <b>Whispers of Morgeth</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>The dark lord takes pity on your failing body. Your service is not yet finished. </i>
                <br> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue/Rot/Dying.
                <br> May also Remove additional <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rot/Dying and gain <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Purple-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordPurple>Umbra</keywordPurple> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Purple-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><keywordPurple>Umbra</keywordPurple> (Deeds)</div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Turquoise-4);'>
            <div>Touched by Xythuul <f7>Doctrine</f7></div>
        </rulecardtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astTurquoise' style='border-radius:4px 0px 0px 4px;'>
                Cultist  
            </abilitysubtitle>
            <abilitysection class='asecTurquoise' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/10<div style='display:inline; color:black; font-weight:800;'>AP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astTurquoise' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Initiation
                </abilitysubtitle>
            </div>
            <abilitysection class='asecTurquoise'>
                The <keywordTurquoise>Awakening of the Abyss</keywordTurquoise>.
                <br><f7>Involves being restrained and put through a ritual in a circle of madness. Potentially a draght or parasite may be forced inside the initiate.
                <div style='height:5px;'></div><b>When Gaining This Card:</b> Gain and 1 <b>SP</b> and an Insanity Aspect: 
                    <div style='display: grid; grid-template-columns: 1fr 1fr 1fr;'>
                        <div>Voices</div> 
                        <div>Staring Into the Void</div>
                        <div>Seizures </div>
                        <div>Delusional Paranoia* </div>
                        <div>Damaged*</div> 
                        <div>Not My Hand* </div>
                        <div>Forbidden Sight</div>
                        <div>Masochist </div>
                    </div>
                <b>*:</b> These may difficult and require working with the GM.
                <div style='height:5px;'></div> You cannot lose this Insanity by normal methods. If you would lose the Insanity or Doctrine, subtract 1 <b>SP</b> from your Character as well.</f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astTurquoise' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Info
                </abilitysubtitle>
            </div>
            <abilitysection class='asecTurquoise'>
                <keywordTurquoise>Xythuul</keywordTurquoise> <f7>is called the mad alien god.
                To worship Xythuul is to know madness, and the true name is unpronounceable and terible to hear.
                It is unknown where Xythuul comes from, but it is rumored he in unlike the other gods, and hails from a place outside time and space.</f7>
                <br><keywordTurquoise>The Cult of the Unspeakable</keywordTurquoise> <f7>is deeply hidden, though it is rumored to have intiates is many positions of power.
                It is unclear what their goals are, but said they wait for their god to come and claim this world in madness.
                Many join merely for the power this provides, but often ultimately are driven to madness and death in the pursuit.
                <br>Several lesser aspects or children of Xyhuul exist, which are almost regarded as tendrils of Xythuuls corruption into the world.
                Some names that are known are Shisugothoa, the bleeding corruption, Zyjujtrath, the gibbering colossus, and Xadrahedron, the devourer of stars, and other enties of madness and destruction.
                <br><keywordTurquoise>Covenant</keywordTurquoise> with Xythuul is best achieved through rituals of madness and places and times of great corruption.
                </f7>
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astTurquoise' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Delirium
                </abilitysubtitle>
            </div>
            <abilitysection class='asecTurquoise'>
                <keywordTurquoise>Delirium</keywordTurquoise> <f7> is the rejection of Favor from other gods, the Favor of the Abyss. Favor from the Unnamable creatures of Xythuul.
                <br> <b>Gaining Delirium (Prayers):</b> These are gained through the Pray Action.
                <br> <b>Gaining Delirium (Deeds):</b> Delirium is granted for acts of nihilism and the destruction of meaning itself.
                <br> <b>Losing Delirium:</b> Delirium is taken from those who promote meaning and sanity. 
            </abilitysection>
        </div>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'>
            <div style='display:grid; grid-template-columns:1fr; '>
                <abilitysubtitle class='astTurquoise' style='padding:3px; border-radius:4px 0px 0px 4px; display:flex; align-items:center; justify-content:center;'>
                    Blasphemy 
                </abilitysubtitle>
            </div>
            <abilitysection class='asecTurquoise'>
                <f7>
                <keywordTurquoise>Blasphemy</keywordTurquoise> is when Xythuul punishes his followers with Stress or Dread for going against the Doctrine.
                Xythuul deplores acting too sane, not embracing insanity, and any act that would prevent the consumtion of this world.
                </f7>
            </abilitysection>
        </div><div style='height:5px;'></div>
        <div style='display:grid; grid-template-columns:1fr;'>
            <abilitysubtitle class='astTurquoise'>
                Abilities
            </abilitysubtitle>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Pray</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                     Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordTurquoise>Delirium</keywordTurquoise>.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordTurquoise>Delirium</keywordTurquoise> if didnt sleep last night.
                    </div></challengeText></challengeContainer></div></actionContainter><abilitysection class='asecTurquoise'>
            <div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Delirium 1</div> <b>Distortion</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Check.
        </abilitysection><abilitysection class='asecTurquoise'>
            <div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Delirium 2</div> <b>Xythuul's Madness</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>Time and space are but unimportant variables in the non-ecludian equaitons of the new cosmos.</i>
                <br> Choose a number other than 5 or 6. That number counts as a Success instead of 5 or 6.
        </abilitysection><abilitysection class='asecTurquoise'>
            <div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Delirium 3</div> <b>Aberration of Xythuul</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <i>SsEnDaM sI hTuRt DnA hTuRt Si sSeNDaM. NoIsUlI nA TuB sI YtilAeR.</i>
                <br> Remove Mortal Wound or Infection. +1 Permanent Points to Insanity Meter.
        </abilitysection><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Turquoise-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/&nbsp;<span style='color:var(--Gray-2)'>3</span> <keywordTurquoise>Delirium</keywordTurquoise> (Pray)</div>
        </div><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Turquoise-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'><keywordTurquoise>Delirium</keywordTurquoise> (Deeds)</div>
        </div></rulecard></div><div id='Curses' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Curses</div></div>    </div>
    </body>
</html>