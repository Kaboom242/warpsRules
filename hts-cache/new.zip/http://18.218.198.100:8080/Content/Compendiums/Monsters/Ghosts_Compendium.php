<html>
    <head>
        <title>Ghosts Monster Compendium</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
            width: 100%;
        }
        .CompendiumInfoBox {
            position: fixed; 
            right: 0px;
            width: 250px;
            background: white;
            color: black;
            padding: 5px;
            border-radius: 4px;
        }
        .CompendiumHead {
            font-size: 16;
            font-weight: 700;
        }
    </style>
    <body style='background:hsla(0,0%,40%,1);'>
                  
        <div style='display: grid;grid-template-columns: 710px 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Poltergeists</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Poltergeist (Small)</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/chair.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Item
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				A weapon which is animated by a dark spirit, usually it's former owner still clinging on to this plane.
				They often have died violent deaths and bear a gruge against the world.
				<br><br>
				Poltergeists often come in groups and haunt or guard places such as old battlefields and other abadonded places.
				Poltergeists are foremd from the enrgy of death and are often associated with Morgeth.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Poltergeist (Small)</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Halbred
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>-</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                --
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Can be any number of small objects. Ex: Boxes, Mugs, Shields, etc.
    	            	Usually constrained to a given area to defend or haunt.
    	            	Will attack until enemy is dead, are destroyed, or target leaves area of effect.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            		<b>Inanimate</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rush</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Move <b>Pace +</b> <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> Spaces.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Smash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Extra Damage:</b> Add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg. Item takes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Poltergeist (Large)</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/cabinet.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Item
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				A weapon which is animated by a dark spirit, usually it's former owner still clinging on to this plane.
				They often have died violent deaths and bear a gruge against the world.
				<br><br>
				Poltergeists often come in groups and haunt or guard places such as old battlefields and other abadonded places.
				Poltergeists are foremd from the enrgy of death and are often associated with Morgeth.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Poltergeist (Large)</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Halbred
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 2</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>8</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>-</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                --
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Can be any number of small objects. Ex: Boxes, Mugs, Shields, etc.
    	            	Usually constrained to a given area to defend or haunt.
    	            	Will attack until enemy is dead, are destroyed, or target leaves area of effect.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            		<b>Inanimate</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<br> <b>Weak Area:</b> Add <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Dmg.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rush</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Move <b>Pace +</b> <sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> Spaces.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Smash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                        Aplies <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> <b>Collision Dmg</b>. 
                        <div style='height:2px;'></div> <b>Extra Damage:</b> Add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg. Item takes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Poltergeist (Weapon)</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Poltergeist.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Weapon
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				A weapon which is animated by a dark spirit, usually it's former owner still clinging on to this plane.
				They often have died violent deaths and bear a gruge against the world.
				<br><br>
				Poltergeists often come in groups and haunt or guard places such as old battlefields and other abadonded places.
				Poltergeists are foremd from the enrgy of death and are often associated with Morgeth.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Poltergeist (Weapon)</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Sword
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR2</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>5</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Halbred
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>-</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                --
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Will be one of the weapons below. 
    	            	Usually constrained to a given area to defend or haunt.
    	            	Will attack until enemy is dead, weapon is destroyed, or target leaves area of effect.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            		<b>Inanimate</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Rusty Sword 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Edged Weapon</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'> <cb><b>Bypass</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword></cb></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Rusty Halbred 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Spear</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display: flex;'><b style='color: black;'>OR</b> <div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword> <sc>6 Dmg:</sc> Sever</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display: flex;'><b style='color: black;'>OR</b> <div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Pin <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <cb><b>Threaten</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></cb> <cb><b>Bypass</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display: flex;'><b style='color: black;'>OR</b> <div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 2
    </div>, <sc>6 Dmg:</sc> Break</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Ghosts</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Wraith</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Wraith.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				A ghosty presence clinging to this plane through pain and hate.
				They tend to be drawn or connected to places with a dark history, and will attack those who come within their reach.
				They also sometimes act a servants, often unwillingly, to some dark wizards or the power of Morgeth.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Wraith</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 4</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>7</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>4</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Use <b>Claws</b> to attack and <b>Screech</b> drain their Target's Stamina. Will use <b>Regenerate</b> when at low health.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>*Spectral Body:</b> <b>DR1</b> against all Dmg other than Light and Energy.
	            		<br><b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> May move through matter/Characters as Slow 1.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Claw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Regenerate</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Harm.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Screech</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><u>Target Resist 2 Terror</u> w/ <b><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></b>.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Spirit</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/spirit.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				A ghosty presence, an ethereal point of light. Thier connect to the world is transient. 
				Passing through walls, aimlessly wandering, found in heavy fog, deep forests, swamps, and graveyards
				often seen in areas that have seen lots of death, like old battlefields or shrines of Morgeth.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Spirit</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 2</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>6</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>3</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	When at range Zap, and move closer to target. Then Enter target and attempt possesion. 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>*Spectral Body:</b> <b>DR1</b> against all Dmg other than Light and Energy.
	            		<br><b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> May move through matter/Characters
	            		<div style='height:1px;'></div> Light Weaknees +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to turning actions aginst Spirit 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Zap</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Spirit</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Terror 2</b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ether Body</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>-1 Stamina, +1 Harm</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Incorporeal</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Turn Invisible, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Dodge this round. Reapear in <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> rounds, at random location. Can only Breath/Recover</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Possession</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Purple-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Once Possession attempt has been started, it must be done every round.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div></sbi></sb> vs<br> Target's <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <fc>Lose:</fc> use <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>
                        <br><sc>Win 1S:</sc> Prevent Targets Actions.
                        <br><sc>Win 2S:</sc> Enter Target. May Control Possessed Target starting next round. Can't be hit with physical attacks.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	<b>Possessed Target:</b> Every Round: <u>Resist 1 Dread</u> w/ <b><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></b>. Can't choose Actions. 
    	            	    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <cs>1S:</cs> Spirit Loses 1 Stamina
    	            	    <cs>2S:</cs> Make actions <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>
                            
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Control Possessed Target</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Preform simple Action (Attack,Dodge,Move). If out of Stamina exit the body. Ignore Target's Weak Status.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Shade</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/ShadeGhost.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
            <f8>
				A ghosty presence, a shadow of a person. Thier connect to the world is transient. 
				 Rarely seen, when they are glimpsed its only an humoid shadow on the wall. There presense and malice can be felt.
				<br><br> Stalks dark halls, haunting a small area/house. Found at places of grissly murders, or Rituals to Morgeth. 
				<br> They are a formitable presence that must be excised for the living to be free of torment.
			</f8>
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Shade</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Dire</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Pace:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR2*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>1</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>4</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	 Lurks in the shadows unnoticed doesn't like to start fights unless prevoked. When prevoked will jump scare. Will try and single out a target rend soul. Loses intrest in fight easily. 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>*Spectral Body:</b> <b>DR2</b> against all Dmg other than Light and Energy.
	            		<br><b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> Invisible in darkness, Casts a shadow.
	            		<div style='height:1px;'></div> Light Weaknees +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to turning actions aginst Spirit 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Scare</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cone&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Terror 3</b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'> <cb><b>Bypass</b> <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword></cb></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Rend Soul</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>1 Dread Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
	                <br> <keyword>Bleed 3</keyword> 
	                <br> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Chance to inflict Rend Soul Curse</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Info: <br>Rend Soul<br> Curse</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><i>You have an black everlasting wound on your torso.</i>
	                    <br> Once per day Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Torso Rend Bleed damage, can go into Harm and doesn't go way after combat. 
	                    <br> All Rend Bleed damage can be removed like wounds.
	                    <br> To remove Rend Soul Curse, a priest must patch your wound with the Ichor of the Gods,
	                        ussually requring a ritual at an alter as close as you can get to the heavens.
	                </div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Banshee</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/BansheeGhost.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				This lonely ghost can be heard wailing in the middle of the night. Thier screams are said to have magical properties. 
				Banshees are offten heard long before being seen.
				<br><br>
				
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Banshee</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>5</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 4</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>8</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>1</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>8</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	When 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>*Spectral Body:</b> <b>DR1</b> against all Dmg other than Light and Energy.
	            		<br><b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> May move through matter/Characters easily
	            		<div style='height:1px;'></div> Light Weaknees +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to turning actions aginst Spirit 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Wailing Shriek</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>All in <img 
        src='/Resources/Art/Images/Hexagon_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Terror <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Incorporeal</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Turn Invisible, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Dodge this round. Reapear in <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> rounds, at random location. Can only Breath/Recover</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Shrill Shriek</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Alll in <img 
        src='/Resources/Art/Images/HexagonW_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> have <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Fly Through</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div><img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 3</b>, <b>Stress <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Long Wail</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Line <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 4</b> <b>Stress <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, if target failed to resist Stress, can't Act.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Revenant</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/RevenantGhost.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				The rattle of chains, flashes of light and fire. Thier screams ring out. 
				Phantoms are damned spirits that have broke free of morgeths grasp.
				<br><br>
				
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Revenant</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Dire</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>5</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Float:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>8</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>6</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>6</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Whip and Phantasmal Chains everyone. When its close to Morgeth's Damnation will open Morgeth's Phantasmal Flaming Maw. 
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>*Spectral Body:</b> <b>DR1</b> against all Dmg other than Light and Energy.
	            		<br><b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> Light Weaknees +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to turning actions aginst Spirit 
	            		<div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May do a second Full/Active Action.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Wailing Shriek</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>All in <img 
        src='/Resources/Art/Images/Hexagon_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7>Can use once per Combat.</f7></b>
                        <br><b>Terror <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Chain Whip</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj<img 
        src='/Resources/Art/Images/Hexagon_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, (Ignore walls)</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Spirit</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 2
    </div>, <b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Phantasmal <br> Chains</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj<img 
        src='/Resources/Art/Images/Hexagon_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, (Ignore walls)</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div><f7>Body area becomes Chained by ethereal chains. Deals <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg per turn.<br> Target <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <sc>2S</sc> Escape.</f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Chain Drag</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>
                        <b>All chained targets:</b> <b>Terror <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        <br>Pull targets in any direction <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Int
    </div> Plus <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> per chain attached, Spaces. Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                        </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <f8>Morgeth's <br> Phantasmal <br> Flaming Maw</f8></div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>
                        Open a maw in reality connecting to the world of spirits. 
                        <br> Place a Maw down on a hex, within 3 Hexes.
                        <br> Every turn Characters on a Maw, Buring 1 on Random Body Area. Resist <b>Dread <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></b> w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Morgeth's Damnation</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                    First time Banshee takes wounds, recover all stamina
                    <br> Remove <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> harm, 
                    <br> Attack all Characters within 2R with Phantasmal Chains.
                    </f7>
                    </div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 696.932px 5px 696.932px;grid-auto-flow: column;background:white;height: 489.736px;grid-gap: 0px;align-items: stretch;grid-column: auto / span 3;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Harbinger</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Ghost</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Harbinger.jpeg' style='height:450px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>1S:</sc> </b>Apparition
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:;  padding:1px 2px 1px 2px;'>
                Extremely powerful spirirts that roam this plain, often seeking and collecting souls for their own ends.
                They can be the former servents of a powerful necromancer, or those cursed for their use of exremely dark magic.
                They will not only seek to defeat those they come in contact with but collect their souls as well.
                Overall these creatures are extremely dangerous and should only be faced by those well prepared.
			
            </div>
        </div>
        </div></div><div style='border-style:solid; border-width:1px; border-color:black; position:relative; top:0px; background:white;'></div><div style='display:grid;grid-template-rows: 16px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Harbinger</b></div><div style='font-size:13px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Epic</div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr 1fr;grid-auto-flow: column;background:none;grid-gap: 4px;'><div style='display:grid;grid-template-rows: 80px auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows:auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:0px 4px 4px 0px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>7</b></div>
        </div>
        <div style='display:grid;grid-template-rows: 1fr 1fr;grid-template-columns: 1fr 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'>
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    </div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b>
                        <div style='padding-top:1px;'><sc>1S:</sc> Apparition
							<div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Pace:</keyword> 3</div>
						</div>
						</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>DR1*</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>20</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 1;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div></div><div style='grid-row: auto / span 1;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
    	            	Will use <b>Dark Sword</b> as the primary attack while charging up for Umbra Abilities w/ <b>Dark Channel</b>.
	            	    <br> <b>Drop:</b> <b>Cursed Blade</b>.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Long Sword with <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 1
    </div>, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg, +1 Bleeding, and +1 <div style='display:inline; font-weight:700;'>DR</div>.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread each Day it is carried.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Physique</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    <b>Spectral</b> (Immune to Stress, Air Loss, Bleeding, etc.)
	            		<div style='height:1px;'></div> May move through matter/Characters as Slow 1.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Mount</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    May Mount/Unmount Spectral Horse as Active Action.
	            	    <br>While Mounted it's Pace is 6, but cannot use Umbra Actions other than <b>Phase</b>.
	            	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Consecrated<br>Ground</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    May fight near Consecrated Ground. This is ground either blessed by Azeal or similar entity or similar protections.
	            	    <br>If in Consecrated Ground, Harbinger has no DR and attack against do +1 Damage.
	            	</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Dark Sword 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Edged Weapon</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>*</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/4</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/3</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash (Corruption) <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 1
    </div>*</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 2</div> Dark Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash (Corruption) <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 3
    </div>*</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;    ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
		                    <b>Corruption:</b> Dmg caused by Corruption should be marked with a 'C' can only be removed as Wounds.
		                    <br><b>Corruption Sickness:</b> Caused by 7 or more Corruption.
		                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Illness every Day until having less that Corruption.
		                    <br><b>*Energy Blade:</b> Can only be Damaged by Light Energy Attacks. <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 
    </div> does not effect Blessed Armor.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='padding:0px 1px 1px 5px; margin:0px -3px 0px -3px; background:var(--Purple-3); color:white; font-weight:700; font-size:9px; display:flex; align-items:center;'>Umbra</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Regenerate</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Lose 1 DR. <cs>1S:</cs> Remove 1 Harm.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Death Screech</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        All Targets in <img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> <u>Resist 2 Stress</u> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                        <div style='height:2px;'></div> For each point not Resisted gain +1 <div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra</div>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Dark Channel</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div> <cb><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Twice)</cb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> +1 <div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra</div>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 2</div></f7><br>Dark Freeze</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b><br><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Win:</b> Target is in Dark Freeze <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                                <br><b>Dark Freeze:</b> Cannot Move or Act.
                                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <u>Resist 2 Terror</u> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> each Round.
                                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Remove w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 1</div></f7><br>Dark Pull</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div> vs Target <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>For each Success over Pull Target toward you 1 Space.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 1</div></f7><br>Dark Mist</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Cricle <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> has Visibility 1 for remainder of Combat.
                                <br> Enemies inside Mist must Resist 1 Terror w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Umbra 3</div></f7><br>Stare of a<br>Thousand Dead</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    	<div style='display:grid; grid-auto-flow:row; grid-gap:5px; width:100%; font-size:9px;'>
                            <div style='display:grid; grid-template-columns:1fr; grid-gap:2px;'>
                                <div style=''>
                                    <u>Target Resist 6 Mind Control</u> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                                    <br>For each Mind Control get +1 Dread.
                                    
                                    <br> <b>Mind Control:  Remove <f7>Free</f7></b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                                    <br> Harbinger controls you. You are uneffected by Weak.
                                </div>
                            </div>
                        </div>
                	</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Ghost / Cursed Pirates</div></div>    </body>
</html>