<html>
    <head>
        <title>Elf & Dwarf Compendium</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
            width: 100%;
        }
        .CompendiumInfoBox {
            position: fixed; 
            right: 0px;
            width: 250px;
            background: white;
            color: black;
            padding: 5px;
            border-radius: 4px;
        }
        .CompendiumHead {
            font-size: 16;
            font-weight: 700;
        }
    </style>
    <body style='background:hsla(0,0%,40%,1);'>
                  
        <div style='display: grid;grid-template-columns: 710px 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Elf</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Standard Elf</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Elf</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/ElfArcher.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            A normal Elf. Most keep to themsleves and often live in nature or elf communities.
	            Almost all are trained in the basic use of the bow.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Standard Elf</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<b>*:</b> Some Stats may be a 2 or 3 if appropriate.
                		<br> Some common weapon types a Human may have such as Knife and Bow are listed below.

                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Notice Checks.
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Bow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+5 Arrows</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Active</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.<br><f7>Any other Action will require you to Nock the arrow again before firing.</f7></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife/Throwing</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Elf Ranger</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Elf</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/ElfRanger.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Armed Elves can be found guarding Elf communities or ranging through the forests.
	            While most elves are not hostile toward humans, many will fight to protect nature in the name of Ernok.
	            Some Elves might even be acting as bandits or raiders in particularly tough times, and those that do will be particularly hostile towards humans.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Elf Ranger</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<b>Drop:</b> Treasure D x1
                		<br> Some common weapon types a Elf may have such as Knife and Bow are listed below.

                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Notice Checks.
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Bow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+10 Arrows</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Active</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.<br><f7>Any other Action will require you to Nock the arrow again before firing.</f7></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Dagger 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Leather Vest 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Light Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>0 <mini>All</mini> 1 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>3</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Dwarf</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Standard Dwarf</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Dwarf</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/DwarfStandardA.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Most Dwarves work as miners or tradesman in Dwarf mining settlements, though some can be found engaging in trade with the surface world.
	            Dwarves highly value precious metals, and are well known for their excellent craftmanship.
	            When dealign with humans they tend to be shrewd, but can be friendly as well after a certain amount of familiarity.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Standard Dwarf</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>2</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<b>*:</b> Some Stats may have a 2 or 3 if appropriate.
                		<br> Some common weapon types a Human may have such as Hammer and Pick-Axe are listed below.

                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		Sink 1 in Water. Dark Vision 1R.
                		<br> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>: +1 Pace.
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Hammer 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>5</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Thrust</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bypass:</keyword> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Pick-Axe 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>5</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Strike</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bypass:</keyword> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Bleed 1
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Dwarf Warrior</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Dwarf</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/DwarfWarrior.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Dwarven warriros are extremely proud and ready to fight anytime their honor is threatened.
	            Most work for dwarven armies or guardsman, though some hire out their serveces to the highest bidder.
	            They take very good care of their axes, and wear hand crafted armor.
	            While not fighting, they enjoy spending their time in alehouses, where sometimes even more fighing occurs.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Dwarf Warrior</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>2</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <b>Drop:</b> Treasure D x1
                		<br> Sink 1 in Water. Dark Vision 1R.
                		<br> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>: +1 Pace.
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Axe 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>4</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Thrust</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Bleed 2, <cs>6 Dmg:</cs> Sever
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Round Shield 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Shield</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>8</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block (Ranged)</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Proj/Blast</keyword></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Scale Mail (Long) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Med Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <mini>All</mini></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso + Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Left Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: 1fr 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Right Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div></div>    </body>
</html>