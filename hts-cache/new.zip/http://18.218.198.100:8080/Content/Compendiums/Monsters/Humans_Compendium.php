<html>
    <head>
        <title>Human Compendium</title>
        <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
    </head>
    <style type="text/css">
        body {
            width: 100%;
        }
        .CompendiumInfoBox {
            position: fixed; 
            right: 0px;
            width: 250px;
            background: white;
            color: black;
            padding: 5px;
            border-radius: 4px;
        }
        .CompendiumHead {
            font-size: 16;
            font-weight: 700;
        }
    </style>
    <body style='background:hsla(0,0%,40%,1);'>
                  
        <div style='display: grid;grid-template-columns: 710px 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Standard Human</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/StandardHuman.jfif' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            A normal Human. He or she may be a peasant, a merchant, a noble, and many things in-between.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Standard Human</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1*</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<b>*:</b> Most Humans have 1 for their Stats, though some may have a 2 or 3 if appropriate.
                		<br> Some common weapon types a Human may have such as Knife and Club are listed below.

                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Club 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>5</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Thrust</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bypass:</keyword> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife/Throwing</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Bandit</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Bandit</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Bandit.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Typical Bandit you can find all over Urdun. In cities that may try to pickpocket or ambush people in dark alleys.
	            In the winderness they will attempt to rob passersby.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Bandit</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    	Will try to steal and run if possible. If working as a group will flee if at as disadvantage.
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife/Throwing</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Bandit Archer</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/BanditArcher.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				Bandits found in forests and other wilderness areas, will often be equipped with bows, allowing them to ambush their targets at distance if possible.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Bandit Archer</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> Main Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> Off Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Pace:</keyword> 3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    Will try to stay in cover as long as possible, shooting from a unknown postion if they can.
	            	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Bow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+5 Arrows</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Active</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.<br><f7>Any other Action will require you to Nock the arrow again before firing.</f7></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Edged Weapon</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cb><b>Bypass</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Bandit Leader</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/BanditLeader.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            A particularly dangerous criminal, he often leads of pack of lesser criminals into battle.
	            He or She will often be fearless but cunning and with an easy charm that inspires those around them.
	            With no shortage of bravery, the will often seek of the most fearsome of their opponants to fight.
	            If victorious, they will rob the victim, and those who are particularly ruthless will even sell their victims into slavery or have them killed.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Bandit Leader</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    	Will alternate between Sword and Bow depending on what's most appropriate. Will flee if at as disadvantage.
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Lead</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>All Allies gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha 3
    </div> Will.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Sword 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife/Throwing</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <cb><b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dex
    </div></cb>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb><div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Bow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+5 Arrows</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Active</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.<br><f7>Any other Action will require you to Nock the arrow again before firing.</f7></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Leater Vest 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Light Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>0 <mini>All</mini> 1 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>3</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Man-at-arms</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Man-at-Arms</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Guard.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Standard Man-at-Arms employed for various reasons.
	            <br><br>
	            Trained to fight competently, but not especially brave or steadfast. Will often flee if the battle turns against them or if they feel a job is beyond their paygrade.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Man-at-Arms</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>0</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		Will take and attempt to hold a defensive postion if possible. Otherwise will approach cautiously and in group formations. <b>Drop:</b> Treasure E x1
                		<br><b>Horsed</b> 
                		<br>&nbsp;&nbsp; <b>Pace:</b> 4, <b>Dodge (Horse/Man):</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <b>Range:</b> Torso/Head 1 Space above.(Range 1 to Hit.)
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Spear 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Pole-Arm</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Thrust</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Threaten</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> vs Target <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'> <b>Win:</b> Loser chooses Abort Attack OR You get +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit</f7></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bypass:</keyword> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed 1</keyword>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div><f8>Chain Mail (Long)</f8> 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Med Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <mini>All</mini> 2 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso + Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><sc>Legs 1S:</sc> Ignore Armor</div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Left Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: 1fr 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Right Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div><f8>Chain Mail Hood</f8> 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Med Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <mini>All</mini> 2 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Head</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><sc>1S:</sc> Ignore Armor</div></div></div></div></div></div></div></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Crossbowman</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Crossbowman.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
				Bandits found in forests and other wilderness areas, will often be equipped with bows, allowing them to ambush their targets at distance if possible.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Crossbowman</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Normal+</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> Main Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> Off Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><div style='font-size:10px; text-align:left; padding-left:8px; font-weight:600;'><keyword>Pace:</keyword> 3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	            	    Will try to stay in cover as long as possible, shooting from a unknown postion if they can.
	            	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Crossbow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+7 Bolts</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Active</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b>, <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 
    </div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.<br><f7>Any other Action will require you to Nock the arrow again before firing.</f7></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Edged Weapon</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cb><b>Bypass</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Gambison (Long) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Light Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>0 <mini>All</mini> 1 Bash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso + Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>3</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><sc>Legs 1S:</sc> Ignore Armor</div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Left Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: 1fr 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>2</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Right Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>2</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Pirate</div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Fighters</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Mercenary</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/Mercenary.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            Mercenaries are common throughout Urdun, mostly congregating in the seedier part of large cities.
	            They offer to take on any job, though for a steep price. Some going so far as to extory their clients.
	            Despite their often cavalier nature, they are very good at what they do, capable of completing all kinds of violent and dangerous jobs.
	            Though most end up spending their money on wine before needing to go fnd another job.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Mercenary</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<f7>
                    		<b>Tactics:</b> Uses <b>Read Battle</b> to raise Edge Level which isused to enhance Attack.
                		</f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
	                	<f7>
    	            		Can Attack and Block with same Weapon.
                		</f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Read Fight</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> <b>+</b><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div>. Each Edge can be used for +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit/Dmg/Defend/Grapple.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Long Sword 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Sheild</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cb><b>Bypass</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword>  <cb><gc>7 Dmg:</gc>Sever</cb>
	                    			<cb><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keyword>Bleed</keyword></cb></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 75px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;    ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div><f8>Leather Armor</f8> 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Light Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>0 <mini>All</mini> 1 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>3</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Main Arm</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>2</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Showdown</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Can use only if you + Target are Melee Attacking each other.</b></f7>
                    <br>Choose <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge Vs. Target.
                    <br><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> You and Target may add <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> or <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> to Check. (Your choice.) 
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                        <b>Win:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg. <b>Tie:</b> You and Target get +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                        <div style='height:1px;'></div><b>Lose:</b> Target has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                    </f7></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Mountain Clans</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Barbarian</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/BarbarianHuman.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
            <f9>
	            Many men of the mountain clans adopt of style of fighting based on stregnth, power, and ferocity.
	            Battle rage makes them stronger and more durable then most orginary men, and they have a battle scream which unerves most mortals.
	            <br><br>
	            Most Barbarians are deeply faithful to Tyrannus, and will make blood sacrifices after a battle, often using captives.
	            They are not without honor however, and respect strength, bravery, and martial prowess.
	            They can make loyal freinds and allies if trust is obtained.
	        </f9>
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Barbarian</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                        May set an ambush, but often jsut charge into battle using Tough and Double Attack to overpower their foes.
                        Taking Damage gives them Rage making them stronger. Will occasionally use Blood Scream to intimidate foes.
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Tough:</b> Gain up to <sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> this Round.
                		<div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Double Attack:</b> Attack with 2 Weapons this Round.
                		<div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Blood Scream:</b> Contest <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. <sc>1S:</sc> Target gain 1 Stress.
                		<div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Tyrannus's Toughness:</b> Ignore Disabled.
                		<div style='height:2px;'></div><b>Rage:</b> When Barbarian takes Damage he grows stronger and more fierce.
                		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Rage L1:</b> 1 or more Vital Wound, gain <b>DR1</b>, +1 Pace, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Melee Dmg.
                		<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Rage L2:</b> 3 or more Vital Wound, gain <b>DR2</b>, +1 Pace, +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Melee Dmg.
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Enrage</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                        <sc>1S:</sc> +1 <b>Rage</b>.
                        <br> Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr 2
    </div>.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Axe <f8>(1 Main Arm, 1 Off Arm)</f8> 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>4</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Strike</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <keyword>Bleed</keyword> 2, <sc>6 Dmg:</sc> Sever.
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                        +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Remove Fatigue when Sleeping or Resting.
                        <br>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Fatigue for Physcial Labor and Travel.
                        <br>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Exposure.
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Hunger/Thirst/Sleep.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Vikings</div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Martial Humans</div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Criminals</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Theif</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/TheifHuman.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	            A highly trained theif is an expert and stealing, sneaking up on foes, and evading damage.
	            They may be hired for candelstine jobes, work as part of a team, or indepently.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Theif</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                        <f7>Will start attack with a Sneak Attack whenever possible (typically creatign a couple of Stealth vs Notice challenges.)
                        After that will Flee once objecitve is commplete using terrain against pursues if possible. 
                        Will use Flanking and Sand Dodge to get an advantage whenever possible.</f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skills</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		<b>Rogue Reflexes:</b> Sneaking/Hiding/Stealing/Acrobatics Checks have lower Difficulty.
                		<br><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Double Attack:</b> May attack with two Knife type weapons this round.
                		<br><b>Flee (Active):</b> Reduce Strike/Proj by +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.
                		<br><b>Flanking:</b> Gain +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, Bypass, and Dmg. (In addition to standard +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.)
                		</f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><b>Sneak Attack</b> occurs when attacking a Target unaware of you.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f7><sb><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div></sbi></sb> <b>vs</b> <div style='height:2px;'></div> <b>Target</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></f7></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>
                        <sc>1S:</sc> Grapple+Muffle. Attack w/ +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit/Dmg/Bypass.
                        <br><sc>1S:</sc> May take non Held/Worn Item.
                        </f7>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Sand Dodge</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                        May attempt once per Combat. Target must be attacking you. +<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
                        <div style='height:1px;'></div> <img 
        src='/Resources/Art/Images/HexagonW_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><b>Contest</b> <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div></sbi></sb> <b>Win:</b> Target is Blind 1, Remove w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                    </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Throwing Knife (10) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Stab</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bypass</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <cs>1S <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</cs> Pin to Surface</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash/Peirce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed</keyword> 1
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bypass</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <cs>1S <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</cs> Pin to Surface</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash/Peirce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed</keyword> 1
                        </div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Pin to Surface</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    	<f7>Must be near surface. Taget may remove Dagger (Active, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg and Bleed 2) or Pull Out (Free, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bleed 2)</f7>
                    	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Leather Vest 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Light Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>0 <mini>All</mini> 1 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>3</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Church</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Cleric</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/ClericHuman.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	             Clerics are agents of the Chrch of Azeal.
	             They see furthuring Azeal's goals as a sworn duty, whether his is protectign the weak, or burning sinners alive.
	             Clerics are also skilled healers, if convinced that helping is would gain Azeal's Favor.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Cleric</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		Clerics use their mace in combat, oftenc charged by a <b>Smite</b>. For allies <b>Bless</b> and <b>Healing Light</b>.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Bless</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Ally Mend <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> OR +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Check.
                        <div style='height:2px;'></div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><b>Smite</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg you are doing and, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Burning (+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Target is Vile.)
                        <div style='height:2px;'></div> <b>Healer:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Heal and Ally Resist Death.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Healing Light</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b>Circle 2</b> Ally's Mend <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. You Mend <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Blinding <br> Light</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Yellow-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>. (Misses if doesn’t hit head w/ eyes.)</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Yellow-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Holy</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='text-align: left; font-size:7px;'> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>. (+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Vile Creatures).
                        <br> <b>Blind</b> <sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>. Remove (Free) w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> </div></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Mace 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>4</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Strike</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Pink-4);'>Str</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed 1</keyword>, <div style='display: inline-block;background: var(--Gray-1);color: black;font-weight: 800;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;'> 
            ArPen 
    </div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, <cs>6 Dmg</cs> Break
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Unified Cross 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Hafted</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>4</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Turn</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Sight <img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> vs Target <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Stamina Loss</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div><f9>Chain Mail (Long)</f9> 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Med Ar.</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <mini>All</mini> 2 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Head</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><sc>1S:</sc> Ignore Armor</div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso + Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><sc>Legs 1S:</sc> Ignore Armor</div></div></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Mages</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Blast Mage</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/BlastMageHuman.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	             A Blast Mage is specialized in the types of Red and Blue Magic which can be used for highly damaging effects.
	             They are usually trained at the Academy, and serve it. But they may also serve their own interests.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Blast Mage</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		<b>Incant</b> to power up a Spell which is the unleashed. May add <b>Overcharge</b> to increase effect.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                	    <b>Cast (Full):</b> May cast Spells below as Full Action.
                		<div style='height:1px;'></div><b>Overcharge</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Increase any Cast Check by <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. <sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>.<fc>0S:</fc> <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Casting Arm.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Incant</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>. <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <cs>1S:</cs> +1 <b>Arcanum</b>.
                        <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May move Pace.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Arcane<br> Missile <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum</div></f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Shoot&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>
                        <sc>1S:</sc><b>+</b><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>.
                        <br> <cs>1S:</cs> Goes around corners andtthrough allies.
                        </f7>
                        </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Fireball <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum</div></f7><br><f7>1 Ready</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Shoot&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc><b>+</b><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                        Burning <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Lightning<br> Bolt <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum</div></f7><br><f7>1 Ready</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Shoot&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc><b>+</b><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                        <f7>
                        <b>Target</b><div style='height:2px;'></div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>  
                        </f7>
                    </div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                        <b>Electrocuted</b> <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> and Pace 1. <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Remove</b> <i>Free</i> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                    </f7>
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                        <f7>
                        <b>3 Enemies within 3 of Target:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb>    
                        </f7>
                    </div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                        <b>Electrocuted</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Ice Wind <br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Arcanum</div></f7><br><f7>1 Ready</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cone 4</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7>
                        All Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Int);'>Int</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> Frozen w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                        <br> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Ice Blast Dmg.
                        <br> <b>Frozen </b> <b>1-3:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> Pace 1. (0 if already 1). <b>4-6:</b> Can't Move/Act.
                        <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Remove</b> <i><f7>Active/Free <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f7></i> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                    </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Arcane Staff 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Magic Implement</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>4</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Other Classes</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Bard</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/HumanBard.jpg' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	             Bards are talented musicians who typically trvel the land looking for inspiration and to make money with their songs.
	             Their connection to the god Yavarra grants them the ability to war reality through song, which they can use in combat to enhance their allies or hinder their foes.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Bard</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		Will use <b>Play</b> to buff allies through <b>Will Song</b>. Will attempt <b>Taunt</b> to make it difficult for a Target, and <b>Noise Blast</b> to repell attackers.
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Play</div></div> <actionSubtitle style='margin-left:3px;'>Full/<br> Active<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Turquoise-4);'>Cha</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>
                        <b>Will Song: Circle 3</b>
                        <br><cs>1S:</cs> An Ally may add +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Check OR +1<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> this Round OR Remove 1 Terror.
                        <br><cs>3S:</cs> Ally get <div style='display: inline-block;background: var(--Green-3);color: white;font-weight: 700;font-size: 8px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding: 0px 2px 0px 2px;'> Success 4/5/6</div>. All foes gain <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stamina Loss.
                        <div style='height:2px;'></div> 
                        <b>OR</b>
                        <div style='height:2px;'></div>
                        <b>Taunt: Circle 4</b>
                        <br><cs>1S:</cs> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Target's Check. They must attempt to attack you next round or Resist 1 Stress w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                        <br><cs>3S:</cs> Target's Check fails. Target gains <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha 3
    </div> Stamina Loss.
                        <div style='height:2px;'></div> 
                        <b>OR</b>
                        <div style='height:2px;'></div>
                        <b>Noise Blast: Semi Circle 1R (Foe's Only)</b>
                        <br><cs>1S:</cs> <b>Hex 4-1R:</b> Lose 1 Pace.
                                        <b>Hex 0-3:</b> Push 1S+<sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb> Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>.
                        <br><cs>3S:</cs> All foes in Range Move back 5 Spaces Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>. <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Collision Damage. 
                        </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Knife 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Edged Weapon</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cb><b>Bypass</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 1</keyword></div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Hearten/Travel Song</div></div> <actionSubtitle style='margin-left:3px;'>Meal/Travel Add On</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>May do once per Day. <br> <cs>1S:</cs> An Ally gains +1 Morale.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto 1fr;grid-auto-flow: column;background:white;width: 706.35px;height: 499.154px;grid-gap: 2px;align-items: stretch;'><div style='display:grid;grid-template-rows: auto 215px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Druid</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/druidhuman.png' style='height:200px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:25px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:25px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:10px;  padding:1px 2px 1px 2px;'>
	             Druids have a deep connectio to nature and typically live deep within the woods or other areas far away from civilization.
	             They care deeply about protecting the environment, and will fight for it if needed.
	             Almost all Druids worship Ernok, the God of Nature, from which they gain their power.
			
            </div>
        </div>
        </div></div><div style='border-style:none none none none; border-width:2px; border-color:black; position:relative; top:4px; background:black;'></div><div style='display:grid;grid-template-rows: auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;padding: 1px 2px 1px 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Druid</b></div><div style='font-size:11px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Hard</div></div>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>1</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto  auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'><div style='display:grid;grid-template-rows:auto auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:52px 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:4px 0px 0px 4px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>5</b></div>
        </div>
        
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    <div></div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    Will <b>Summon</b> and <b>Command</b> creature from nature to help the in combat, then use Communions such as <b>Undergrowth</b> or <b>Poison Spore</b> to weaken the enemy.
                	    If pressed, hey will transfrom using <b>Aspect of the Wolf</b> and fight their enemies directly via their <b>Claws</b>.
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Summon</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Turquoise-4);'>Cha</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <cs>1S:</cs> +1 Summon Point. (Culmulative)
                        <br> <f7>Animal will fight until disabled or critically wounded.
                        <br> <b>1 Summon Point:</b> Snake, Boar, or similar. 
                        <br> <b>2 Summon Points:</b> Wolf or similar. 
                        <br> <b>3 Summon Points:</b> Bear or simlar</f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Command</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Full:</b> <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Turquoise-4);'>Cha</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>
                        <div style='height:4px;'></div> <b>Active:</b> <sb><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <cs>1S:</cs> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Summon's Check.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Undergrowth</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 2 Stamina Loss w/ <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>. <f7>4 if no plants near Area.</f7>
            		<br> Create Circle 1 within 1R for 3 Rounds. All enemies inside are Slow 2.
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Poison Spore</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                		Resist 1 Samina Loss <div style='height:2px;'></div> w/ <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>
                		Cone 2
                    </div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                		<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Green-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		 Target Resist 3 Poison w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Mist Cloud</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 2 Stamina Loss w/ <sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>. Resist 3 if in a dry area.
		            <br> Create 1R Circle of Mist around you for 4 Rounds. 
		            <br> Visibility 1 in Mist. Hits in Mist are <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter><div style='padding:0px 1px 1px 5px; margin:0px -3px 0px -3px; background:var(--Red-3); color:white; font-weight:700; font-size:9px; display:flex; align-items:center;'>
            Aspect of the Wolf &nbsp;&nbsp;&nbsp; <f8>Transform: Full</f8>
        </div><div style='display:grid; grid-template-columns:auto auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    <f7>
                		<b>+1 <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='height:1px;'></div> +1 <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='height:1px;'></div> +1 Pace.</b>
                        </f7>
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Claw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div><f8>Strike</f8></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Bleed 2</keyword></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Red-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May Claw twice, once per Hand.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'>Epic Humans</div><div style='display: grid;grid-template-columns: 1fr;grid-template-rows: 1fr;grid-gap: 8px 8px;grid-auto-flow: row;'><div style='width:90%; display:grid; grid-gap:2px; grid-template-columns:auto;'><div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 696.932px 5px 696.932px;grid-auto-flow: column;background:white;height: 489.736px;grid-gap: 0px;align-items: stretch;grid-column: auto / span 3;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: auto 1fr;grid-auto-flow: column;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:flex; align-items:center; background:black; color:white; border-style:solid; border-width:1px; border-color:black; font-size:20px; text-align:left; padding:2px 5px 2px 5px;'><div>
            <b>Prince Of Theives</b>
        	<div style='display:inline; font-size:10px;'>&nbsp;&nbsp;<b>Human</b></div><div style='display:inline-block; position:absolute; bottom:4px; right:4px; font-size:10px;'>&nbsp;&nbsp;v2.0</div>
        </div></div>
        </div>
        <div style='display:flex; align-items:center; justify-content:center; background:white; color:white; border-style:solid; border-width:1px; border-color:black; padding:1px'>
            <img src='/Content/Art/PrienceOfTheives.jpg' style='height:380px; width:auto;'>
        </div>
        </div><div style='display:grid;grid-template-rows: auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:none;grid-gap: 2px;'>
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Hitbox</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:14px; padding:1px 2px 1px 2px;'>
    <div style='font-size:15px; 
    display:grid; grid-auto-flow:row; grid-template-columns:1fr; grid-template-rows:auto 1fr; grid-gap:2px;
    height:100%; width:100%;
    '><div style='font-size:10px;'></div>
                <div style='font-size:15px;'>
                    <b><sc>3S:</sc> </b>Head<br>
                    <b><sc>2S:</sc> </b>Torso<br>
                    <b><sc>1S*:</sc> </b>L/R Arm<br>
                    <b><sc>1S*:</sc> </b>Legs<br>
                    <f10><cs>* <b>d6</b>:</cs> <b>1/2:</b> L Arm. <b>3/4:</b> R Arm. <b>5/6:</b> Legs.</f10>
                </div>
            </div></div>
        </div>
        
        <div style='display:grid; grid-auto-flow:row; grid-template-rows:auto 1fr;
        border-radius:4px 4px 4px 4px; border-style:solid; border-width:1px; border-color:black;'>
            <div style='background:black; color:white; border-radius:4px 4px 0px 0px; display:flex; align-items:center; justify-content:left; font-size:10px; padding:2px 2px 2px 4px;'><b>Description</b></div>
            <div style='background:white; color:black; border-radius:0px 0px 4px 4px; display:flex; align-items:top; justify-content:center; font-size:;  padding:1px 2px 1px 2px;'>
				Dashing, charasmatic, and extremely dangerous.
				<br><br>
				This elite scoundral may be leading a mercenary band, leading a revolution, or working as an extremely high priced assassin.
				They are extremely cunning and will nearly always have the drop on the party, including contingencies for almost every situation.
				Their only weakness might be there arrogance, where repeated successes can convince them they will always win. They usually do.
			
            </div>
        </div>
        </div></div><div style='border-style:solid; border-width:1px; border-color:black; position:relative; top:0px; background:white;'></div><div style='display:grid;grid-template-rows: 16px 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr auto;grid-auto-flow: column;background:black;grid-gap: 2px;'><div style='font-size:13px; color:white; border-radius:4px; padding:0px 0px 0px 10px;'><b>Prince Of Theives</b></div><div style='font-size:13px; color:white; padding:0px 4px 0px 0px; display:flex; align-items:center;'>Epic</div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr 1fr;grid-auto-flow: column;background:none;grid-gap: 4px;'><div style='display:grid;grid-template-rows: 80px auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'><div style='display:grid;grid-template-rows:auto auto auto 1fr;grid-template-columns: 1fr;grid-auto-flow: row;background:white;grid-gap: 2px;'>
    <div style='display:grid; grid-gap:2px; grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr; grid-template-rows:1fr; grid-auto-flow:row;'>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Pink-4);'>Str</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Red-4);'>Fort</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>2</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Endr</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Orange-4);'>Agl</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Green-4);'>Dex</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Blue-4);'>Sense</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Turquoise-4);'>Cha</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Int);'>Int</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>3</div>
        </div>
        <div style='
        display:grid; grid-template-columns:1fr; grid-template-rows:auto auto; border:solid 1px hsla(0,0%,25%,1); 
        grid-auto-flow:column dense; height:auto; text-align:center;'>
            <div style='
        background:white; color:black; text-align:center; font-size:10px; font-weight:600; padding:2px; border-radius:4px 4px 0px 0px;
        border-style:none none solid none; border-color:black; border-width:1px;
         color:var(--Purple-4);'>Spirit</div><div style='
        display:flex; align-items:center; justify-content:center; background:white; text-align:right; 
        font-size:20px; font-weight:700; color:black; padding-top:2px;'>4</div>
        </div>
    </div>
    <div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'>
        <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid black; background:black;'>
            <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:white; background:black; border-radius:0px 4px 4px 0px;'><b>Stamina</b></div>
            <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; background:white; color:black; background:white; border-radius:0px 4px 4px 0px;'><b>10</b></div>
        </div>
        <div style='display:grid;grid-template-rows: 1fr 1fr;grid-template-columns: 1fr 1fr;grid-auto-flow: column;background:none;grid-gap: 1px;'>
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dash</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Dodge</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Defend</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 3px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <b>Breath</b> &nbsp;&nbsp;<sub><div style='display:inline; font-weight:700; color:var(--Green-4);'>Endr</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Active</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 3px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:10px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>    
    </div>
    
    <div style='display:grid; grid-template-columns:auto 1fr; grid-auto-flow:column; border:1px solid var(--Red-3); background:white;'>
        <div style='font-size:9px; margin-top:2px; padding:1px 3px 1px 2px; display:flex; align-items:center; color:black; 
        background:white; border-radius:4px 0px 0px 4px; border-width:1px; border-style:none solid none none; border-color:var(--Red-3);'><div>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='height:2px;'></div><b>Recover</b> <sub><div style='display:inline; font-weight:700; color:var(--Red-4);'>Fort</div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sub>
            <div style='font-size:7px; margin-left:5px;'><b><i>Free</i></b></div>
        </div></div>
        <div style='font-size:15px; padding:1px 1px 1px 1px; display:flex; align-items:center; justify-content:center; 
        background:white; color:black; background:white; border-radius:0px 4px 4px 0px; font-size:8px;'>
            <div style='text-align:center;'>
                <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
            </div>
        </div>
    </div>
    </div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='background:black;display:grid; grid-template-rows:15px auto auto auto auto auto ; grid-template-columns:auto auto auto auto auto auto ; grid-auto-flow:row; grid-gap: 1px; info:;border-radius:4px; padding:1px;'><div style='background:black; color:white; font-size:9px; border-radius:4px; padding:0px; text-align:center;'><b>Body Area</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Armor</b></div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Harm</b></div>
        <div style='background:var(--Gray-3); color:white; font-size:8px; border-radius:4px 4px 0px 0px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
            <b>Wound</b>
        </div>
            <div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'>
                <div style='text-align:center; postition:relative; top:2px;'>
                    <b>Harm</b>
                </div>
            </div><div style='background:black; color:white; font-size:8px; border-radius:4px; padding:2px; display:flex; align-items:flex-end; justify-content:center;'><b>Crit</b></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>3S:</sc> Head</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>0</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>4</div></div><div style='grid-row: auto / span 2;background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div></div><div style='grid-row: auto / span 2;background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 1px;height: 17px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: column; align-items: left; justify-content:center; font-size:10px;padding:2px;'><div><b><sc>2S:</sc> Torso</b></div></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px; grid-row: span 1;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> M. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><sc>1S:</sc> O. Arm <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div><div style='background:white; color:black; border-radius:0px 0px 0px 4px;; display:flex; flex-direction:row; align-items:center; justify-content:left; 
                font-size:10px;  padding:1px 3px 1px 2px;'><b><nowrap><div style='padding-top:1px;'><sc>1S:</sc> Legs <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><br><div style='display:inline; font-size:9px; text-align:left; padding-left:15px; font-weight:600;'><keyword>Pace<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></keyword>3</div></div></nowrap></b></div><div style='background:var(--Gray-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction:column; align-items: center; justify-content:center;padding:2px;'><div><div style='display:inline; font-size:10px; color:black;'><b>Item</b></div></div></div><div style='background:var(--Dmg-2); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>2</div></div><div style='background:var(--Dmg-3); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div style='display:inline; font-size:12px; color:white; font-weight:700;'>3</div></div><div style='background:var(--Dmg-4); color:black; border-radius:0px 0px 0px 0px; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px 4px 2px 4px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div> <div style='display:inline; font-size:12px; color:white; font-weight:700;'>2 </div></div></div><div style='background:var(--Dmg-5); color:black; border-radius:0px 0px 0px 0px;; display:flex; flex-direction: row; align-items: center; justify-content:center;padding:2px;'><div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                	    Can do 2 to 3 Actions per Round. Can use a steady amount of Attacks, Dash, and Breath.
                	    Can Taunt and Lucky to avoid Damage and Hit.
                	    <br> May switch between Knives and Bow as a single Action. Throwing Knives can be drawn and thrown at any time.
                	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Skilled</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    	Most Manuever, Stealth, Balance, and Charisma Challenges are considered easy.
                    	</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>True Ambidextrous</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Can do 2 Actions per Round. (Ex: Attack twice.)
                    <br> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May do third Action this Round.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Blinding Strike</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    If Hitting Head with +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> over, Daze <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Target.
                    <br><b>Daze</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div> on Hit. Pace is 1. Remove <f7>Free</f7> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Elite Reflexes</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Dodge or Block. May do up to 3 times per Check.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Taunt</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <b>Contest:</b> <sb><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Turquoise-4);'>Cha</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb>. 
                    <div style='height:2px;'></div><b>Win:</b> Gains <div style='display: inline-block;background: var(--Green-3);color: white;font-weight: 700;font-size: 8px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding: 0px 2px 0px 2px;'> Success 4/5/6</div> on Target this Round. Target gains 1 Stress
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Lucky</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Contest:</b> <sb><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Purple-4);'>Spirit</div></sbi></sb> <b>Win:</b> Target rerolls Check with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Fleeing</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    	<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> on Defensive Actions if Fleeing.
                    	</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='display:grid;grid-template-rows: 1fr;grid-template-columns: 1fr;grid-auto-flow: column;background:none;grid-gap: 2px;'><div style='display:grid; grid-gap:2px; font-size:10px; align-content: start;'><div style='background:black; font-weight:700; color:white; font-size:9px; padding:1px 2px 1px 5px;'>Abilities/Skills</div><div style='padding:0px 1px 1px 5px; margin:0px -3px 0px -3px; background:var(--Red-3); color:white; font-weight:700; font-size:9px; display:flex; align-items:center;'>Equipment</div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Dagger (x2) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>3</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/4</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>/4</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 90px 1fr;'><actionTitle style='background:var(--Red-3); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Slash</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike <img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cb><b>Bypass</b> <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash/Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
		                    <keyword>Bleed 2</keyword>, <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><b>Pin Limb To Surface</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword>, <b>Dmg Back</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Red-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Red-3);margin-left:-2px;margin-top:-2px;'>
                <div>Throwing Knife (15) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Knife</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Red-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>All</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Dmg</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Red-3);border-style: solid; border-color:var(--Red-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Red-3);'>Brk</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>2</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Stab</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bypass</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash/Peirce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Orange-4);'>Agl</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed</keyword> 2, , <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><b>Pin Limb To Surface</b>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bypass</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Slash/Peirce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <keyword>Bleed</keyword> 2, <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><b>Pin Limb To Surface</b>
                        </div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Pin to Surface</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    	Must be near surface. Taget may remove Dagger (Active, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg and Bleed 2) or Pull Out (Free, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+$5D Bleed 2)
                    	</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Red-1); border-color:var(--Red-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Green-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Green-3);margin-left:-2px;margin-top:-2px;'>
                <div>Bow 
                    <div style='display:inline; font-size:8px; font-weight:500;'>+10 Arrows</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Green-1);font-size: 10px;'><div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shoot</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><sb><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><sbi><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>=</div><div style='display:inline; font-weight:700; color:var(--Green-4);'>Dex</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline; font-weight:700; color:var(--Blue-4);'>Sense</div></sbi></sb></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs>+<img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Pierce</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Bleed 2</b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Nock Arrow</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Prepare to Shoot an Arrow.</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-gap:1px; padding:2px 1px 2px 1px; border-radius:0px 4px 4px 4px; border-style:solid; border-width:1px; background:var(--Turquoise-1); border-color:var(--Turquoise-4);'><div style='display: grid;grid-template-columns: 1fr auto auto auto auto;grid-template-rows: auto;grid-gap: 2px;font-size: 9px;background: var(--Turquoise-1);'><div style='display:grid; grid-gap:2px; grid-auto-flow:row;'><div style='display: grid;align-items: center;grid-template-columns: auto;color: white; font-weight: 700;text-align: left;padding: 2px 4px 2px 3px;font-size: 10px;border-radius: 0px 20px 20px 0px;background:var(--Turquoise-3);margin-left:-2px;margin-top:-2px;'>
                <div>Chain Mail (Long) 
                    <div style='display:inline; font-size:8px; font-weight:500;'>Med Armor</div>
                    <div style='display:inline; font-size:7px;'></div>
                </div></div></div><div style='display: grid;align-items: center;grid-template-columns: auto;color: black; font-weight: 600;text-align: left;padding: 0px 1px 0px 1px;margin-top:2px;background: var(--Turquoise-1);font-size: 10px;'><div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>DR</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <mini>All</mini> 2 Slash</div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Absorb</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div>1 <small>All</small></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;color: black; font-weight: 600;text-align: left;background: var(--Turquoise-3);border-style: solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='display: flex; align-items:center;color: white; font-weight: 600;text-align: left;border-radius: 4px 0px 0px 4px;padding: 1px 2px 0px 1px;background: var(--Turquoise-3);'>Dmg Back</div><div style='display: flex; align-items:center;color: black; background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'><div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Torso + Legs</div><div style=' display:grid; grid-template-columns:1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>5</span></div></div></div><div style='display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);background: white;color: black; font-weight: 600;text-align: left;'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Bypass</div><div style='display: flex; align-items:center;color: black; font-size: 8px;font-weight: 500;text-align: left;background: white;padding: 1px 4px 0px 3px;border-radius: 0px 4px 4px 0px;'></div></div></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Left Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: 1fr 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div><div style='grid-column: 1 / -1;display: grid;grid-template-columns: auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: var(--Turquoise-2);color: white;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;grid-row: 1/-1;display: flex; justify-content: center;flex-direction: column;'>Right Arm</div><div style=' display:grid; grid-template-columns:auto auto 1fr;'><div style='display: grid;grid-template-columns: auto auto 1fr;grid-auto-rows: auto;grid-gap: 1px;font-size: 9px;'><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Dmg</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div><div style='background: white;color: black; font-size: 9px;font-weight: 600;text-align: right;display: grid;grid-template-columns: auto 1fr;border: solid 1px;border-color: var(--Turquoise-3);'><div  style='background: var(--Turquoise-3);color: white;font-size: 8px;font-weight: 600;border-radius: 4px 0px 0px 4px;margin-left: -1px;margin-bottom: -1px;padding-left: 1px;padding-right: 3px;display: table-cell;display: flex; justify-content: center;flex-direction: column;'>Brk</div><div style='padding-right: 2px;padding-left: 2px;display: flex; align-items:center; justify-content:flex-end;'><div><span style='color:black;'>4</span></div></div></div></div><div style='height:1px;'></div><div style='color: black; font-size: 8px;font-weight: 500;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);     ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Block</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Turquoise-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Block</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><keyword>Strike</keyword></div></challengeText></challengeContainer></div></actionContainter></div></div></div></div></div></div></div></div></div></div></div></div></div><div style='grid-column-start: 1;grid-column-end: 3;font-size: 30px;font-weight: 900;color: white;margin:0px 0px -7px 0px;'></div></div>    </body>
</html>