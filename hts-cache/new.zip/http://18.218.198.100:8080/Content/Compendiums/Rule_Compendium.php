<html>
<head>
    <title>Rule Compendium</title>
    <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
</head>
<style type="text/css">
    body {
     width: 100%;
    }
</style>
<body style='background:hsla(0,0%,40%,1); padding-left:5px;'>
<div style='display: grid;grid-template-rows: 1fr;grid-template-columns: repeat(auto-fill, 356px);grid-gap: 8px 8px;grid-auto-flow: row;'><div id='Rule Cards' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Rule Cards</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle>Contents <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'></span></rulecardtitle><div style='display:grid; grid-template-columns:20px 1fr; grid-gap:2px; padding:4px 8px 2px 8px;'>
            <div style='font-weight:700; font-size:12px;'>1</div> <div><b>Basics</b> (Morale, Will, Dodge)</div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>2</div> <div><b>Grapple</b> (Close grabbing combat)</div>
            <div style='font-weight:700; font-size:12px;'>3</div> <div><b>Grapple <f7>Continued</f7>, Unarmed, Improvised Combat, Prone</b></div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>4</div> <div><b>Challenges</b> (Combat, Positioning, Mobility)</div>
            <div style='font-weight:700; font-size:12px;'>5</div> <div><b>Challenges <f7>Continued</f7></b> (Endurance, Notice, Social, Stealth)</div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>6</div> <div><b>Damage, Constitution, Treatment, Injured</b></div>
            <div style='font-weight:700; font-size:12px;'>7</div> <div><b>Dying, Mental Strain, Traumas</b></div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>8</div> <div><b>Swimming, Climbing, Terrain</b></div>
            <div style='font-weight:700; font-size:12px;'>9</div> <div><b>Hazards, Blasts/Impacts, Items</b></div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>10</div> <div><b>Shifts, Resting, Weeks</b></div>
            <div style='font-weight:700; font-size:12px;'>11</div> <div><b>Travel, Survival, Character Progression</b></div>
            <div><div style='height:2px;'></div></div> <div></div>
            <div style='font-weight:700; font-size:12px;'>12</div> <div><b>Glossary <f7>A - H</f7></b></div>
            <div style='font-weight:700; font-size:12px;'>13</div> <div><b>Grapple <f7>I - Z</f7></b></div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='height: 15px;'><span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>1</span></rulecardtitle><div style='font-size: 36px; font-weight: 800; text-align: center '>WARPS RULES</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Determination 
                <div style='font-weight: 500; font-size: 8px;'> Combat:<f8> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> / <b>Will</b> / <b>Morale</b></f8> </div>
                <div style='font-weight: 500; font-size: 8px;'>  Other: <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:7px;'>1F</div> /  <f8><b>Morale</b></f8> </div></div></div> <actionSubtitle style='color:black; margin-left:3px;'>Use</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>May apply only once per Check.</b>
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> Reroll Check. May replace Result.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to a Check. <f7>Ignore <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> for these dice.</f7></div></challengeText></challengeContainer></div></actionContainter><rulecardsubtitle> Stamina <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> </rulecardsubtitle><div style='line-height: 8px; font-size: 8px; padding: 0px 2px;'>Short term exertion. Con Point recorded with <f12><b style='font-weight:900;'>&#8226;</b></f12>. Goes away after combat.</div><div style='margin-left:5px; display:grid; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f8><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f8> Recover</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Reduce/Prevent <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Damage. <br><f7><b>Note:</b> Prevented Dmg can still apply Bleeding.</f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Catch Breath</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Regain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stamina. <b><i>Full:</i></b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.</div></challengeText></challengeContainer></div></actionContainter></div><div style='height:2px;'></div><rulecardsubtitle> Will </rulecardsubtitle><div style='font-size: 8px; padding: 0px 2px;'>
                Willpower and resolve. Goes away at end of Combat.
            </div><div style='margin-left:5px; display:grid; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><span>1</span> Will</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Use</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> Spend 1 Will instead of <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Cost</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> Remove 1 Terror.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Encourage</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                        <cs>2S:</cs> Ally within <img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> gains Will.
                    </div></challengeText></challengeContainer></div></actionContainter></div><div style='height:2px;'></div><rulecardsubtitle> Morale </rulecardsubtitle><div style='font-size: 8px; padding: 0px 2px;'>
                Longterm confidence and resolve. May come from effects, items, or experiences.
            </div><div style='margin-left:5px; display:grid; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><span>1</span> Morale</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Use</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> Spend 1 Morale instead of <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Cost</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>OR:</b> Remove 1 Stress/<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.</div></challengeText></challengeContainer></div></actionContainter></div><div style='height:2px;'></div><rulecardsubtitle>General Combat</rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Cover</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Use</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b><f7>Requires Character to be behind Cover. Can't be combined with <i>Defend</i>.</f7></b>
                    <br><b>Reduce</b> Proj/Blast by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Cover Bonus</b>.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i style='font-size:7px;'><b>Cover Bonus Examples:</b> Shrub (<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>), Wall Corner (<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>), etc.</i>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Dash <div style='background: white; display: inline-block; padding: 1px; height: 12px; width:12px; border-radius: 8px; border: 1px solid black;'><img 
        src='/Resources/Art/Images/Mobility_Black.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: -2;
            
            padding: 0px 0px 0px 0px;
        '></div></div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> <cb><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></cb></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Move +1 Spaces.
                    <cb><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to <b>Dodge</b></cb>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Dodge</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Reduce</b> Strike/Proj by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><rulebox>
            <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>5</b>s do not count as Successes. Each additional applies <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doesn't effect <b>Resist/Rest/Catch Breath/Compose Self</b>.
             <div style='height:1px;'></div><b9>Bleed:</b9> Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>. Effect only appies upon 1 or more Dmg.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Each point applies Torso Dmg or Stamina Loss. Effected Character chooses.
            <div style='height:1px;'></div><b9>Flanking:</b9> If attacking Target from opposite sides, each attacker gets <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.
        </rulebox>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Breather</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>After Combat Characters remove Harm, Stamina Loss, Terror, Will, and other temporary effects.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle><span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>2</span> Grappling</rulecardtitle><div style='padding: 0px 2px; font-size: 8px; '>
                <b>Grappling</b> Characters may only attempt Grapple Actions.
                <br><b>Prevent</b> is done against each Grapple Action Targeting you.
                <br><b>Assist</b> is used to add Successes to an Ally's Grapple Action.
                <br><b8>Leaving a Grapple</b8> can occur whenever both decide to end the Grapple.
            </div><div style='height:2px;'></div><rulecardsubtitle>Grapple Actions</rulecardsubtitle><rulebox style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; background: white;'>
            <div style='display:flex; align-items:center; font-size:10px;'><div style='text-align:center;'><b>Any<br>Grapple<br>Action</b></div></div>
            <div style='display:grid; grid-gap:0px;'>
                <div><sc>1S:</sc> Reposition yourself and Target within space. (Ex: Switch sides.)</div>
                <div><sc>1S:</sc> Attacks against are considered <b>Friendly Fire</b> against Target.</div>
                <div><sc>0S:</sc> May Knockdown yourself and Target.</div>
            </div>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Action</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Attempt Active Action. (Attacks have <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bypass.)
                    <br><sc>1S:</sc> Attempt Defensive Action (ex: Block, Dodge.)
                    <br><cs>1S:</cs>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bypass.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Full Action</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc>  May attempt Full Action. Can't Move.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Escape</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Leave Grapple and/or remove Pin. Move 1 Space.
                    <br><sc>1S:</sc> Prevent Pin Damage.
                    <br><sc>1S:</sc> Attempt Defensive Action (ex: Block, Dodge.)
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Disarm</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Disarm Target. (Item falls <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Spaces away.)
                            <br><sc>2S:</sc> Take/Unstrap Item. <f7>Must Unstrap Armor 1-3 Times to Remove.</f7>
                            <br><sc>3S:</sc> Take and use Target's Item.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Shove</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Move 1 Space with Target.
                            <br><sc>2S:</sc> <b>Push</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>. Knockdown 2. Collision <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Strangle</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><div style='display:grid; grid-auto-flow:row; grid-gap:2px; width:100%;'>
                                <div>
                                    Target must have Head/Neck within reach. May Muffle Target.
                                </div>
                                <div>
                                    <b>OR</b> <sc>1S:</sc> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>Dmg</b>. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b>Strangle</b> next Round.
                                </div>
                                <div style='display:grid; grid-template-columns:auto 1fr;'>
                                    <div><b>OR</b> <sc>2S:</sc></div><div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <b>Dmg</b>. +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b>Strangle</b> next Round.</div>
                                </div>
                            </div></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><div style='text-align:left;'>Take<br>Hostage</div></div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-size:8px;'><sc>2S:</sc> <b>Take Hostage</b> Req Executing Weapon.</div>
                    <div style='display:inline-grid; grid-auto-flow:row; grid-gap:2px; font-size:9px; width:calc(100%); margin-top:1px;'>
                        <div style='display:inline-grid; grid-template-columns:auto 1fr; grid-gap:2px; margin-left:0px; font-size:7px;'>
                            <situationHeader style='font-weight:500;'><f8>Holding<br>Hostage</f8></situationHeader>
                            <div style='display:flex; align-items:center; font-size:8px;'><div>At any time may attempt:<br><b>Execute</b> <f8>Executing Weapon Dmg w/ +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hostage.</f8></div></div>
                        </div>
                        <div style='display:inline-grid; grid-template-columns:auto 1fr; grid-gap:2px; margin-left:0px;'>
                            <situationHeader style='font-weight:500;'><f8>Hostage</f8></situationHeader>
                            <div style='display:flex; align-items:center; font-size:8px;'><div><b>Prevent</b> <sc>3S:</sc>Prevent <b>Execute</b>. Escape to Grapple.</div></div>
                        </div>
                        <div style='display:inline-grid; grid-template-columns:auto 1fr; grid-gap:2px; margin-left:0px;'>
                            <situationHeader style='font-weight:500;'><f8>Hitting Into Grapple</f8></situationHeader>
                            <div style='display:flex; align-items:center; font-size:8px;'><div>Must <b>Friendly Fire</b> w/ -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to avoid Hostage.</div></div>
                        </div>
                    </div>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Lift</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:grid; grid-auto-flow:row; grid-gap:2px; width:100%;'>
                        <div style='display:grid; grid-auto-flow:row; grid-gap:2px; width:100%; font-size:8px;'>
                            <div>
                                <sc>2S:</sc> <b>Lift</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Grapple vs Target. May move Pace in Grapple.
                            </div>
                            <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:1px; font-size:8px;'>
                                <situationHeader style='font-weight:500;'><f8>Lifting</f8></situationHeader>
                                <div style='display:grid; grid-auto-flow:rows; grid-gap:1px;'>
                                    <div>
                                        <sc>1S:</sc> <f8><b>Hurt</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <b>Bash Dmg</b> to Target Body Area.</f8>
                                    </div>
                                    <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:1px;'>
                                        <div style='display:grid; align-items:center;'><div><sc>2S:</sc> <f8><b>Throw</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></f8></div></div>
                                        <div><f8>Apply <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>Impact Dmg</b>. <br>Knockdown + Throw Target <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> Spaces.</f8></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div></challengeText></challengeContainer></div></actionContainter><rulebox style='margin-top:0px;'>
            <b8>Ranged:</b8> Certain Actions (ex: Disarm) cannot be applied when Grappling at distance.
            <br><b8>Flying:</b8> Flying Charcters must still succeed in moving every Round or begin to fall.
            <br><b8>Size Differences:</b8> A <b>Lift</b> occurs automatically if Grappling a Target below Capacity.
        </rulebox></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Grapple  <f8>Continued</f8> + Unarmed + Prone <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>3</span></rulecardtitle><rulecardsubtitle>Grapple Prevent / Assist Actions</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
                <b>Prevent</b> is used to redce the effectiveness of a Grapple Action targeting you.
                <br> <b>Assisting</b> in a Grapple is one another Character helps an ally in a Grapple.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; When Assisting a Character may do an <b>Grapple Assist</b> and a <b>Prevent Assist</b>.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Grapple Assist</b> is applied to the Ally's chosen Grapple Action.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Prevent Assist</b> is applied to an Ally's Prevent Action.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A Character can only be Assisted by a single Ally at a time. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Characters may leave Assited Grapples w/o Escping only if the opponant agrees.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Prevent</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Reduce</b> Target's Grapple Check by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>OR</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><b>Prevent Assist:</b> Add <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>OR</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Allies Prevent Check.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Grapple Assist</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>OR</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Add Successes to Ally's Grapple Check.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Unarmed</rulecardsubtitle><div style='margin-left:5px; display:grid; grid-gap:1px;'><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Unarmed</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <cb><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></cb></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Push</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b><br><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>. Move with Target.<br><sc>Win:</sc><b>Push:</b> 1. Knockdown 1.</div></challengeText></challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Grab <img 
        src='/Resources/Art/Images/HandW.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div><div style='text-align:center;'>Strike <img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                        <div style='font-size:8px;'>
                            Enter Grapple and attempt Grapple Action. See <b>Grappling Section</b>.
                            <br><b>Tackle <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</b> Move +1 Space. Knockdown Self and Target.
                            <br><b>Interrupt <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</b> Attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Contest.
                            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>If Won:</b> Grab Target before their Action.
                        </div></div></challengeText></challengeContainer></div></actionContainter></div><div style='height:2px;'></div><rulecardsubtitle>Improvised Combat</rulecardsubtitle><div style='line-height: 8px; font-size: 8px; padding: 0px 2px;'>
            Sometimes combat can get messy, Characters can pick up items and objects around <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; them to use in combat.
        </div><div style='margin-left:5px; display:grid; grid-gap:1px;'><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Improvised</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Throw Item</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f8>If Edged: Bleed 1</f8> </div></challengeText></challengeContainer></div></actionContainter></div></div><div style='height:2px;'></div><rulecardsubtitle>Prone</rulecardsubtitle><div style='line-height: 8px; font-size: 8px; padding: 0px 2px;'>
            A Character is knocked to the ground or off thier feet (or other mobility providing limbs), listed below are the only actions that can be done while prone.
        </div><div style='margin-left:5px; display:grid; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Act</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full: Prone</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Any Active/Full Action. <br> <f8>(Can't Move. Can't Defend, Can't attempt <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions.)</f8></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Stand</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full: Prone</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Stand. <sc>1S:</sc> Move 1 Space.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Crawl</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full: Prone</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Move 1 Space. <sc>1S:</sc> Move 1 more Space.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Roll</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full: Prone</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>May Defend. <sc>1S:</sc> Move 1 Space. <sc>2S:</sc> Stand.</div></challengeText></challengeContainer></div></actionContainter></div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle><span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>4</span> Challenges</rulecardtitle><div style='padding: 0px 2px; font-size: 8px; '>
                <b>Challenges</b> are used for most anything a Character may attempt that isn't an action.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Some Challenges are listed with suggested results.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Others the GM will create and evaluate in the moment.
                <br> <b>Challenge Checks</b> are made by combining two Stats or a single Stat and adding <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp For example a <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to move a heavy log or <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> to get over it.
                <div style='height:1px;'></div> <b>Difficulty</b> is chosen by the GM. With <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Easy</b>, <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Hard</b> and <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Very Hard</b>.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If Simulation is desired replace flat Successes to be with a <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> check. 
                <div style='height:1px;'></div> <b>Cumulative Challenges</b> are those where each Success is added to a result.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Often <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Easy</b>, <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Hard</b> and <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> for <b>Very Hard</b>. About <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> per round expected.
                <div style='height:1px;'></div> <b>Helping</b> Characters may add Dice or Successes to Challenges. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some Challenges may be attempted together.
                <div style='height:1px;'></div> <b>Contests</b> may occur when Characters are working against each other. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Contests will cancel each other's Success. They may be the same or different Checks. 
                <div style='height:1px;'></div> <b>Expertise</b> Some challenges require expertise in certain subjects to attempt. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ex: Magic, Languages, Music, etc.)
            </div><div style='height:2px;'></div><rulecardsubtitle> Combat Challenges </rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Friendly Fire</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:8px;'><b>Must attempt when in danger of hitting an Ally.</b>
                    <br><fc>2S:</fc> Avoid Hitting Target.<br><fc>1S or Less:</fc> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit Target. <f7>(GM directs Hit).</f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Guile</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:8px;'>Attmept to taunt, distract, or otherwise influence a Target's Actions.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Priority</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Winner is quicker. May effect action order.<br><f7><i>Ex: Grab sword first, Beat to space, etc.</i></f7></div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle> Positioning Challenges </rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Reposition</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></f7></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>Win:</b> Change You and Target's position in Space.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Impede</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Must be in Same Space as Target.</b> 
                    <br><b>Win:</b> Target can’t Move/Hit past you. Target may Attack you instead.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle> Mobility Challenges </rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Jump <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Typically <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> per 5' forward or 1/2' up.<br><fc>Off by 1:</fc> Typically get a chance to grab the nearest ledge or helping hand.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Maneuver <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Avoid obsticles. <i>Low wall, fruit stand, car hood.</i><br><fc>Off by 1:</fc> May lose movement that round.<br><fc>Fail:</fc> Typcially fall Prone.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Balance <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Move slowly over precarious ground.<br><i>Thin Ledge, log over chasm, earthquake. </i><br>Typically move 5' per <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.<br><fc>Fail:</fc> Fall prone or off surface.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Challenges <f8>Continued</f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>5</span></rulecardtitle><rulecardsubtitle> Endurance Challenges </rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
                Hard physical effort may be represented by resisting an amount of Fatigue recieved.
                <div style='font-size:7px; margin-left:5px;'><i>
                    <b>1 (Easy):</b> Hopping a Fence, Climbing a Hill.
                    <br><b>3 (Hard):</b> Climbing a mountain, Carrying a person.
                    <br><b>5 (Brutal):</b> Dragging a boat a mile through the mud.
                </i></div>
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Endurance</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Resist 1-5 Fatigue/Stamina w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: #484848;
        
        font-weight:700;
    '>
        Stat
    </div>.
                            <br>`<f7>Stats depend on type of exertion. 
                                <i>Ex: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> (pushing a cart), <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> (climbing), etc. 
                                </i>
                            </f7>
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle> Notice Challenges </rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Notice</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Used to notice ambushes, stealthed Characters, and other dangers, like falling rocks. Typically the higher the result the more time to react.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Search</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>If there’s something to find it's found by the Character w/ the most Successes.
                High Result may find more.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle> Social Challenges </rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Social</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    Convince someone of something, endear yourself to people, or get a small discount.
                    Characters cannot typically be convinced to act way outside their interests or totally change their opinion but may have their disposition shifted.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Haggle</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><fc>0S:</fc> +1 Gold to Price. <sc>1S:</sc> No Effect. <br><sc>2S:</sc> -1 Gold to Price. <sc>3S:</sc> -3 Gold to Price.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle> Stealth Challenges </rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Stealth</b> may occur whenever a Character is not in-sight of another character.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stealth may be ignored until Characters in danger of being noticed.
            <br><b>Alertness</b> determined how interested a guard is in finding a Stealthed Character.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Distracted</b> Characters don't have any clue stealthed character might exist.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Relaxed</b> Characters may look around, and say 'I think I heard something.'
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Searching</b> Characters are actively trying to find source of noise.
            <br><b>Disadvatages</b> in Stealth may apply Negative mods.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Ex: Armor, carrying things, noisy actions.</i>
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 53px 1fr;'><actionTitle style='background:var(--Gray-4); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:b; '></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                Sneak past or act quietky. The more successes, the more quiet. When doing as a group, failures may be counted together.
                <i><f7>
                    <br><b>Easy:</b> Sneaking past distracted guards.
                    <br><b>Hard:</b> Moving past a guard tower in the night.
                    <br><b>Very Hard:</b> Creeping up behind an alert guard.
                </f7></i>
            </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; grid-template-columns: 53px 1fr;'><actionTitle style='background:var(--Gray-4); justify-content:left; flex-direction:row;   align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Hide</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='height:1px;'></div><b>OR</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Stay hidden. <fc>Fail:</fc> Found.
            <br>May have to beat a <b>Notice</b> Action.
            <br>Some hiding spaces may add bonuses.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> vs. <b>Target's</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    <br><sc>Win:</sc> Target cannot react to being grabbed/attacked.
                    <br><sc>Tie:</sc> Target may react to Action with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                    <br><fc>Lose:</fc> Target notices and may react to Action.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Damage + Constitution + Treatment + Injured <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>6</span></rulecardtitle><rulecardsubtitle>Damage</rulecardsubtitle><div style='line-height: 8px; font-size: 8px; padding: 0px 2px;'>
            Damage (Dmg) is often applied by Attacks and applies Harm, Wound, and other effects.
            <div style='height:1px;'></div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Limb (Arm) can't be used. Anything it is holding is Disarmed.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Disabled Main Arm:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.
            <div style='height:1px;'></div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>&#10680 </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Limb (Legs) Can't be used. Knockdown occurs.
            <div style='height:1px;'></div><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Cannot Move or attempt Actions other than <b>Recover</b> or <b>Remove</b>.
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Aid</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full / Active:<div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Remove <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Harm from Inactive Target.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Constitution</rulecardsubtitle>
        <div style='font-size: 8px; padding: 0px 2px;'>
            A Character's Constitution represents a Character general health and wellbeing.
            <br><b>Con Points</b> such as Fatigue, Hunger, etc. and get recorded in the Consitution Meter.
            <br><b>Expire Checks</b> occur when Characters would go over their Consitution limit.
            <div style='font-size:8px; display:grid; grid-template-columns:auto 1fr; grid-gap:1px;'>
                <div style='display:flex; align-items:center; border:1px solid black; padding:1px 2px 1px 2px;'><div><b>Expire<br>Check</b></div></div>
                <div style='display:flex; align-items:center;'><div>
                    Resist points over Con Limit w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><sc>0 Remaining:</sc> Pass out for a bit/KOd if in Combat. <sc>1 or more:</sc> Dead.
                </div></div>
            </div>
        </div><div style='height:2px;'></div><rulecardsubtitle>Treatment</rulecardsubtitle>
        <div style='font-size: 8px; padding: 0px 2px;'>
             <b>Treatment</b> attempting to care for and accelerate the healing of an ally.
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f9>Give<br> Treatment</f9></div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                    &nbsp;&nbsp;&nbsp;  <b>Attempt on additonal Character:</b> Resist <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div>.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Heal</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>2S:</cs> Remove 1 Wound/Broken.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div><f8>Critical</f8></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f7><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></f7></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <f7><cs>2S:</cs> Remove 1 Mortal Wound/Infection.</f7>
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/Injured.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div> Injured</rulecardsubtitle><div style='margin-left:5px; display:grid; grid-gap:1px;'>
            <div style='font-size:8px; padding: 0px 2px;'>
                <b>Aesthtic Damage:</b> When Injured choose a descriptive scar, lost digit, etc.
                <br> <b>Finger Damge:</b> If on Arm roll <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. <sc>3S:</sc> Gain Lost Finger Aspect.
                <br> <b>Injury Check:</b> Resist Dmg over Critical w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                <div style='height:1px;'></div>
                <div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; margin-left:10px;'>
                    <div style='border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' ><div style='display: inline-block; background: black; color: white; font-weight: 800; padding:2px 3px 2px 2px;'>0 Over Critical:</div> <b>Broken</b> 10</div>
                    <div style='border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' ><div style='display: inline-block; background: black; color: white; font-weight: 800; padding:2px 3px 2px 4px;'>1+ Over Crital:</div> <b>Infection</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div>
                </div>
            </div>
            <div style='display: grid; grid-template-columns: 1fr auto;'> 
                <div style='border: 1px black solid; padding: 0px 2px; font-size:8px;'>
                    <b>Broken:</b> Can't use Limb until removed. Removed w/ <b>Sleep/Recieve Treatment</b>.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Record in the Notes Area with amount and Body Area. 
                </div>
                <div style='position: relative; top: 2px;'>
                    <div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/DownArrow.svg' 
        height='20px'
        width='20px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div>
                </div>
            </div>
            <div style='border: 1px black solid; padding: 0px 2px; font-size:8px;'> 
                <b>Infection</b>
                <br> Can't use Limb. Can't remove Wounds.  May lose Limb.
                <br> Each day <f8>Resist 3 Rot (Con Point represented by <b style='font-weight:900;'>(R)</b>).
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist w/ <b><f10>(</f10></b><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><b><f10>)</f10></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Comfort</b>.</f8>
                <br><f8>If all Infection removed, each Rot <b style='font-weight:900;'>(R)</b> becomes Illness <b style='font-weight:900;'>(I)</b>. Gain Broken 10.</f8>
            	<actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Amputation</f10></div></div> <actionSubtitle style='color:black; margin-left:3px;'><f8>Interim</f8></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f8><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></f8></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>Patient Resists 2 Illness w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                        <br> <cs>1S:</cs> Reduce Illness Patient Resists by 1.
                        <br> <sc>1S:</sc> Gain Lost Leg/Lost Arm Aspect. 
                        <br> <sc>2S:</sc> Gain Lost Lower Leg/Lost Hand Aspect.
                        <br> <sc>3S:</sc> Gain Lame Leg/Lost Fingers Aspect.</f7>
                    </div></challengeText></challengeContainer></div></actionContainter></div>
            </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Dying + Mental Strain + Traumas <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>7</span></rulecardtitle><rulecardsubtitle><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div> Dying</rulecardsubtitle><div style='margin-left:5px; display:grid; grid-gap:1px;'><div style='font-size:8px; padding: 0px 2px;'>
                <b>Aesthtic Damage:</b> Choose a descriptive scar, etc.
                <br> <b>Eye Damage:</b> If from Head Wound roll <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. <sc>3S:</sc> <b>Eye Dmg</b>.
                <div style='margin-left:8px;'>
                    <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f8>Eye<br>Dmg</f8></div></div> <actionSubtitle style='margin-left:3px;'><f8></f8></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f8><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f8></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7>
                             <fc>0S:</fc>Lost Eye until Mortal Wound Healed. <fc>1S:</fc> Blind until Mortal Wound Healed. 
                             <br><fc>2S:</fc> Permanent Lost Eye. <fc>3S:</fc> Permanent Blind.
                             </f7>
                        </div></challengeText></challengeContainer></div></actionContainter>
                </div>
                <div style='height:1px;'></div>
                <b>Dying Check:</b> Can't Move/Act. Resist Dmg over Critical w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                <div style='height:1px;'></div>
                <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:1px; margin-left:10px;'>
                    <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px; border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' >
                        <div style='display:flex; align-items:center; background: black; color: white; font-weight: 800; padding: 2px;'>
                            Over Critical:
                        </div>
                        <div>
                            +X <b>Death Points</b>.
                            <br><f7>X equals non-Resisted value.</f7>
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;  border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' >
                        <div style='display:flex; align-items:center; background: black; color: white; font-weight: 800; padding: 2px;'>
                            Critical:
                        </div> 
                        <div  style='display:flex; align-items:center;'>
                            <div><b>Mortal Wound</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div>
                        </div>
                    </div>
                </div>
                <div style='height:1px;'></div>
                <div style='display: grid; grid-template-columns: 1fr auto; font-size:8px;'>
                    <div>
                        <div style='border: 1px black solid; padding: 0px 2px;'>
                            <b>Death Points:</b>  Tracks a Character's closeness to Death.</f8>
                            <br> After Combat Resist <b>Death Points</b> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b>One Ally:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>
                        </div>
                        <div style='height:1px;'></div>
                        <div style='display:grid; grid-template-columns:auto 1fr; grid-gap:1px; margin-left:10px;'>
                            <div style='border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' ><div style='display: inline-block; background: black; color: white; font-weight: 800; padding: 2px;'>
                                1+ Death Points:</div> Dead.
                            </div>
                            <div style='border: 1px black solid; font-size:9px; padding: 0px 2px 0px 0px;' ><div style='display: inline-block; background: black; color: white; font-weight: 800; padding: 2px;'>
                                0 Death Points:</div> <b>Mortal Wound</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                            </div>
                        </div>
                    </div>
                    <div style='position: relative; top: 1px;'>
                        <div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/DownArrow.svg' 
        height='20px'
        width='20px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div>
                        <div style='height:5px;'></div><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/DownArrow.svg' 
        height='20px'
        width='20px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div>
                    </div>
                </div>
    
            </div>
            <div style='border: 1px black solid; padding: 0px 2px; font-size:8px;'>
                <b>Mortally Wounded</b> 
                <br> Character is critically wounded and may die. Cannot remove Wounds.
                <br> End of Each Day <f8>Resist 3 Dying (Con point represented by <b style='font-weight:900;'>(Dy)</b>)
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist w/ <b><f10>(</f10></b><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><b><f10>)</f10></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</f8>
                <br><f8>If all Mortal Wound is removed, each Dying <b style='font-weight:900;'>(Dy)</b> becomes Illness <b style='font-weight:900;'>(I)</b>.</f8>
                <br> Mortally Wounded Characters are better off being carried instead of traveling.
            	
            </div></div><div style='height:2px;'></div><rulecardsubtitle>Mental Strain</rulecardsubtitle><div style='font-size: 8px; padding: 0px 2px;'>
            <b>Mental Strains</b> negatively effect Characters psychology. Often resisted with <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        </div><div style='margin-left:8px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Mental Strain</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Resist 1-5 Terror/Stress/Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='font-size: 8px; padding: 0px 2px;'>
            <b>Terror:</b> Intense short term Fear. Con Point represented by <b style='font-weight:900;'>(T)</b>. Removed after combat.
        </div><div style='margin-left:8px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Compose Self</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full / Active:<div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Remove <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Terror from self.</div></challengeText></challengeContainer></div></actionContainter></div><div style='font-size: 8px; padding: 0px 2px;'>
            <b>Stress:</b> Fear or strain the linger. Con Point represented by <b style='font-weight:900;'>(S)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Removed by using <b>1 Morale</b>.
            <br><b>Dread:</b> Long term mental damage. Con Point represented by <b style='font-weight:900;'>(D)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Each use of <b>1 Morale</b> removes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>Dread</b>.
            
        </div><div style='font-size: 8px; padding: 0px 2px;'>
            <b>Mental Breakdowns</b> may be applied by Characters with too many Mental Effects.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; When applied Characters remove all current Terror/Stress/Dread and gain a Trauma.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If they already have 2 Traumas they may gain an Insanity instead.
            <br><b>Insane Characters</b> place Terror/Stress/Dread into their Insanity Card's Insanity Meter.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If Insanity meter is full additional points go in the Consitution Meter as normal. 
        </div><div style='height:2px;'></div><rulecardsubtitle>Traumas</rulecardsubtitle><div style='font-size: 8px; padding: 0px 2px;'>
            Some choices and consequences of adventure may cause acute psychological damage.
            <br><b>Cannibalism:</b> Eating other Humanoids. Resist 3 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            <br><b>First Kill of a Humanoid:</b> Resist 2 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            <br><b>Cold Blooded Murder:</b> Resist 4 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; May use 2 Inspiration to gain Sociopath Aspect.
            <br><b>Witnessing Traumas:</b> Cannibalism, Cold Blooded Murder performed by an ally.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist 1 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            <br><b>Death of a Friend:</b> Resist 3 Dread w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Swimming + Climbing + Terrain <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>8</span></rulecardtitle><rulecardsubtitle>Swimming</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <div style='height:1px;'></div>
            <b>Swimming </b> Characters must be at surface to breathe and cannot attempt <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions.
            <br> Typically may only attempt <b>Wade</b><b>/</b><b>Swim</b>.
             If Character can't act they sink below surface.
            <div style='height:1px;'></div>
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Wade</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full: Swimming</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><br> <b>Grabbing Something:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Move 1 Space. 
                    <br><sc>1S:</sc> Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stamina.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Swim</div></div> <actionSubtitle style='margin-left:3px;'>Full: Swimming</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Move 1 Space. 
                    <br><sc>1S:</sc> Attempt Active and Defensive Actions.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='margin-bottom: 0px;'>
            <b>Air Loss:</b> Resist 2 Air Loss per Round w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>10:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div>. <b>20:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div>.</b> All Air Loss removed whenever able to breathe.
            <br><b>Difficult Swimming/Helping:</b> <i>Heavy Clothes, Carrying someone, etc.</i>
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> to all Checks while Swimming.
            <br><b>Currents:</b> Moved that many Spaces in the direction of the Current each Round.
            <br><b>Sinking:</b> <i>Wearing metal armor, carrying heavy items.</i> Sink 1 Spaces per Round.
        </rulebox><div style='height:2px;'></div><rulecardsubtitle>Climbing</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <div style='height:1px;'></div>
            <b>Climbing</b> Characters must <b>Hang/Climb</b> each Round or fall.
                 Can't attempt <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions.
            <div style='height:1px;'></div>
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Hang</div></div> <actionSubtitle style='margin-left:3px;'>Full: Climbing</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <fc>0S:</fc> May Fall.
                    <br><sc>1S:</sc> Don't Fall. Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stamina.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Climb</div></div> <actionSubtitle style='margin-left:3px;'>Full: Climbing</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Climb 1 Space. Max:3
                    <br><sc>1S:</sc> Attempt Active and/or Defensive Action.
                    <br> <b>OR</b> <sc>2S:</sc> Attempt Full Action w/ <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                    <br> <b>OR</b> <sc>3S:</sc> Attempt Full Action.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Boost</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Target's Climb. <sc>2S:</sc> Boost Target up 1 Space.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='margin-bottom: 0px;'>
            <b>Easy Climbs:</b> <f7><i>Ladders, Easy holds, etc.</i></f7>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to <b>Climb</b>. May stop Climbing without falling.
            <div style='height:1px;'></div><b>Difficult Climbs:</b> <f7><i>Poor holds, slippery, one hand, etc.</i></f7> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> to <b>Hang</b> / <b>Climb</b>. On <sc>0S:</sc> Fall.
        </rulebox><div style='height:2px;'></div><rulecardsubtitle>Terrain</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <div style='height:1px;'></div>
            <b>Terrain</b> effects the area, causing difficulties for movement and combat.
        </div>
        <rulebox style='font-size: 8px;'>
            <b>Narrow/Crowded:</b> <i style='font-size:8px;'>Narrow Pass, Crowded Areas, etc.</i>
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Dodge , <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions, and using long weapons (Ex: Swords).
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Applies when 2 or more Allies are operating in a single Space.
            <div style='height:1px;'></div><b>Slow X:</b> <i style='font-size:8px;'>Bushy Ground (Slow 1), High Water (Slow 2)</i> Reduce Speed by X.
            <div style='height:1px;'></div><b>Difficult X:</b> <i style='font-size:8px;'>Slippery, Shaking, Narrow Ledges, Dense Crowd, Uneven footing, etc.</i>
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; When moving X spaces, make <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> <sc>0S:</sc> Fall. (Interupts movement.)
            <div style='height:1px;'></div><b>Obstacles:</b> <i style='font-size:8px;'>Fallen Column, Fense, Table, etc</i>
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Reduce Speed by 1 or 2. May attempt <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> <sc>XS:</sc> Ignore Obstacle.
            <div style='height:1px;'></div><b8>Darkness:</b8> <b6>Night:</b6> Visibility 3. &nbsp;&nbsp;&nbsp;<b6>Full Moon:</b6> Visibility 1R. &nbsp;&nbsp;&nbsp;<b6>Caverns:</b6> Visibility 0-3.
            <div style='height:1px;'></div><b8>Fog:</b8> Typically Visibility 2-1R.
            <div style='height:1px;'></div><b8>Light:</b8> Counteracts Darkness and raises Visibility to that amount.
        </rulebox></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Hazards + Blasts/Impacts + Items <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>9</span></rulecardtitle><rulecardsubtitle>Hazards</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
        <div style='height:1px;'></div>
        <b>Hazards</b> make areas more dangerous, typically applying Damage while inside.
    </div><rulebox style='font-size: 8px;'>
        <b8>Acid:</b8> Causes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Damage to all Body Areas within it every Round.
        <div style='height:1px;'></div>
        <b8>Fires:</b8> Spaces on Fire may cause Blast of Burning 2 to effected Body Areas.
            <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b6>Spread:</b6> Fires may spread from <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> adjacent flamable Spaces per Round.
            <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b6>Smoke:</b6> Visibility 2. Resist 1 to 3 Air Loss per Round w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        <div style='height:1px;'></div>
        <b8>Lava:</b8> Causes <b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Damage to all Body Areas within it every Round.
        <div style='height:1px;'></div>
        <b8>Wind:</b8> Each Round Resist Push 1-3 w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.
        <div style='height:1px;'></div>
        <f7><b8>Note:</b8> If Hazard would apply Dmg to Head and Torso together, only the Head Dmg is applied.</f7>
    </rulebox><div style='height:2px;'></div><rulecardsubtitle>Blasts/Impacts</rulecardsubtitle><div style='background:white; font-size:8px;'>
            <b8>Blast/Impact:</b8> Hits that spread over body. <b6>On 5 or more Impact Dmg:</b6> Apply Break.
            <ruleboxTab style='margin-top:0px;'>
                <div style='font-size:8px;'>
                <actionContainter style='font-size: ; grid-template-columns:1fr; display:inline-grid;; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Blast/<br>Impact</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f8><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f8></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:8px;'>
                            <sc>0S:</sc> No Effect.
                            <br><sc>1S:</sc> Target chooses 1 Body Areas. Knockdown.
                            <br><sc>2S:</sc> Torso + Target chooses 1 Limb. Knockdown.
                            <br><sc>3S:</sc> Head + Target chooses 1 Limb. Knockdown.</div></challengeText></challengeContainer></div></actionContainter>
                </div>
            </ruleboxTab>
            <div style='height:1px;'></div><b>Collision:</b> If Character collides with an object <b>Impact</b> Dmg is applied.
            <br><b>Falling:</b> Characters/Items Fall 10 Spaces/Round. Landing causes Impact Hit.
                <ruleboxTab style='margin-top:0px;'>
                    <b6>5-10':</b6> <f7><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>&nbsp;&nbsp;&nbsp;
                    <b6>10-50':</b6> <f7><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>&nbsp;&nbsp;&nbsp;
                    <b6>50-100':</b6> <f7><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>&nbsp;&nbsp;&nbsp;
                    <b6>100-200':</b6> <f7><b style='font-weight:700; color: black;'>10<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>&nbsp;&nbsp;&nbsp;
                    <b6>200+':</b6> <f7><b style='font-weight:700; color: black;'>20<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>
                    <div style='font-size:8px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; display:inline-grid;; '><actionTitle style='background:var(--Gray-4);    ;'><div style='text-align:center;'><div style='text-align:left;'>Landing</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f8><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></f8></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><f8><sc>1S:</sc>Reduce Falling Damage Level by 1.</f8></div></challengeText></challengeContainer></div></actionContainter></div>
                </ruleboxTab>
        </div><div style='height:2px;'></div><rulecardsubtitle>Carrying Items</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Encumbrence (<b6>E</b6>)</b> represents a size/weight of an Item to carry.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Characters can only carry up to their <b>Capacity</b> Value.
            <div style='height:1px;'></div><b>Worn</b> Items can be worn on the body, with a limit of one peice of armor per Body Area.
            <div style='height:1px;'></div><b>Readied</b> Items are those worn on the Hip/Back or that are being Held.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Characters can switch out Readied Items as a Free Action.
            <div style='height:1px;'></div><b>Carried</b> Items, such as in Backpacks, require an Active Action to pull out/put away.   
        </div><div style='height:2px;'></div><rulecardsubtitle>Item Damage</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            Items can be Damage by being struck or used to Block.
            <div style='height:1px;'></div><b>DR (Damage Reduction)</b> reduces Damage applied by the listed amount.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some Items may have different DR values for different Damage Types.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <f7><i><b>Ex:</b> 3 Dmg to an Item with DR1, is reduced to 1 Dmg.</i></f7>
            <div style='height:1px;'></div><b>Absorb</b> lists the maximum Dmg applied to the Armor. The rest is applied to the wearer.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Absorb is always applied after DR.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <f7><i><b>Ex:</b> 3 Dmg to an Item with Absorb 1, will apply 1 Dmg to the Armor and 2 to the Wearer.</i></f7>
            <div style='height:1px;'></div><b>Dmg</b> is usally the first points of a Dmg to an Item and can often be reparied.
            <div style='height:1px;'></div><b>Brk</b> is applied after Dmg is full and are more difficult to repair.
            <div style='height:1px;'></div><b>Dmg Back</b> is how much Dmg the Item does to whatever is striking it.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This Dmg ignored the DR of whatever it is applied to.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <f7><i><b>Ex:</b> When struck, and Item with Dmg Back <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, applies that much Dmg to the Item hitting it.</i></f7>
        </div><div style='height:2px;'></div><rulecardsubtitle>Item Mods</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            Items made of special materials may have their attributes altered.
            <br><f7><b>Rusty/Low Quality:</b> 1/2<b6>G</b6>. Half Brk and Dmg (rounded down). If Weapon: Takes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg every Hit. </f7>
            <br><f7><b>Mythril:</b> x2<b6>G</b6>. +3 Brk and Dmg. Weapon: <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> AP, +1 Bleeding (Slash), <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg (Bash). Armor: -33%<b6>E</b6>. </f7>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Resting + Weeks  <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>10</span></rulecardtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Day</b> Actions take an entire Day.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Characters may also atempt Day long challenges and other activities.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Shorter things such as conversations do not counts as an action.
            <br><b>Interim</b> Actions are those that cannot be done during Combat.
            <br><b>Daily</b> Actions occur at the end of the day.
        </div><div style='height:2px;'></div><rulecardsubtitle>Resting</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            Rest Actions is important as it's one of the few ways to remove Fatigue and Wounds.
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rest</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Fatigue</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Comfort</b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Remove 1 Fatigue.
                    <cs>2S:</cs> Remove 1 Illness.
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Limb Wounds<br> <f7>Once per Limb</f7></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Comfort</b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>2S:</cs> Remove 1 Wound/Broken/Infection.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Head/Torso Wounds</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Comfort</b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>2S:</cs> Remove 1 Wound/Mortal Wound.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Daily</rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Daily<br> Needs</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Thirst</div></div></challengeHead><challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Drinking 1 Drink:</b> Prevents 1 Thirst <b>OR</b> a <b style='font-weight:900;'>(W)</b> becomes Fatigue.
                    <br><b>Resisting Thirst:</b> Resist Thirst (Ex: 2) w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    <f7>
                    <br><b>Dirty Water:</b> Get <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Illness per Drink. <b>Foul Water:</b> Get <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Illness per Drink.
                    <br><b>Mixing Water:</b> When water is mixed it all becomes the dirtier type.
                    </f7>
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Hunger</div></div></challengeHead><challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Eating 1 Food:</b> Prevents 1 Hunger <b>OR</b> an <b style='font-weight:900;'>(H)</b> becomes a Fatigue.
                    <br><b>Resisting Hunger:</b> Resist Hunger (Ex: 1) w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Sleep</div></div></challengeHead><challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>No Sleep:</b> Must Resist Sleep (Ex: 1) Fatigue</u> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                    <div style='height:1px;'></div><f7><b>Sleepy:</b> When not Sleeping may need to Resist falling Asleep w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.</f7>
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Exposure</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <f7>
                    <b>Exposure</b> ranges from 0 (mild) to 3 (extreme) and can be from Heat or Cold.
                    <br>Rolled once per Exposure type applied (Ex: Cold 1 and Heat 1 would be 2 Checks.)
                    <br>Exposure may be modeified by conditions such as being wet or having shelter.
                    </f7>
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Warming/Cooling Dice</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Resist/Remove 1 Exposure of the associated type.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Week</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <f7>Characters may only take week when they have supplies (food, water, etc.) and a safe haven (place to sleep, livable climate) and are not in any danger (as defined by the GM.)</f7>
        </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Week</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    May take 6 Shift Actions.
                     Remove all Fatigue/Exposure/Illness at end of week. Remove <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress and Dread.
                    Remove <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wounds.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Other</rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Prepare</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Day Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    Increase preparation (usually per success). Typically requires Expertise.
                    <f7><i>Prepare a specific magical spell to disarm a trap, practice an infiltration manuever.</i></f7>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Feast</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>Spend 1 additional Food after everyone Party has ate.<br> All Characters doing a Feast Action gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale. <br> <f7>If Drinking Ale/Wine gain +1 Morale.</f7></div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Travel + Survival + Character Progression <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>11</span></rulecardtitle><rulecardsubtitle>Travel</rulecardsubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Travel</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    Travel 1 World Space. Resist <b>Travel Difficulty</b> Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br> <b>March:</b> May Travel additional World Space. 
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Additional Resist <b>1 + Travel Difficulty</b> Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-gap:1px;'>
            <div style='font-size: 8px;'>
                <b>Travel Difficulty:</b> Fatigue caused by traveling through different terrains.
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>0:</b> <i>Road.</i>
                    &nbsp;&nbsp;&nbsp;  <b>1:</b> <i>Trail, flat land.</i>
                    &nbsp;&nbsp;&nbsp;  <b>2:</b> <i>Wilderness, rough, snow.</i>
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>3:</b> <i>Mountainous, very rough, jungle, deep snow, swamp.</i>
                <br> <b>Travel Mods:</b> Things that make traveling harder. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Heavy Winds:</b> Increase Travel Fatigue by 1.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Dark:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Leg Wounds. <i>Ex: Night w/ Light or Full Moon.</i>
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Dangerous:</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Leg Wounds.
                <br><b>Carrying:</b> Adds Fatigue. Can be divided among Characters. <f7>Ex: Person +2</f7>
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Characters can Rest while carried, but w/o strecher apply Uncomfortable Mod <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>. 
                <br> <b>Other:</b> Additional Travel constraints.
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Horses:</b> Horses typically cannot do Level 3 Terrain.
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Wagons:</b> Wagons typically cannot do Level 2 Terrain and above.
            </div>
        </div><div style='height:2px;'></div><rulecardsubtitle>Survival</rulecardsubtitle><div  style='font-size: 8px;'>
           <b8>Cook</b8><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Improve food. Requires Fire, Cooking Supplies, may add Herbs. 
        </div>
        <div  style='font-size: 8px;'>
           <b8>Campfire</b8><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Warming Dice. Create Visibility <img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>. Required to cook food.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Creating A campfire: use Tinderbox Item ot Magic, ect. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Campfire is put out by rain and heavy snow, Need Shelter in these conditions.
        </div>
        <div  style='font-size: 8px;'>
           <b8>Wet</b8><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Unable to make a fire due to weather or region dampness.
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Forage</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>
                    &nbsp;&nbsp;&nbsp;  <b>Attempt Additional Forage:</b> Resist <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div>.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><b>Region Bonus</b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> 1 Rummage. <cs>1S:</cs> 2 Herbs. <cs>2S:</cs> 1 Food.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Find Shelter</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Resist:</b> <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><b>w</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>2S:</sc> May make Fire. +1 Warmth/Cool Dice.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><rulecardsubtitle>Character Progression</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            Characters progress though gaining <div style='display:inline; color:black; font-weight:800;'>XP</div>, <div style='display:inline; color:black; font-weight:800;'>AP</div>, and <b>Inspiration</b>.
            <br> <div style='display:inline; color:black; font-weight:800;'>XP</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Character's experience in battle. Gained through quests and combat.
            <br> <div style='display:inline; color:black; font-weight:800;'>AP</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Characters general experience. Gained through quests and exploration.
            <br> <b>Inspiration <div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> Knowledge, insight, or epiphanies to progress toward speicifc skills. 
            <br> Inspiration can be gained directly, by accumulating enough Successes over multiple Checks, passing a difficult Challenge, and many other ways.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; There are many ways to engage with the world to gain <b>Inspiration</b>.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Challenges:</b> Taking on difficult feats. Such as a daring climb or risky infiltration.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Exploration:</b> Finding new areas or unknown treasures.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Knowledge:</b> Reading a book or researching at a library.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Socialization:</b> NPCs may have knowledge or insights that Characters can learn from.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Training:</b> Teachers may impart Inspiration, for free or a price.
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle>Glossary <f8>A - H</f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>12</span></rulecardtitle><rulebox>
            <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>5</b>s do not count as Successes. Each additional applies <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doesn't effect <b>Resist/Rest/Catch Breath/Compose Self</b>.
            <div style='height:1px;'></div><b9>Absorb:</b9> How much Dmg Armor takes when Hit. See <b>Items Section</b>.
            <div style='height:1px;'></div><b9>Air Loss:</b9> Resist 2 Air Loss per Round w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>10:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div>. <b>20:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div>.</b> All Air Loss removed whenever able to breathe.
            <div style='height:1px;'></div><b9> Armor Piercing:</b9> Ignores that amount of DR and/or Absorb.
            <div style='height:1px;'></div> <div style='height:1px;'></div><b9>Bleed:</b9> Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>. Effect only appies upon 1 or more Dmg.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Each point applies Torso Dmg or Stamina Loss. Effected Character chooses.
            <div style='height:1px;'></div><b9>Blast:</b9> Dmg that is spread over multiple areas. See <b>Blast/Impact Section</b>.
            <div style='height:1px;'></div><b9>Blind:</b9> Can't see or react. When moving make a <b>Stumble</b>. <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> in some Terrain.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Stumble</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> <fc>0S:</fc> Knockdown occurs.
            <div style='height:1px;'></div><b9>Break:</b9> <b>On Limb:</b> Broken 10. <b>On Head:</b> Dying. <b>On Item:</b> Destroy Item.
            <div style='height:1px;'></div><b9>Burning:</b9> +1 Dmg to Body Area at end of every Round. <f7>(Includes Round recieved).</f7>
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Remove(Self) <i><f7>Full:<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/Active/Free <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><f7></i></b> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Remove(Ally) <i><f7>Full:<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>/Active</f7></i></b> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Each Water used adds <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Max 4). Submerged Removes completely.
            <div style='height:1px;'></div><b9>Broken:</b9> Can't use Limb. Remove with <b>Sleep/Receive Treatment</b>. See <b>Injuries Section</b>. 
            <div style='height:1px;'></div><b9>Bypass:</b9> Check when hitting armor. Successes use Armor's Bypass effect.
            <div style='height:1px;'></div><b9>Climbing:</b9> Must Hang/Climb every Round or fall. Cannot attempt <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; See <b>Climbing Section</b>.
            <div style='height:1px;'></div><b9>Collision:</b9> Spreads Dmg over multiple areas. See <b>Blast/Impact Section</b>.
            <div style='height:1px;'></div><b9>Comfort:</b9> Effect quality of rest. Typically provided by Inns. Adds dice to resting acions.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Negative comfort or discomfort applies a <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> instead.
            <div style='height:1px;'></div><b9>Contest:</b9> A Challenge where Characters attempt the same Check.
            <div style='height:1px;'></div><b9>Cooling Dice:</b9> Aids in Checks to Resist/Reduce Heat Exposure. See <b>Daily Section</b>.
            <b9>Corruption:</b9> Can't remove Harm from Body Area and each day it gains <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.
                 <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; May remove 1 Corruption anytime you would remove a Wound.
            <div style='height:1px;'></div><b9>Disarm:</b9> Item falls <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> spaces away in random direction.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Two Handed Items are disarmed if the Main Arm is Disarmed.
            <div style='height:1px;'></div><b9>Dmg Back:</b9> Does associated Damage, ignoring DR, to Item/Limb that Strikes it.
            <div style='height:1px;'></div><b9>DR:</b9> Damage Resistence. Reduces Dmg by that amount. May list applicable type.
            <div style='height:1px;'></div><b9>Dread:</b9> Long term mental damage. Con Point represented by <b style='font-weight:900;'>(D)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Each use of <b>1 Morale</b> removes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>Dread</b>.
            <div style='height:2px;'></div><b9>Dying:</b9> Slowly dying. Con Point represented by <b style='font-weight:900;'>(D)</b>. See <b>Injuries Section</b>.
            <div style='height:1px;'></div><b9>Encumbrence:</b9> How difficult an Item is to carry. See <b>Items Section</b>.
            <div style='height:1px;'></div><b9>Exposure:</b9> The effects of cold/warm weather. 
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Con Point represented by <b style='font-weight:900;'>(EH)</b> for Heat and <b style='font-weight:900;'>(EC)</b> for Cold.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; See <b>Daily Section</b>.
            <div style='height:1px;'></div><b9>Falling:</b9> Causes Impact Damage. See <b>Blast/Impact Section</b>.
            <div style='height:1px;'></div><b9>Fatigue:</b9> Long term exertion. Con Point represented by <b style='font-weight:900;'>(F)</b>.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Gain 1 Fatigue. <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px; '>2F</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Gain 2 Fatigue. <div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px; '>3F</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Gain 3 Fatigue.
            <div style='height:1px;'></div><div style='height:1px;'></div><b9>Flanking:</b9> If attacking Target from opposite sides, each attacker gets <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.
            <div style='height:1px;'></div><b9>Grappling:</b9> When Characters are linked by grabbing/wrestling. See <b>Grappling Section</b>.
            <div style='height:1px;'></div><b9>Hunger:</b9> Loss of energy due to lack of food. Con Point represented by <b style='font-weight:900;'>(H)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Eating 1 Food:</b> Prevents 1 Hunger (daily resist) <b>OR</b> an <b style='font-weight:900;'>(H)</b> becomes a Fatigue.
    </rulebox>
    </rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle>Glossary <f8>I - Z</f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'>13</span></rulecardtitle>
        <rulebox>
            <b9>Illness (I):</b9> Toll taken by sickness or disease. Con Point represented by <b style='font-weight:900;'>(I)</b>. 
            <div style='height:1px;'></div><b9>Impact:</b9> Dmg that is spread over multiple areas. See <b>Blast/Impact Section</b>.
            <div style='height:1px;'></div><b9>Infection:</b9> Can't use Limb.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Remove with <b>Receive Treatment/Amputation</b>. See <b>Injuries Section</b>. 
            <div style='height:1px;'></div><b9>Knockdown:</b9> Become Prone or Fall if climbing/on narrow ledge. Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>.
            <div style='height:1px;'></div><b9>Light:</b9> Counteracts Darkness and raises Visibility to that amount.
            <div style='height:1px;'></div><b9>Mend:</b9> Prevent Dmg <b>OR</b> Remove Harm. Prevented Dmg can still apply Bleeding.
            <div style='height:1px;'></div><b9>Mobile <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>:</b9> Requires the use of Limbs tagged with <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> (typically legs.)
            <div style='height:1px;'></div><b9>Morale:</b9> Character's longterm confidence and resolve. See <b>Morale Section</b>.
            <div style='height:2px;'></div><b9>Mortal Wound (M):</b9> Slowly dying. See <b>Injuries Section</b>.
            <div style='height:1px;'></div><b9>Pin:</b9> Stop Target's Movement and enter Grapple. If so may attempt Pin Actions. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dmg Effect only appies upon 1 or more Dmg. Pin Actions ignore Armor.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dmg from Pin Actions is applied to the Body Area Pin was applied to.
            <div style='height:1px;'></div><b9>Poison:</b9> Resist Poison w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> when recieving. Con Point represented by <b style='font-weight:900;'>(P)</b>. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Becomes <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Illness After Combat.
            <div style='height:1px;'></div><b9>Push/Pull:</b9> Move Target listed Spaces. May apply Collision. 
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Push over 1:</b> Knockdown.
            <div style='height:1px;'></div><b9>Rot:</b9> Limbs becoming gangrene. Con Point represented by <b style='font-weight:900;'>(R)</b>.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; See <b>Injuries Section</b>.
            <div style='height:1px;'></div><b9>Sever:</b9> Seperates a Character's from the Hit Body Area.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>On Head:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <fc>0S:</fc> Character is Dead. <fc>1S:</fc> Character is Dying.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>On Limb:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> <fc>0S:</fc> Lose Arm/Leg. +3 Bleed. <fc>1S:</fc> Lose Hand/Foot. +2 Bleed.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<f7>These effects are not prevented by Mend. Some effects may reattach Body Areas.</f7>
            <div style='height:1px;'></div><b9>Slowed:</b9> Some Effect is making it difficult for Character to move or act.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>1-3:</b> Pace is 1  (0 if already 1). <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>. <b>4 or more:</b> Can't Move, or attempt most Actions.
            <div style='height:1px;'></div><b9>Sinking:</b9> <i>Wearing metal armor, carrying heavy items.</i> Sink 1 Spaces per Round.
            <div style='height:1px;'></div><b9><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Stamina:</b9> Short term exertion. Con Point represented by <b style='font-weight:900;'>(<f12>&#8226;</f12>)</b>. Removed after combat.
                <div style='height:1px;'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; See <b>Stamina Section</b>.
            <div style='height:1px;'></div><b9>Step:</b9> Move 1 Space. Must not be Slowed and have a Pace of 1 or more.
            <div style='height:1px;'></div><b9>Stress:</b9> Fear or strain the linger. Con Point represented by <b style='font-weight:900;'>(S)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Removed by using <b>1 Morale</b>.
            <div style='height:1px;'></div><b9>Swimming:</b9> Can't breath unless at surface. Cannot attempt <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Actions.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; See <b>Swimming Section</b>. 
            <div style='height:1px;'></div><b9>Terror:</b9> Intense short term Fear. Con Point represented by <b style='font-weight:900;'>(T)</b>. Removed after combat.
            <div style='height:1px;'></div><b9>Thirst:</b9> Thrist and dehydration. Con Point represented by <b style='font-weight:900;'>(W)</b>.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Drinking 1 Drink:</b> Prevents 1 Thirst (daily resist) <b>OR</b> <b style='font-weight:900;'>(W)</b> becomes Fatigue.
            <div style='height:1px;'></div><b9>Two Hands <img 
        src='/Resources/Art/Images/Hand_L.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Hand_R.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>:</b9> Requires using Two Hands. <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> or impossible with one hand.
            <div style='height:1px;'></div><b9>Visibility:</b9> Can't see or react to anything more than X Spaces away.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some Actions may be done with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> in Low Light. For <b>Visibility 0</b> see <b>Blind</b>.
            <div style='height:1px;'></div><b9>Warmth Dice:</b9> Aids in Checks to Resist/Reduce Cold Exposure. See <b>Daily Section</b>.
            <div style='height:1px;'></div><b9>Wet:</b9> Unable to make a fire due to weather or region dampness.
            <div style='height:1px;'></div><b9>Will:</b9> Willpower and resolve. Goes away at end of Combat. See <b>Will Section</b>.
        </rulebox>
        </rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle> Vehicles  <f8></f8> <span style='color:white; float:right; font-weight:600; padding:0px 3px 0px 3px;'></span></rulecardtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Vehicles</b> are things which can carry Characters around. They can often also carry cargo, passengers, as well as take Dmg. 
            Vehicles are represented by Vehicle Cards, where the Vehicle information is stored.
        </div><rulecardsubtitle>Vehicle Travel</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Vehicle Travel</b> allows Characters to ride the Vehicle for days at a time, often with a room in the Vehicle for sleeping.
            <br> <b>Day Speed:</b> How far the Vehicle can travel in single day.
            <br> <b>Crew:</b> How many people are needed for the boat to able to travel in the boat.
            <br> <b>Occupants:</b> How many people the boat can carry. 
            <br> <b>Port:</b> Where a Vehicle can port, meaning dock and safely and unload cargo.
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Any:</b> Anywhere. <b>Port:</b> Any region port. <b>Deep Port:</b> Only select large ports.
            <br> <b>Adrift:</b> When a ship us broken or unmmanned and merely follows the ocean currents.
        </div><div style='height:2px;'></div><rulecardsubtitle>Cargo</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Cargo (C):</b> Each Cargo weight 10<b6>E</b6>. There are three kinds of Cargo:
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ships will list how many boxes of Cargo <b>(C)</b> the ship can carry.
            <br> <b>Food and Water Cargo:</b> Nourishes the crew with food/water.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ships will list how much Food and Water Cargo are used per week.
            <br> <b>Trade Cargo:</b> Can be traded in for profit when the ship docks at a port.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Like quests, profitability of trade depends on the journey the cargo travels.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Minor:</b> 10G per Cargo <b>Major:</b> 25G per Cargo <b>Epic:</b> 50G per Cargo

        </div><div style='height:2px;'></div><rulecardsubtitle>Crew Health/Morale</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Crew Health</b> states the the crews status regarding, injuries, sickness and death.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Injuries:</b> Wounds the crew has which can typicaly be healed through R&R.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Casualties:</b> Deaths and debilitating injuries. Removed through Hiring at a Port.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Critical:</b> Almost everyone on the crew is dead. Removed through Hiring at a Port.
            <b>Morale</b> is the mental health of the Crew.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>5 (Good):</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ship Actions and Daily Movement, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Weekly Movement.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>3-4 (Fine):</b> No effects.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>1-2 (Disgruntled):</b> Unhappy. May even pick fights. <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> on all Ship Actions. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>0 (Mutiny):</b> Adrift. Can't attempt Ship Actions. Typically an armed revolt occurs.
        </div><div style='height:2px;'></div><rulecardsubtitle>Oceans</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Ocean Regions</b> have information which describes how they effect travel through them.
            <br> <b>Wind:</b> This is done daily and may increase or decrease the ships travel speed that day.
            <br> <b>Drift:</b> This is the direction and distnace traveled if Adrift.
            <br> <b>Sea Challenge:</b> These are challenges that each PC with a Sailor Ability may attempt.
        </div><div style='height:2px;'></div><rulecardsubtitle>Vehicle Combat</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Vehicle Combat</b> occurs when there is combat between or on Vehicles.
            <br><b>Vehicle Combat Round</b> a Vehicle will move every 5 Rounds of Standard Combat. 
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If there is no Standard Combat occuring, this can be ignored.
            <br> <b>Combat Speed:</b> How far the Veicle travels in a single Vehicle Combat Round.
            <br> <b>Boat Combat:</b> Terrain on a boat in Combat is considered Difficult 1. 
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A strom or large waves are considered Difficult 2.
        </div><rulecardsubtitle>Ports</rulecardsubtitle><div style='padding: 0px 2px; font-size: 8px; '>
            <b>Personal:</b> 1G Full Repair	
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Small:</b> 2G + 1 Day per Dmg, 5G + 2 Days per Brk.
            <br><b>Medium:</b> 3G + 1 Day per Dmg, 10G + 5 Days per Brk.
            <br><b>Large:</b> 5G + 1 Day per Dmg, 20G + 7 Days per Brk.
            <br><b>Shore Leave:</b> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale and remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Injuries/Casulaties per week.
        </div></rulecard></div></div>


<div style='
width: 800px;
background: white; 
box-sizing: border-box;

margin-top: 15px;
margin-bottom: 0px;
padding: 5px;
border-radius:0px;
margin-bottom: 15px;
    
position: relative;
display: flex;
align-items: flex-start;
flex-direction: column;
'>
    <div style='
    display:grid;
    grid-template-rows: auto;
    grid-template-columns: auto;
    width: 100%;
    grid-gap: 2px;
    '>
        <div style='
        width:790px;
        display:grid; 
        grid-template-columns: 1fr; 
        grid-auto-flow: row; 
        grid-gap:1px;
        '>
            <div style='
            color: black;
            background:hsla(41.4,0%,78%,1);
            border-radius: 0px;
            border-bottom: 1px solid black;
            border-top: 1px solid black;
            padding: 2px 2px 2px 15px;
            margin-bottom: 0px;
            font-family: `Oswald`, sans-serif;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            font-size: 20px;
            '>
                Introduction
            </div>
            
        <SubTitle>
            Basics
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>WARPS</BasicsHeader>
            <BasicsText><div>
                An immersion focused RPG where players take on the role of Player Characters (PCs) and a Game Master (GM) takes on the roll of the world their exploring and all the Non-Player Characters (NPCs) within it.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Dice</BasicsHeader>
            <BasicsText><div>
                Players roll 6-sided Dice with each 5 or 6 counting as Successes. <b>Example:</b> <div style='display:inline-block; font-size:20px; margin-top:-5px;'>&#9858; &#9861; &#9860;</div> would be a result of 2 Successes.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Successes</BasicsHeader>
            <BasicsText><div>
                The more Successes a Character rolls on a Check (a roll of the dice) the better they perform on meeting their intended task.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Checks</BasicsHeader>
            <BasicsText><div>
                Resolution in WARPS is done via a Check which invovles rolling a given number of Dice, usually a Character's Value in an assocated Stat, and then counting the Successes.
                <br><b>Stats:</b> These describe a Characters core appitudes. A <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> of 3 would add 3 Dice.
                <br><b>Mods:</b> Some Abilities add Dice to Checks. These can be applied once per Check unless otherwise stated.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Resolution Keywords</BasicsHeader>
            <BasicsText><div>
                <b>Dice:</b> D6s. Added to a Check using a +<b style='font-weight:700; color: black;'>X<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> notation. Ex: +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> would add 2 Dice to a Check.
                <br><b>Value:</b> The amount of Points a Character has in a Stat.
                <br><b>Roll:</b> The total ampount of Dice being rolled for a Check. Includes all the Stats and any other added Dice.
                <br><b>Auto Successes:</b> Added to a Check using a +<b style='font-weight:700; color: black;'>X<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> notation. For example +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> would add 1 Success to the total.
                <br><b>Result:</b> Sumtotal of all Success, including those via the Roll and Auto Successes.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Check Types</BasicsHeader>
            <BasicsText><div>
                Checks can be categorized in the following ways:
                <br><b>Action Check:</b> Made as part of an Action (as opposed to an Action).
                <br><b>Challenge Check:</b> Made as part of a Challenge. Typically has one or more Stats.
                <br><b>Stat Check:</b> Check that invovles the associated Stat. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Resist</BasicsHeader>
            <BasicsText><div>
                Resist Checks Reduce the amount of something that would be applied.
                Each Success on Resist Check reduces it's points by 1.
                For example Burning 2 is being applied and a Character gets <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Resist in, than only Burning 1 would be applied instead.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Combat
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Rounds</BasicsHeader>
            <BasicsText><div>
                In situations where every second counts the game is broken into Rounds where each Character takes their Actions simultaneously. Each Round can be considered roughly 2 to 5 seconds long.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Spotlights</BasicsHeader>
            <BasicsText><div>
                The GM facilitates Rounds by breaking them into Spotlights. Typically a GM will ask which PCs want to be involved in a Spotlight. 
                A Spotlight is a focus on how two or more Characters interact with each other and perform their Actions. 
                Then the GM runs through how the Spotlighted Character’s Actions play out, as if happening roughly at the same time. The GM then moves to the next Spotlight until all PC/NPCs have gone.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Spaces</BasicsHeader>
            <BasicsText><div>
               Often in combat, the world is divided into roughly 5 feet by 5 feet Spaces, typically on Hex Grid.<br>These Spaces can be considered 5 feet tall and stacked vertcially as well. 
               <br><img 
        src='/Resources/Art/Images/HexagonW_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><b>:</b> Can only Target Effect the Space the Effect thakes place.
               <br><img 
        src='/Resources/Art/Images/HexagonW_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><b>:</b> Represents a single space unit. Additionally: <img 
        src='/Resources/Art/Images/HexagonW_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, <img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>, represent 2 and 3 spaces.
               <br><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><b>:</b> Represents one ranged unit. This is equivalent to 6 Space.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>It is recommended to use and on hand measuring short cut (like a roughly 6' pencil or marker.</i>
               <br><b>Line of Sight:</b> Most Hits go through each Space, meaning anything between them and the Target is Hit first, typically stopping the Hit.
               <br><b>Blast:</b> A type of Hit that covers and area, hitting everything inside.
               <br><b>Circle X:</b> Effects every Space X away from Effect. Circle 0 only effects the current Space.
               <br><b>Semi-Circle X:</b> Effects all Spaces X away in a Half-Circle from Effect. Semi-Circle 0 only effects the current Space. 
               <br><b>Cone X:</b> Effects all Spaces X away in a 45 degree cone from Effect. Cone 0 only effects the current Space. 
               <br><b>Thrown:</b> Travels in an arc, and may move over things in it's way.
               <br><b>Diagonals:</b> If a distance would be measured diagonally (vertically and horizontally) the distance is the shortest of the two.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Actions</BasicsHeader>
            <BasicsText><div>
                Each Round a Character may choose one Action, which may involve Attacking, Running, or many other options.
                Their are several types of Actions which can be divided into two major types, Combat Actions and Long Term Actions. 
                <br><b>Combat Actions:</b> While Combat Actions can be done out of Combat, they are often done in Combat situations and have a type determining how much focus they require in that setting.
                <br>&nbsp;&nbsp;&nbsp;<b>Use Action:</b> Something a Character can attempt as long as they can pay the cost. Additional restrictions may be listed.
                <br>&nbsp;&nbsp;&nbsp;<b>Active Action:</b> Can be mobile while doing, Can move Pace and Block/Dodge. Typically cannot move after attempting Active Actions.
                <br>&nbsp;&nbsp;&nbsp;<b>Full Action:</b> Require focus. Can only do the chosen Action. Cannot Move Pace or attempt Defend Action (ex:Block/Dodge)
                <br>&nbsp;&nbsp;&nbsp;<b>Defense Action:</b> Can be attempted as a reaction to an Attack.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Dodge Action:</b> Typically reduce Hit of Strike and Proj. Does not effect Blasts.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Block Action:</b> Typically reduce Hit of Strike only. If reduced to 0, apply Attack to Item/Body Area used to Block.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Cover Action:</b> Involves sheilding oneself with an object. Typically reduces Hit of Proj and Blast Hits.
                <br>&nbsp;&nbsp;&nbsp;<b>Free Action:</b> Can be done at any time. These may be done once per Round unless otherwise stated.
                <br>&nbsp;&nbsp;&nbsp;<b>Grapple Action:</b> While in a Grapple these are the only Actions you can do.
                <br><b>Long Term Actions:</b> These Actions typically take hours and cannot be done in Combat.
                <br>&nbsp;&nbsp;&nbsp;<b>Shift Action:</b> Action requires a signifigant part of a Character's Day. See the Shift + Daily + Downtime Section for more info.
                <br>&nbsp;&nbsp;&nbsp;<b>Interim Action:</b> Takes somewhere between 5 and 30 minutes.
                <br><b>Actions Sub-Types:</b> Actions may have one or more Sub-Types which may have in game consequences. Some examples are listed here, but there are others.
                <br>&nbsp;&nbsp;&nbsp;<b>Nurse:</b> A special type of a Shift Action. A Character can only be the the Target of a single Nurse Action at a time. 
                <br>&nbsp;&nbsp;&nbsp;<b>Prone:</b> Actions Characters can only do while Prone.
                <br>&nbsp;&nbsp;&nbsp;<b>Swimming:</b> Actions Characters can only do while in water deep enough to swim in.
                <br>&nbsp;&nbsp;&nbsp;<b>Climbing:</b> Actions Characters can only do while hanging/climbing on to a vertical surface.
                <br>&nbsp;&nbsp;&nbsp;<b>Practice:</b> Actions ussed to hone a Characters skills.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Action Mods</BasicsHeader>
            <BasicsText><div>
                Action Mods are listed in Actions listing situations/options which may apply changes to the Check.
                <br><b>Unless stated otherwise, all Action Mods can only be applied once.</b>
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Movement States</BasicsHeader>
            <BasicsText><div>
                In addition to the standard Standing other Movement States.
                In these Movement States Characters can only attempt Actions with the Movement State listed in the subtitle. (These often allow the CHaracters to access other Actions.)
                Switching from one movement state to other can involve an Action as Prone to Standing, but often is a Free Action (to start climbing from the ground.)
                <br><b>Prone:</b> Character is off their feet or otherwise on the ground.
                <br><b>Swimming:</b> Character is mostly/completely submerged in liquid.
                <br><b>Climbing:</b> Character is hanging on to a semi-vertical surface.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Effects</BasicsHeader>
            <BasicsText><div>
                The Effect of an Action, states what happens when the Action is attempted.
                <br>Some Effects have Sucess costs that must be expended from an associated Check.
                <br>&nbsp;&nbsp;&nbsp;<sc>XS:</sc> This effect can occur once if the associated Check has enough Successes to be expended on it.
                <br>&nbsp;&nbsp;&nbsp;<cs>XS:</cs> This effect can occur multiple times, as long as there are enough Success for each time activated.
                <br>&nbsp;&nbsp;&nbsp;<fs>XS:</fs> This effect occurs if the amount of Successes mathes the amount here, regardless of the ishes of the Character. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Pace</BasicsHeader>
            <BasicsText><div>
                How many Spaces a Character can freely move in a Round while attempting a Standard Action. Requires a Character be upright and have access to the Mobile Limbs. Mobile Limbs are marked with a <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> symbol.
                <br>Pace may be a type a movement across different environment types.
                <br><b>Pace Types</b> 
                <div style='margin-left:10px;'>
                    <b>Ground:</b> Moving over a relatively flat surface like walking. Pace is assumed to Ground based unless stated otherwise.
                    <br><b>Surface:</b> Can move across any surface even horizontal and inverted.
                    <br><b>Swim:</b> Moving through a liquid such as Water.
                    <br><b>Fly:</b> Moving through the Air. These often include a Min-Speed which must be moved or the Character falls. Flying Characters may move downwards up to 10 Spaces per Round.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Ascend:</b> The value Flying Characters can Ascend whenever moving through the Air. Sometimes Ascend may only be done via a Dash Action and/or Stamina.
                    <br><b>Float:</b> Floating through the air. May move in any direction.
                </div>
                <b>Large Creatures:</b> For Characters that take up more than 1 Space turning in place counts as moving a single Space.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Remove</BasicsHeader>
            <BasicsText><div>
                Remove is a special Action that is used to remove Con Points.
                Remove will list if it can be used as Full/Active/Free Action as well as the Check used.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>After Combat</BasicsHeader>
            <BasicsText><div>
                After Combat is over Characters may take a <b>Breather</b> which involves roughly 10 minutes to relax.
                <br>This allows Characters to remove Stamina Loss, Harm, Terror, and other temporary effects.
                <br>This is not possible if Characters ar being chased or are otherwise unable to take a break.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Attacks / Damage
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Attacks</BasicsHeader>
            <BasicsText><div>
                An Attack is typically an attempt to Harm another Character. The Attacker will make a Hit Check potentially counteracted by the Target’s Defensive Check. 
                The Attacker will then choose a Body Area to Hit from the Target’s Hit Box and apply Damage to it.
                <br><b>Attack Example:</b>
                <br>&nbsp;&nbsp;&nbsp;Attacker attempt Hit Check (<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>).
                Target attempts Dodge to Defend (<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>).
                This results in Attacker having <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit.
            	<br>&nbsp;&nbsp;&nbsp;Attacker chooses <sc>2S:</sc> <b>Torso</b> from Target’s Hit Box and rolls Damage (<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>).
            	Target records 4 Damage in Torso Damage Meter.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Hits</BasicsHeader>
            <BasicsText><div>
                When Attacking a Hit Check is made to determine the Hit Value of the Attacker.
                The remaining value left over after the Target's Defend Check can be used to choose a Body Area from the Target’s Hit Box.
                <br>Hits are denoted by Checks with a Hit Heading, which can be a <b>Strike</b> or a <b>Proj</b> (Projectile).
                <br>The Target may use a Defense Action to limit the Hit. Different tpyes of Defensive Actions may apply depending on the type of Hit.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Body Areas</BasicsHeader>
            <BasicsText><div>
                Each Character has a Hit Box with each Body Area that can be Hit, and a corresponding value needed to Hit it. When successfully Hit, Attacks typically apply Damage to the corresponding Damage Meter.
                <br>Arms are typically divided into a <b>Main Arm (M)</b> which is primarily used for holding weapons and special tasks, and an <b>Off Arm (O)</b>.
                <br>Some Hits, typically with <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> may require rolling a die to randomly determine which of the possible Body Areas is Hit.
                This effect can be ignored, and the body area chosen with an additiona success.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Damage</BasicsHeader>
            <BasicsText><div>
                Each Body Area has a Damage Meter broken into Harm, Wound, and Critical.
            	<br>&nbsp;&nbsp;&nbsp;<b>Harm:</b> Damage that can be removed in the short term. Broken into two phases with second often applying a debilitating effect.
            	<br>&nbsp;&nbsp;&nbsp;<b>Wound:</b> Damage that can typically only be removed over time.
            	<br>&nbsp;&nbsp;&nbsp;<b>Critical:</b> The Max Damage a Body Area can take, typically has a severe effect.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Damage<br>Types</BasicsHeader>
            <BasicsText><div>
                Damage can come in various forms, some of which may have certain interactions with certain armors, Characters, etc.
                <br>If Damage Types are seperated by a '/' then the ser may choose 1 of those whenever making an Attack. 
            	<br><b>Physical Damage:</b> Damage caused by physical trauma/force.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Bash:</b> Blunt force or bludgeoning damage such as from a hammer or club.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Slash:</b> Slicing or cutting damage such as from a sword or claws.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Pierce:</b> Penetrating damage such as from an arrow, or bullet.
            	<br><b>Energy Damage:</b> Damage that comes from focused energy, often from magic or technology.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Energy:</b> A generic type of Energy Damage which can be from many non-specific origins.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Fire:</b> Energy from heat or fire.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Ice:</b> Energy from concetrated cold or ice.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Elec:</b> Concentrated electrical energy.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Light:</b> Energy from concetrated light, often related to in-universe deities.
            	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Dark:</b> Energy from concetrated darkness, often related to in-universe deities.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Hands /<br>Mobility</BasicsHeader>
            <BasicsText><div>
                Some Body Areas have special uses/penalties when damaged. 
            	<br>&nbsp;&nbsp;&nbsp;<b>Hand <img 
        src='/Resources/Art/Images/Hand.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>:</b> Can be used to pick up and use items. Character drops anything held and cannot use Hand if lost.
            	<br>&nbsp;&nbsp;&nbsp;<b>Mobile <img 
        src='/Resources/Art/Images/Mobile.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>:</b> Used for a movement. Character cannot stand/move their listed Pace if lost.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Challenges
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Challenge</BasicsHeader>
            <BasicsText><div>
                A Challenge is a freeform Check typically prompted by the GM. This may include seeing if the Character can jump over a ravine, push a boulder, resist pain, etc.
                <br>The outcome is based on the number of Sucesses of the Challenge, with more required for a more difficult outcome.
                <br>Challenges can happen both and and out of Combat, and can be done as team, over time, or versus other Characters.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Challenge<br> Checks</BasicsHeader>
            <BasicsText><div>
                GMs may choose whatever Stats they feel are most appropriate for the Challenge.
                <br> <b>Multi-Stat:</b> These are combined from two different Stats. Ex: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>.
                <br> <b>Pure Stat:</b> These use only one Stat and add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Ex: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Multi-Round</BasicsHeader>
            <BasicsText><div>
                A type of Challenge where Successes are accumulated over time.
                These can add tension to make players work over multiple Round. Can be used in place of a very difficult check.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Contest</BasicsHeader>
            <BasicsText><div>
                A type of Challenge Success determined by winning a Check against one or more other Characters.
                Can be listed with a single stat, or with seperate Checks for the different Characters.
                Ties can be determined randomly by a 50/50 roll (Ex: Odds vs Evens).
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Constitution
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Constitution</BasicsHeader>
            <BasicsText><div>
                A Character's Constitution can be effected by Con Points such as Fatigue, Hunger, Dhydration, Drowsiness, Dread, etc.
                Con Points are logged in a Characters Status Section with each poin rcorded by its assocaited letter (Ex: 'H' for Hunger). Different Con Points have different means of removal.
                <br>The size of a Character's Status Meter is determined by their Species (typically 3).
                <br>As Characters gain too many detrimental Constitution Points they have a <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> Status applied to them. Even more points lead to a <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div> Condition.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Stamina</BasicsHeader>
            <BasicsText><div>
                A Characters Stamina can be used for doing Special Abilities, with each <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> putting a Stamina Point in the Constitution Meter.
                All Stamina Points gained are removed once a Character may take a 10 minute break.
            </div></BasicsText>
        </BasicsSection>
        <!--
        <BasicsSection>
            <BasicsHeader>Luck</BasicsHeader>
            <BasicsText><div>
                A Character's reserve of good fortune.
                <br> Can be used to apply +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to a Check or Prevent <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Damage.
            </div></BasicsText>
        </BasicsSection>
        -->
        <BasicsSection>
            <BasicsHeader><div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Will</div></BasicsHeader>
            <BasicsText><div>
                Will represents a Characters determination to push through fatigue and adversity.
                <br> Will can only be gained in Combat and is lost when Combat ends.
            </div></BasicsText>
        </BasicsSection>
            <BasicsSection>
            <BasicsHeader><div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div></BasicsHeader>
            <BasicsText><div>
                Morale is a Charactrer's mental strength and health. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Mental Effects</BasicsHeader>
            <BasicsText><div>
                Mental Effects are something negatively effects a Character's mental health. There are three types of Mental Effects: Terror, Stress, and Dread.
                <br>Each point of Terror/Dread goes into a Character's Constitution Meter with a Tr (Terror) or a Dr (Dread).
                <br><b>Terror</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>  Character's immediate mental anguish and fear over a situation.
                <br><b>Stress</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Lingering psychological trauma that can last for days.
                <br><b>Dread</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Long term psychological trauma with far ranging impacts.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Mental Breakdowns</BasicsHeader>
            <BasicsText><div>
                A Character can remove all Mental Effects they currently have with a Mental Breakdown. 
                In a Mental Breakdown a Character gains a Trauma Card.
                If a Character already has two Trauma Cards types they take an Insanity Card instead.
                A Character can only have up to one cards of this type.
                <br><b>Trauma:</b> A lingering mental problem such as Depression, Nightmares, or the Shakes.
                <br><b>Insanity:</b> A severe mental crisis that may end with the Character or others severely hurt or dead.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Timed Effects</BasicsHeader>
            <BasicsText><div>
                Some Con Points are timed and go down at the end of each Shift.
                For example a point of 'Fatigue (4 Shifts)' recorded as F4 would go down to a F3 at the end of the Shift.
                <br>If the Effect would go to 0 it is removed.
                <br>Timed Con Points can also be removed via the normal methods they would be removed with as well.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Abilities
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Abilities</BasicsHeader>
            <BasicsText><div>
                Abilities are one of the key things that define a Character.
                Abilities list several Character Skills that are granted to the Character that has them.
                Abilities are devided into Classes, Talentes, and Doctrines and are represented by Ability Cards, which Characters gain by Training.
                Sequenced Abilities must be gotten in order. (Ex: Runner 1 must be learned before Runner 2.)
                <blue>Only 1 Ability Card can be used in a single round, meaning Characters cannot use any Bonus or Action from two different Ability Cards in the same Round.</blue>
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Training</BasicsHeader>
            <BasicsText><div>
                Abilities are gained by Training.
                Training is done through the Train Action which grants Characters <div style='display:inline; color:black; font-weight:800;'>AP</div>.
                A Character cannot use the Skills assocaited with an Ability until they have fully trained it.
                <br> <b>Study:</b> Abilities with the Study keyword cannot be gained without a text to study from.
                    Some study materials are listed as Uncommon or Rare, meaning they are harder to find in the world.
                    (If a rarity is not listed, it is considered Common.)
                <br> <b>Teachers:</b> Teachers may grant bonuses to Train Actions.
                    If Training with a Teacher, Characters do not need a Study Material.
                    Any Character with an Ability may acts as a Teacher for another Character.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Classes</BasicsHeader>
            <BasicsText><div>
                Classes are a Character's primary combat skills.
                Class Abilities are often divided into levels.
                Classes also have an associated Class Card which contain information about the Class and can be used to track Class Training.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Talents</BasicsHeader>
            <BasicsText><div>
                Talents are mostly non-Combat Abilities such a Vocation or Athletic skill.
                Talents are divided into Talent Types.
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Athletics:</b> Physcial skills such as Climbing and Riding.</blue>
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Wilderness:</b> Skills that involve using or surviving in the wilderness.</blue>
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Crafts:</b> Creating Items from raw resources.</blue>
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Arts:</b> Artistic skills such as music and painting.</blue>
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Intellectual:</b> Study in specific field of knowledge.</blue>
                <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><b>Organization:</b> Memebership or rank in a organization within the world.</blue>
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Doctrines</BasicsHeader>
            <BasicsText><div>
                Doctrines represent a connection and worship of a god or divine being within the universe.
                The being grants specific special bonuses and abilities for performing acts and deeds supporting the deity. 
                It is up to GM to role play the interests and thoughts of the god.
                <br> <b>Initiation:</b> In addition to standard training, Characters must be initiated into a Doctrine.
                This Initation typically involves some physical ceremony to connect them to the will of the god.
                Initations are often done through an organization involved with the god, though sometimes the god may grant more direct forms of initation.
                <br> <b>Favor:</b> The interest or support of a god.
                Favor grants skills to Characters they may use.
                Favor is typically granted by a god for doing acts which they support and taken away for acts that go against their interests.
                Since GM's roleplay the gods, they may choose how much favor is granted or lost, though it typically is from 1, a minor act such a helping a begger, to 5, a large act such as destroying an opposing temple.
                GM's may role dice to determine how much Favor is granted from a god as well.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Other
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Interims</BasicsHeader>
            <BasicsText><div>
                An Interim is a preiod of time that typically takes between 5 and 30 minutes. 
                Interim Actions can only be done in this time. An Interim cannot take place if the Characters are rushed (Ex: Being chased.) 
                <br>A <b>Breather</b> is a common Interim Action in which Characters catch their breath and treat their wounds, allowing Characters to remove Stamina Loss and Harm.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Shifts</BasicsHeader>
            <BasicsText><div>
                Often in the world a Character’s journey are broken into longer time periods. Days are broken into Shifts of <b>Morning/Midday/Afternoon/Evening/Night</b>.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>World Spaces</BasicsHeader>
            <BasicsText><div>
                The world is divided in World Spaces, each with a diameter of aproximently 10 miles. Traveling through a World Space typically incurs resisting a listed amount of Fatigue usally ranging from 0 to 5.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Bonuses</BasicsHeader>
            <BasicsText><div>
                Many Classes and in-game effects will apply Bonuses (Dice, Successes, etc.) to Checks. Each type of Bonus may only be applied once per Check.
                For example a Character cannot apply a +1D Proficiency Bonus and a +2D Proficiency Bonus to the same Check.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Penalties</BasicsHeader>
            <BasicsText><div>
                Some in-game effects will apply Penalties (Dice, Successes, etc.) to Checks. Whenever recieving multiple Penalties of the same type, always only apply the greater one.
                For example a Character has a -2S Armor Pentaly and a -1S Armor Penalty, they would only apply the -2S Armor Penalty.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Rule Zero</BasicsHeader>
            <BasicsText><div>
                Because WARPS does not include a rule for everything possible thing, it is up to the GM to use/ignore/create rules as they see fit, according to what makes sense and what is best for the game/world they are playing.
            </div></BasicsText>
        </BasicsSection>            
        <SubTitle>
            Stats
        </SubTitle>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Stats</BasicsHeader>
            <BasicsText><div>
                Represent a Character's core characteristics. Act as the base value for most Checks.
            </div></BasicsText>
        </BasicsSection>

        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Strength
    </div></BasicsHeader>
            <BasicsText><div>
                Might, Muscularity, Physical power.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div></BasicsHeader>
            <BasicsText><div>
                Toughness, Pain Tolerance, Resistance to Damage.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endurance
    </div></BasicsHeader>
            <BasicsText><div>
                Stamina, Fitness, Health.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agility
    </div></BasicsHeader>
            <BasicsText><div>
                Speed, Mobility, Flexibility.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dexterity
    </div></BasicsHeader>
            <BasicsText><div>
                Coordination, Hitting, Deft Hands.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></BasicsHeader>
            <BasicsText><div>
                Alertness, Awareness, Sharpness.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Charisma
    </div></BasicsHeader>
            <BasicsText><div>
                Talking, Leading, Inspiring.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Intellect
    </div></BasicsHeader>
            <BasicsText><div>
                Problem Solving, Mental Power, Intuition.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></BasicsHeader>
            <BasicsText><div>
                Resolve, Will, Inner Strength.
            </div></BasicsText>
        </BasicsSection>
        
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Raising Stats</BasicsHeader>
            <BasicsText><div>
                Stats can be raised by training in Abilities.
                <br> Different cultures have different maximum values listed in Character Creation.
                After Character Creation the Character may raise a Stat up to 3 more than their Culture Maximum.
            </div></BasicsText>
        </BasicsSection>
        
        <!--
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='display:inline-block; border-style:solid; border-width:1px; font-weight:700; padding:0px 2px 0px 2px; background:Fuchsia; color: var(--Precision); border-color: black;'>Insight</div></BasicsHeader>
            <BasicsText><div>
                Ability to see solutions and make tactical decisions.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: Fuchsia;
        
        font-weight:700;
    '>
        Vigor
    </div></BasicsHeader>
            <BasicsText><div>
                Might and physical power. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: Fuchsia;
        
        font-weight:700;
    '>
        Athletics
    </div></BasicsHeader>
            <BasicsText><div>
                Speed and mobilty.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: Fuchsia;
        
        font-weight:700;
    '>
        Awareness
    </div></BasicsHeader>
            <BasicsText><div>
                Observation and clarity of mind.
            </div></BasicsText>
        </BasicsSection>
        -->
                    
        <SubTitle>
            Items
        </SubTitle>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Item Cards</BasicsHeader>
            <BasicsText><div>
                Each Item is represented by an Item Card taken by the Character who currently has the item.
                <br>There are several types of Items invluding Weapons, Armor, and others.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Encumbrance</BasicsHeader>
            <BasicsText><div>
                Items have an <b6>E</b6> <b>Value</b> representing how heavy or difficult to carry they are.
                When carried items are placed into <b6>E</b6> <b>Slots</b>. For example each Item with an <b6>E</b6> of 1, takes up one <b6>E</b6> Slot.
                <br> The amount of <b6>E</b6> Slots a Character can carry before becoming <b>Slowed</b> is the Character's <b>Capacity</b> value.
                <br><b>Capacity = <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> + <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> + <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> + Species Capacity Mod</b>
                <br> Some smaller items take up 1/5 <b6>E</b6>. These can be rounded down to 0, if carrying less than 5 in any particular Capacity area.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Carriers</BasicsHeader>
            <BasicsText><div>
                These carry other Items such as a backpack or puch and have <b6>E</b6> Slots for Characters to hold Items.
                <br> Any <b6>E</b6> Slots a Character has filled on a Carrier, are applied to the wearer's total.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Using Items</BasicsHeader>
            <BasicsText><div>
                <b>Held Items:</b> Held Items must be Held in order to use their Actions. A Character may hold 1 Item in each Hand.
                <br> Unless otherwise stated an Item can only be used for one Action per Round.
                For example, without an Ability that says otherwise, you cannot Attack and Block with the same sword in the same Round.
                <br><b>Readied Items:</b> These are Items that are worn on the body and can be Drawn as a Free Action. A Readied Item can usually be any Item 1<b6>E</b6> or Less. Ex: Sword worn on a belt.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Sidearm:</b> These Items can be Readied regardless of their <b6>E</b6>.
                <br><b>Worn Items:</b> Worn Items are Worn on the location stated. Armor worn only protect those locations when they are Hit.
                <br><b>Carried Items:</b> Carried Items are those that in in a backpack or similar. Usually getting an Item out of a Carrier is a Active Action.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Item Damage</BasicsHeader>
            <BasicsText><div>
                Items can take Damage similar to Characters. Like Characters, Items with DR reduce that Damage by the DR value.
                <br>Damage is applied to Item <b>Damage Points (Dmg)</b>, then, if no more remain, to Item's <b>Broken Points (Brk)</b>.
                <br>If no more Damage Points or Broken Points reamin, the Item is <b>Broken</b> and cannot be used until repaired.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Damage Resistance (DR):</b> Amount of Damage ignored. May list an associated Type it applies to, otherwise applies to all Damage.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Damage Points (Dmg):</b> Damage to Item that can usually be removed through field repairs.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Broken Points (Brk):</b> Damage to Item that requires special techniques or equipment to remove.
                <br><b>Full Block:</b> If an Item used to Block reduces a Hit is reduced to 0 (from 1 or more), apply Attack and Damage to Blocking Item/Body Area.
                <br><b>Armor:</b> Armor is worn to take Damage whenever it is applied to the Body Area the it is worn on.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Absorb:</b> When the Armor takes Damage the Absorb amount is applied to it's Damage/Broken Points.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Remaining, non-Absorbed Damage is applied to the wearer.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Bypass:</b> The Bypass effect listed is what occurs if a Successful Bypass is applied to it.
                <br><b>Broken:</b> Items that are Broken cannot be used as anything other than Improvised Weapons.
                    When a Weapon breaks it becomes of an Improvised Weapon it becomes the nearest Improvised Weapon of the GM's choice (Bludgeon, Shiv, Bulky Weapon, etc.) 
                <br><b>Dmg Back:</b> When items strike another Item with a Dmg Back value, the listed value of Dmg is applied to the item. This Damage value ignores DR.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Item Keywords</BasicsHeader>
            <BasicsText><div>
                Item Keywords apply special effects to Items.
                <br><b>Dmg Back:</b> Applies associated DM Back to whatever Body Area/Item that successfully Strikes it.
                <!--<br><b>Proficiency:</b> Rules after a <span><gc style='background: var(--Gray-2);'>P</gc></span>, require a character to have proficency with this item to do. 
                    <br>Rules after <gc style='background: var(--Gray-2);'>M</gc>, require a character to have master to do.-->
                <br><b>Threaten:</b> You+Target Attacking each other, <b>Contest:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>(You) vs. <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>(Target)
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Win:</b> Loser chooses: You get listed Bonus to Hit OR Loser can't Attack you this Round.
            </div></BasicsText>
        </BasicsSection>
        <!--
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Resources and Crafting</BasicsHeader>
            <BasicsText><div>
                Resources are types of Items that can often be used to craft other Items.
                General Resouces are often just listed by their type (Ex: Herb) while Special or Rare types are often listed specifically (Ex: Blood Flower (Herb)).
                <br><b>Special Resouces:</b> Specical and more valuable version of resource. These resources are worth x10<b6>G</b6> the price of the standard resource unless stated otherwise. 
                <br><b>Rare Resouces:</b> Rare and paticularly valuable version of the resource. These resources are worth x50<b6>G</b6> the price of the standard resource unless stated otherwise.
                <br><b>Reusing Resouces:</b> Turning a crafted Item back into resources can be done at GM discretion.
                    Typiclly Metal, Cloth, String can almost always be reused. 
                    Typicaly Remanants, Herbs, Stone, and Orichalcum cannot be reused.
            </div></BasicsText>
        </BasicsSection>
        -->
                    
        <SubTitle>
            Monsters and Non-Player Characters
        </SubTitle>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Non-Player Characters (NPCs)</BasicsHeader>
            <BasicsText><div>
                In WARPS GMs will control many other people and creatures. These are repsented using an <b>NPC Card</b> and, if appropriate, a <b>NPC Status Card</b>.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>NPC Card</BasicsHeader>
            <BasicsText><div>
                NPCs Cards contain all the information needed to NPCs in battle or in a campaign.
                <br><b>Basics:</b> The front of an NPC Card contains its Species (and possibly additional Species types), a reference picture, Hitbox, and information about how
                    it may fit into the campiagn or ecology of the world.
                <br><b>Stats, Difficulty, Body Areas, Common Action Dice (ex: Dash, Dodge, etc.)</b>
                <br><b>Abilities:</b> These are the special abilties the NPC can use. This may include special info about their body or special powewrs.
                    It may also include Tactics about how these abilities can be used. This section may also include basic species info such as Appitite or reward for defeatign them.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>Difficulty</BasicsHeader>
            <BasicsText><div>
                NPC Difficulty determines how dangerous NPCs are if engaged in Combat.
                <br><b>Normal:</b> An enemy which can be expected to take on a single PC. A '+' may used to designate an extra amount of danger.
                <br><b>Hard:</b> Hard enemies can pose a particular danger against a single PC, even able to take on 2 or 3 PCs at once.
                <br><b>Dire:</b> A single Dire enemy can take on a whole party at once and still pose a major threat.
                <br><b>Epic:</b> Epic levels are extremely dangerous if taken head on, and may eliminate an entire party if not careful.
                <br><b>Godly:</b> Beyond the scope of what a party may be able to defeat. Best avoided at all costs.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader style='padding:2px;'>NPC Status Card</BasicsHeader>
            <BasicsText><div>
                The NPC Status Card is used to track NPC data such as Damage or Stamina. One card can be used per NPC.
                An additional NPC Info Card can be used to track additional NPCs such as their name or story details.
            </div></BasicsText>
        </BasicsSection>
                </div>
    </div>
</div>

<div style='
width: 800px;
background: white; 
box-sizing: border-box;

margin-top: 15px;
margin-bottom: 0px;
padding: 5px;
border-radius:0px;
margin-bottom: 15px;
    
position: relative;
display: flex;
align-items: flex-start;
flex-direction: column;
'>
    <div style='
    display:grid;
    grid-template-rows: auto;
    grid-template-columns: auto;
    width: 100%;
    grid-gap: 2px;
    '>
        <div style='
        width:790px;
        display:grid; 
        grid-template-columns: 1fr; 
        grid-auto-flow: row; 
        grid-gap:1px;
        '>
            <div style='
            color: black;
            background:hsla(41.4,0%,78%,1);
            border-radius: 0px;
            border-bottom: 1px solid black;
            border-top: 1px solid black;
            padding: 2px 2px 2px 15px;
            margin-bottom: 0px;
            font-family: `Oswald`, sans-serif;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            font-size: 20px;
            '>
                Reward Reference
            </div>
            <BasicsSection>
            <BasicsHeader>Treasure</BasicsHeader>
            <BasicsText><div>
            <SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Red-2);'> <div>F</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 1x Copper Coin
                            <br> <b>Weapons:</b> Shiv, Bolt
                            <br> <b>Arrows:</b> Arrow, 3x Improvised Arrows
                            <br> <b>Other:</b> Rags, Herb, Torch (Improvised), Parchment
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Red-2);'> <div>E</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 3x Copper Coins
                            <br> <b>Arrows:</b> Quality Bolt, Quality Arrow
                            <br> <b>Other:</b> Holy Water, Spell Material, Pelt, Common Scroll, Oil Bottle (w/3 Oil), Torch (Quality), 50’ Rope (Weak), Bandages, Cloak, 10 Cigarettes, Cigar, Holy Fragment, Vial of Holy Water
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Orange-2);'> <div>D</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 5x Copper Coins, 1x Silver Coin
                            <br> <b>Weapons:</b> Throwing Blade, Club
                            <br> <b>Armor:</b> Leather Vambrace/Shoulder Pads, Leather Leg Guard, Leather Vest
                            <br> <b>Arrows:</b> 5x Arrows, 5x Bolts
                            <br> <b>Other:</b> Scroll (Common), Symbol of Mercy, Cooking Pot, Stamina Potion, Orichalcum, Healing Potion, 50’ Rope (Sturdy), 3x Spell Material, Drugs (Trip/Sleet/Fizzyn), Wine, Fiction Book
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Yellow-2);'> <div>C</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 5x Copper Coins, 1x Silver Coin, Bauble
                            <br> <b>Weapons:</b> Throwing Axe, Edged Club, Old Bow
                            <br> <b>Armor:</b> Leather Vambrace/Shoulder Pads, Leather Leg Guard, Leather Vest, Buckler, Round Shield,
                             <br> <b>Arrows:</b> 5x Quality Arrows, 3x AP Arrow, 3x Barbed Arrow, 3x Poison Arrow, 3x Fire Arrow, 5x Quality Bolts, Power Arrow, Elven Arrow, Black Arrow
                            <br> <b>Other:</b> Textbook (Common), Explosion Potion, Uncommon Scroll, Prayer Beads, Book of Azeal
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Yellow-2);'> <div>B</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 3x Silver Coins, 15x Copper Coins, 1x Gold Coin
                            <br> <b>Weapons:</b> Knife, Low Quality Sword, Low Quality Spear, Javelin
                            <br> <b>Armor:</b> Kite Shield, Tower Shield, Holy Shield, Unified Cross
                            <br> <b>Other:</b> Textbook (Uncommon), Spell Book (Empty), Quality Leather Boots, Lantern (w/ 3 Oil), Poison, Cheap Instrument
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Green-2);'> <div>A</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> Gold Bar, 4x Silver Coins, 20x Copper Coins
                            <br> <b>Weapons:</b> Crossbow, Dagger, Bow
                            <br> <b>Armor:</b> Gambeson (Short), Chainmail Hood, Metal Greaves, Gambeson (Long)
                            <br> <b>Other:</b> Textbook (Rare)
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Green-2);'> <div>A+</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 25x Copper Coins, 5x Silver Coins, 3x Gold Coins, Gem
                            <br> <b>Weapons:</b> Axe, War Hammer, Mace, Flail, Straight Sword, Curved Sword, Thrusting Sword, Spear, Glaive, Halberd
                            <br> <b>Armor:</b> Brigandine, Metal Skullcap
                            <br> <b>Other:</b> 50’ Rope (Superior), Rare Scroll, Instrument
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Turquoise-2);'> <div>S</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 35x Copper Coins, 7x Silver Coins, Mythril, Etherium
                            <br> <b>Weapons:</b> Large War Hammer, Large Axe, Longbow, Elven Bow, Great Sword
                            <br> <b>Armor:</b> Scale Cuirass
                            <br> <b>Other:</b> Quality Instrument
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Blue-2);'> <div>S+</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 65xCopper Coins, 10xSilver Coins, 5xGold Coins, Gold Ingot, Jewel, 2xGem
                            <br> <b>Armor:</b> Breastplate, Chainmail Tunic (Short), Great Helm, Chainmail Tunic (Long), Splint (Full Set), Arnet Helm
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Blue-2);'> <div>S++</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> Gold Idol, 10x Gold Coins, 25x Silver Coins, 2x Jewel
                            <br> <b>Armor:</b> Scale (Full Set)
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div><SideTitleContentGrid>
                    <RotatedTitleContainer style='background: var(--Blue-2); width:auto;'> <div>S+++</div> </RotatedTitleContainer>
                    <div style='display:grid; grid-gap:1px;'>
                        <div style='font-size: 9px;'>
                            <b>Treasure:</b> 200x Copper Coins, 40x Silver Coins, 20x Gold Coins, 3x Gold Ingots, 3x Jewel
                            <br> <b>Armor:</b> Plate (Full Set)
                        </div>
                    </div>
                </SideTitleContentGrid><div style='height:1px;'></div></BasicsText></div>
        </BasicsSection>            <BasicsSection>
            <BasicsHeader>Inspiration</BasicsHeader>
            <BasicsText><div>
                Represents Characters learning and growing from their experiences. Typically Characters will recieve 1-3 <b>Inspiration</b> per Session.
                <br>Combat <b>Inspiration</b> can recieved for:
                <br><b>Combat:</b> Typically 1 <b>Inspiration</b> per Combat, 3 <b>Inspiration</b> for a very dangerous Combat.
                <br><b>Quests:</b> 1 <b>Inspiration</b> for a Minor Quest, 3 <b>Inspiration</b> for a Major Quest.
            </BasicsText></div>
        </BasicsSection>
        <div style='height:2px;'></div><BasicsSection>
            <BasicsHeader>Quests</BasicsHeader>
            <BasicsText><div>
                <b>Quests</b> are tasks given in world typically with a reward in <b6>G</b6> per person based on difficulty and Character Level.
                <br><b>Minor ~25<b6>G</b6> (Level 1):</b> Local NPC asks the party to take care of a pest problem in his basement. Kill a few rats and be on your way.
                <br><b>Medium ~50<b6>G</b6> (Level 3):</b> The Town is being terrorized by a werewolf. Investigate what’s going on, find the werewolves lair near town and slay it.
                <br><b>Major ~75<b6>G</b6> (Level 5):</b> Land you arrive in is ruled by an evil wizard. Talk with the locals, find your way to his tower, defeat his many minions and kill him.
                <br><b>Epic ~100<b6>G</b6> (Level 7):</b> Travel Far away to a distant dungeon, encountering dangerous combats along the way. The dungeon takes a few days to clear and go through, and at the bottom an Epic Dragon Boss battle is fought.
            </BasicsText></div>
        </BasicsSection><BasicsSection>
            <BasicsHeader>Other</BasicsHeader>
            <BasicsText><div>
                <b>Puzzles:</b> Typically 1 <div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div> and taking about 20min to solve.
                <br><b>Journeys:</b> +<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> <div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div> Short (5 to 10 World Spaces), +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> <div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div> Long (+30 World Spaces). Some Journey's may grant <b>Inspiration</b> as well.
                <br><b>Major Tasks:</b> 1 - 2 <div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div> including investigations, fetching, searching, stealthing, building/crafting, survival, escape, intrigue, talking, etc.
            </BasicsText></div>
        </BasicsSection>        </div>
    </div>
</div>

<div style='
width: 800px;
background: white; 
box-sizing: border-box;

margin-top: 15px;
margin-bottom: 0px;
padding: 5px;
border-radius:0px;
margin-bottom: 15px;
    
position: relative;
display: flex;
align-items: flex-start;
flex-direction: column;
'>
    <div style='
    display:grid;
    grid-template-rows: auto;
    grid-template-columns: auto;
    width: 100%;
    grid-gap: 2px;
    '>
        <div style='
        width:790px;
        display:grid; 
        grid-template-columns: 1fr; 
        grid-auto-flow: row; 
        grid-gap:1px;
        '>
            <div style='
            color: black;
            background:hsla(41.4,0%,78%,1);
            border-radius: 0px;
            border-bottom: 1px solid black;
            border-top: 1px solid black;
            padding: 2px 2px 2px 15px;
            margin-bottom: 0px;
            font-family: `Oswald`, sans-serif;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            font-size: 20px;
            '>
                Regions and Settlements
            </div>
            
        <SubTitle>
            Regions
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Regions</BasicsHeader>
            <BasicsText><div>
                Regions represent the locations of the world. 
                A <b>Region Sheet</b> contains info that can be used to determine things such as Character's survival, encounters, visual discriptions, and weather.
                GMs can use either prebuilt Regions, make their own regions, or use basic Region info.
                Regions are divided into Region Basics, Scenery, Events, and Quests.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Region Types</BasicsHeader>
            <BasicsText><div>
                <b>Types:</b> Regions typs break regions into broad categories.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Arid:</b> Very dry and hot climates for large portions of the year.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Lush:</b> Very dense in plantlife.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Severe:</b> Is marked by very cold temperatures, either in the winter or year round.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Temperate:</b> Mostly conssiting of mild weather.
                <br><b>Sub Types:</b> These are sub types of biomes. Each has a corresponding General Region Sheet as well.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Alpine:</b> A high and cold biome usually found on steep mountain ranges and plateaus.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Badlands:</b> An area made up of mostly uneven rocks with little vegitation.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Chaparral:</b> A dry area with scatter shrubbery.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Coniferous:</b> A forest often made of tall evergreen trees and typically in higher and mountainous areas. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Desert:</b> An area made up primarily of grainu dry dirt and rolling sand dunes.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Forest:</b> A standard forest, typically in cool temperatures.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Ice Field:</b> An area consisting of massive ice shelves, often with fissures. Extremely dangerous.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Jungle:</b> An area of very dense trees and plantlife, often warm and humid.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Pastoral:</b> Cool area with long fields and some trees.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Plains:</b> Area of sparse woodlands along with grass and shrubs.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Tundra:</b> A barren area found in very cold climates.
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Wetlands:</b> A colder flooded area of trees and shallow water.
            </div></BasicsText>
        </BasicsSection>
        <SubTitle>
            Region Basics
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Region Basics</BasicsHeader>
            <BasicsText><div>
                Region Basics are used to determine the amount and kind of resources a Region has, as well as other standard survival information.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Temperature</BasicsHeader>
            <BasicsText><div>
                This describes the effects the region's temperature has on Characters such as Cold and Heat Exposure. This may change in certain seasons such as winter.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Scarcity Check</BasicsHeader>
            <BasicsText><div>
                For each World Space the GM may make a Scarcity Check using <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                The Scarcity Check determines things about the space such as how lush or barren the area is.
                <br> <cs>Barren 0S:</cs> Area has relatively low fauna, and comparitively less water/food/resources.
                <br> <cs>Standard 1S:</cs> Area average fauna/water/food/resources.
                <br> <cs>Plentiful 2S/3S:</cs> Area has relatively high amount of fauna, and comparitively more water/food/resources.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Forage Results</BasicsHeader>
            <BasicsText><div>
                Lists the results of a Character's Forage Roll such as how much Rummage is found.
                This may include an attempt to Hunt, which requires the use of an Bow and Arrow or some other Hunting tool.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Scenery</BasicsHeader>
            <BasicsText><div>
                Scenery is used to create a description of the environment. This can also be used a seed for a more expansive or person description as well.
                <br> There are Scenery descriptions for each type of area: Barren, Standard, and Plentiful.
                <br> Scenery can be chosen randomly or chosen by the GM.
            </div></BasicsText>
        </BasicsSection>
        <SubTitle>
            Events
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Events</BasicsHeader>
            <BasicsText><div>
                Events are things the Characters find or that happen to the Characters while in the region.
                <br> Events can be chosen by the GM or determined randomly, or mixed.
                Additionally Events can be used however the GM wants, including tying together different ones or using just parts to tie more directly into the sotry of the particular campaign.
                <br> Events are divided into categories such as Weather, Obstacles, Crossings, Settlements, Aid, Encounters, Interiors/Entrances, and Incidents.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Weather</BasicsHeader>
            <BasicsText><div>
                These are weather effects which may make it difficult to travel. They usually last for a set number of shifts. Sometimes these are determined by the season.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Obstacles</BasicsHeader>
            <BasicsText><div>
                Obsticles are things which impede the Character's travels, often creating additional hardship.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Barriers</BasicsHeader>
            <BasicsText><div>
                Barriers are very difficult to cross areas such as a river or ravine. These may involve a Crossing that can be used to pass them.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Crossing</BasicsHeader>
            <BasicsText><div>
                A Crossing is a bridge, ferry, or other method of getting through a Barrier, such as a river.
                These may also present a opportunity for a Challenge or Encounter such as a toll.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Settlements</BasicsHeader>
            <BasicsText><div>
                These are settlements, typically of humanoids, that are nuetral or helpful for the Characters.
                Often these involve Villages or Towns. See the Settlements section for more details.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Aid</BasicsHeader>
            <BasicsText><div>
                Aid are helpful events or beneficial things that Characters might find.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Encounters</BasicsHeader>
            <BasicsText><div>
                Encounters are the types of creatures that may fight or be dangerous to the Characters.
                When used by the GM these may be Active (acting the Characters), Passive (in a place where the Characters may choose to attack them), or Stalking (actively hunting, ambushing, or otherwise attempting to attach the party.).
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Interior/<br> Entrance</BasicsHeader>
            <BasicsText><div>
                These are locations that the Characters might explore. Often they have monsters or treaure inside.
                Additionally these section may be used to describe areas the Characters find themselves in.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Hooks</BasicsHeader>
            <BasicsText><div>
                These are things that might happen to the Characters of other kinds and may be used to trigger quests or move the narrative forward in other ways.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Quests</BasicsHeader>
            <BasicsText><div>
                <blue>Fill this out...</blue>
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            General Region
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>General Region</BasicsHeader>
            <BasicsText><div>
                Generals Regions are used to fill in for Regions that don;t have more specific information. These can be divided into biomes that best match the Region Type.
                <blue>These include Woods, Plains, Jungle, Desert, and Snow.</blue>
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Settlements
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Settlements</BasicsHeader>
            <BasicsText><div>
                Settlements are places where many creatures, typically humanoids, live and depending on the size offer various goods and services.
                <br> Settlements are divided into Villages, Towns, and Cities.
                Each type of Settlement has a cooresponding <b>General Settlement Sheet</b> which describes the basic activities and services available in the Settlement.                
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Villages</BasicsHeader>
            <BasicsText><div>
                Villages are the smallest type of Settlements and usually have a population between 50 to 100 people.
                <br> Villages may have special characteristics described by the Region they are in as well.
                <br> Villages are typically not marked on the map and are often instead found while moving through a Region.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Towns</BasicsHeader>
            <BasicsText><div>
                Towns are bigger than Villages but not as big as Cities and usually have a population between 500 to 5,000 people.
                <br> Towns are typically marked on the map though some not on the map may be sometimes be found in some Regions.
                <br> Like Villages Towns often have specific characteristics listed within the Region they are in.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Cities</BasicsHeader>
            <BasicsText><div>
                Cities are the biggest type of Settlement and typically have between 10,000 and 1,000,000 people.
                <br> Cities are almost always marked on the map. 
                In addition to a General City Sheet, most Cities have a <b>City Sheet</b> listing Scenery, Events, and Quests specific to that particualr City.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>City Sheets</BasicsHeader>
            <BasicsText><div>
                Each Specific City Cheet will have 
                <blue>Weather
                Holidays/Festivals
                Labor/Training
                Districts
                    Scenery
                    Locations
                    Events
                Jobs
                Quests
                Underworld(?)
                </blue>
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            Time Table
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Time Table</BasicsHeader>
            <BasicsText><div>
                In WARPS times passes as it normaly does, one day after another.
                Each day passed can be marked on the WARPS Time Table. Which has a place of Seasons, and Months.
                The Time Table may also be used to track various weather events.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Months and Seasons</BasicsHeader>
            <BasicsText><div>
                In WARPS each month is 28 days long to simplify tracking with each season (SPring, Summer, Fall, and Winter) being 3 months long.
                <br> In addition, various important days and holidays can be listed on the months section of the Time Table.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Weeks and Days</BasicsHeader>
            <BasicsText><div>
                The days and weeks section is used to track which date within the month is the current one and can also be used to track other events at the daily level as well.
            </div></BasicsText>
        </BasicsSection>
                </div>
    </div>
</div>

<div style='
width: 800px;
background: white; 
box-sizing: border-box;

margin-top: 0px;
margin-bottom: 0px;
padding: 5px;
border-radius:0px;
margin-bottom: 15px;
    
position: relative;
display: flex;
align-items: flex-start;
flex-direction: column;
'>
    <div style='
    display:grid;
    grid-template-rows: auto;
    grid-template-columns: auto;
    width: 100%;
    grid-gap: 2px;
    '>
        <div style='
        width:790px;
        display:grid; 
        grid-template-columns: 1fr; 
        grid-auto-flow: row; 
        grid-gap:1px;
        '>
            <div style='
            color: black;
            background:hsla(41.4,0%,78%,1);
            border-radius: 0px;
            border-bottom: 1px solid black;
            border-top: 1px solid black;
            padding: 2px 2px 2px 15px;
            margin-bottom: 0px;
            font-family: `Oswald`, sans-serif;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            font-size: 20px;
            '>
                Character Creation
            </div>
            
        <SubTitle>
            Introduction
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Introduction</BasicsHeader>
            <BasicsText><div>
                Character Creation is the process of the creating your Player Character for WARPS.
                You will likely have this Character for a while, so feel free to put as much thought as you need till you are satasfied with your Character.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Stat Points</BasicsHeader>
            <BasicsText><div>
                These points are used for Character Stats and other things that represent a Character's natural abilities and apititudes.
                <br>The amount of Stat Points a Character starts with and can spend is listed on their Culture Card.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Character Points (CP)</BasicsHeader>
            <BasicsText><div>
                Represent a Character's skills, knowledge, and training.
                <br>The amount of Character Points a Character starts with and can spend is listed on their Culture Card.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Inspiration &nbsp;<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></BasicsHeader>
            <BasicsText><div>
                Moments and experiences a Character had that allowed to gain knowledge and progress in their abilities. 
                <br>The amount of Character Points a Character starts with and can spend is listed on their Culture Card.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            1. Culture
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Culture Card</BasicsHeader>
            <BasicsText><div>
                A Culture Card sets the foundation of your Character. At the top will be the Culture, Species, and possibly a Species subtype.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Cultural Info</BasicsHeader>
            <BasicsText><div>
                At the top of the Culture Card will be info about the culture and society of your chosen Culture.
                This can be read or referenced at any time and can be used to help properly role play your Character's Culture and Species. 
                <br> <b>Subcultures</b> are more specific types of cultures within a larger one.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Starting Points</BasicsHeader>
            <BasicsText><div>
                This is the amount of <div style='display:inline; color:black; font-weight:800;'>CP</div> and <div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> your Character has to spend on Abilities and Aspects. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Stats</BasicsHeader>
            <BasicsText><div>
                This section includes all the Starting and Maximum Values for your Character.
                (If a starting Stat is not listed then the Starting Value is 0.)
                <br>1 Stat Point may be used to raise a Stat by 1.
                <br> <b>Max Stats:</b> A Character's max Stat at Character Creation is listed on the Culture Card. 
                    Other Stat raising effects can cause a Character to have up to 3 more in a Stat then the maximum listed on the Culture Card.
                    Some Aspect Cards may raise the maximum as well.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Background</BasicsHeader>
            <BasicsText><div>
                Choose a Background for your Character.
                <br>A Character's Background represents how they grew up, were raised, and/or the culture they were in.
                <br>Backgrounds often come with Talents Characters can choose, starting equipment and gold, and/or Stat Bonuses. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Other</BasicsHeader>
            <BasicsText><div>
                These include Special Abilities or Drawbacks specific to your chosen Culture.
                Some may be automatically applied to the Culture, while some require spending <div style='display:inline; color:black; font-weight:800;'>CP</div> to obtain.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            2. Character Sheet
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Character Sheet</BasicsHeader>
            <BasicsText><div>
                Take a Character Sheet cooresponding to your Species Card. (Ex: Human, Elf, Dwarf, etc.) The Species will determine which kind of Character Sheet your Character will use unless stated otherwise.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Stats</BasicsHeader>
            <BasicsText><div>
                Fill out your Stats from your Culture Card on Character Sheet.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Special Abilities</BasicsHeader>
            <BasicsText><div>
                Your Character Sheet may also list Species Abilities unique to that Species.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Capacity</BasicsHeader>
            <BasicsText><div>
                A Character's Capacity <b><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div> + <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> + <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> + Species Capacity Mod</b>
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            3. Cutomization
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Cutomization</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Customization is done via spending points <div style='display:inline; color:black; font-weight:800;'>CP</div> on Abilties, Aspects, and other Character creation options. 
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Abilities</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Abilities are represented by Ability Cards. These inclde both Talents, Classes, and Doctrines.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Classes</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Classes are represented by a Class Card, used to track progress within that class, and a Class Ability Card, which has a Characters skills gained from that Class.
                <br> <b>Unless stated otherwise, a Character may only put points into Level 1 Classes during Character Creation.</b>
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Doctrines</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Doctrines are represented by Doctrine Cards. They represent a Character's relationship with a God.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Aspects</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Aspects are represented by Aspect Cards and can be both positive, often called Edges, or negative, often called Drawbacks.
                Some have special stat reqirements as well.
                <br> <b>Edges</b> (Green Cards) are Aspects that provide a net-positive and require spending <div style='display:inline; color:black; font-weight:800;'>CP</div>.
                <br> <b>Drawbacks</b> (Red Cards) are Aspects that provide a net-negative and increase a Chacters spendable <div style='display:inline; color:black; font-weight:800;'>CP</div> when taken. A Character can have up to 5 Drawbacks.
                <br> <b>Stat Drawbacks</b> are special Drawbacks that bring a Stat to 0. A Character may take more than 1 but can only gain 1 SP this way.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Gold</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Character may spend their starting Gold on any items in the game.
                <br> Additionally 1<div style='display:inline; color:black; font-weight:800;'>CP</div> may be spend to gain 5<b6>G</b6>.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Other</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                1<b>SP</b> may be spend to gain 20<div style='display:inline; color:black; font-weight:800;'>CP</div> or 100<b6>G</b6>.
            </div></BasicsText>
        </BasicsSection>
                    
        <SubTitle>
            4. Background
        </SubTitle>
        <BasicsSection>
            <BasicsHeader>Background Card</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                The Background Card provides a space to flesh out your Character's look, personality, and history.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Basics</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                Basics are Character's Name, Age, and Birthdate. Typically a Birthdate is gained by choosing randomly.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Basics</BasicsHeader>
            <BasicsText><div style='width:100%;'>
                A Description typically includes things such as a Character's Height, Eye and Hair Color, and other notable physicla features.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Bio</BasicsHeader>
            <BasicsText><div>
                A Characters should have some information about where is from, their family, as well as some connections they ave in the world, such as friends or asssociates.
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Goals</BasicsHeader>
            <BasicsText><div>
                A drive that is personal to the Character and is worked out with the GM when chosen (this can often be in private).
                These should be difficult to accomplish, and can be can be from the Character Goal List, or created personally by the Player. 
                Either way, a Personal Goal should be worked out with the GM before the game starts.
                <br>You may choose a Personal Goal from this list or create your own.
                <div style='height:1px;'></div>
                <div style='background:white; display:grid; grid-template-columns:1fr; grid-gap:4px;'>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>See the World</b> See distant lands, perhaps even those before undiscovered.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Family Name</b> Prove your worth in pursuit of honor and glory for your family.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Wealth</b> Gain enough money that you can life a life of leisure and luxury.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Fame</b> Be known and beloved across the land.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Vengeance</b> You've been wronged and won't rest until you have justice.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Slayer</b> Vanquish a powerful beast for glory and honor.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Clear Name</b> Prove your innocence from a wrongful accusation.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Reclaim Past</b> Find something or someone lost from your past.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Serve God</b> Achieve a decisive victory in the name of your God.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Legendary Warrior</b> Win battles such that they will sing of for generations.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Legendary Blacksmith</b> Be renowned for incredible metal works.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Run a Business</b> Operate a succesful business producing a handy profit.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Frontiers of Knowledge</b> Comprehend the universe as no one has before.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Find Artifact</b> Find and claim a powerful artifact from a lost age.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Reclaim Thrown</b> Win back the wrongly taken throne for you or your clan.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Resurecetion</b> Bring someone back through foribdden dark magic.</div>
                        </div>
                    </div>
                    <div style='background:white display:grid grid-template-columns:1fr grid-gap:1px'>
                        <div style='display:grid grid-template-columns:1fr border:solid 1px black'>
                            <div style='font-size:9px; padding:2px 1px 0px 1px;'><b>Immortality</b> Seek dark and forbidden means to avoid death.</div>
                        </div>
                    </div>
                </div>
            </div></BasicsText>
        </BasicsSection>
        <BasicsSection>
            <BasicsHeader>Complications</BasicsHeader>
            <BasicsText><div>
                Complications are things that create challenges for Characters as they try to acheive their goals.
                These can be things such as crippling drug addiction, a feared enemy, or memory loss.
            </div></BasicsText>
        </BasicsSection>
                    <!--
                                                -->
            
        </div>
    </div>
</div>




</body>

</html>