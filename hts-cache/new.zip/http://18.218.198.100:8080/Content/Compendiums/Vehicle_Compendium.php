<html>
<head>
    <title>Vehicle Compendium</title>
    <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
</head>
<style type="text/css">
    body {
     width: 100%;
    }
    .linkHead0
    {
        font-weight: 900;
        padding-bottom: 5px;
        font-size: 16px;
    }
</style>
<body style='background:hsla(0,0%,40%,1); padding:5px;'>

    </div>
    <div style='margin:0px;'>
        <div style='color:white; font-weight:600; font-size:20px;'>Carts/Wagons</div>
        <div style='display:grid; grid-template-columns:auto auto auto; grid-gap:5px; justify-content:start;'><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:var(--Orange-4); color:white; border-radius:4px;'>Cart <f7>Vehicle: Cart</f7><div style='display:inline-block; float:right;'>20G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A simple cart that can be pulled by a person or animal.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>0</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>3</div></div></div><div style='display:grid; grid-template-columns:auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Pull</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>50<b6>E</b6>/5C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Pull</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Move 1 World Space. Requires someone steering.
                    <br> <b>1 Puller:</b> Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    <br> <b>2 Pullers:</b> Each resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        Comfort 0 (Can fit 3 people at once.)
        <br> Can only travel on Roads and flat ground.
        <br> Can be fitted with Sleds for snowy areas.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR1</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Cart</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:var(--Orange-4); color:white; border-radius:4px;'>Covered Wagon <f7>Vehicle: Cart</f7><div style='display:inline-block; float:right;'>50G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A large covered wagon that can be pulled by a person or animal.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>5</div></div></div><div style='display:grid; grid-template-columns:auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Pull</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>100<b6>E</b6>/10C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Pull</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Move 1 World Space. Requires someone steering.
                    <br> <b>1 Puller:</b> Resist 3 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    <br> <b>2 Pullers:</b> Each resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    <br> <b>3 Pullers:</b> Each resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                    </div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        Comfort 0 (Can fit 5 people at once.)
        <br> Can only travel on Roads and flat ground.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR1</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Cart</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div></div>        <div style='color:white; font-weight:600; font-size:20px;'>Personal Boats</div>
        <div style='display:grid; grid-template-columns:auto auto auto; grid-gap:5px; justify-content:start;'><div style='display:grid; grid-gap:2px; align-content:start; width:315.503; height:235.45; background:white; color:black;'><div style='font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:var(--Orange-4); color:white; border-radius:4px;'>Raft <f7>Vehicle: Tiny Boat</f7> <f8>10<img 
        src='/Resources/Art/Images/EWeight_White.svg' 
        height='9px'
        width='9px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f8><div style='display:inline-block; float:right;'>5G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A flat floating surface roughly 15' by 15' (3 space by 3 spaces).</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>N/A</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>8</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Drift</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>N/A</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Move <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> World Space. Resist 1 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>. Up to 3 Characters may attempt this. <f7>Requires Paddle.</f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Remove 1 Dmg from Vehicle.</div></challengeText></challengeContainer></div></actionContainter></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR1</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                Whenever Critical, the ship sinks.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1 Space. <f7>Requires Paddle.</f7>
                </div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        <f8>Ship goes in whatever direction the Drift of the area is (See Ocean Region.)
        <br> Ship can be carried overhead and used to navigate narrow rivers.</f8>
    </div></div><div style='display:grid; grid-gap:2px; align-content:start; width:315.503; height:235.45; background:white; color:black;'><div style='font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:var(--Orange-4); color:white; border-radius:4px;'>Canoe <f7>Vehicle: Tiny Boat</f7> <f8>10<img 
        src='/Resources/Art/Images/EWeight_White.svg' 
        height='9px'
        width='9px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f8><div style='display:inline-block; float:right;'>10G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A small hollow tube like craft about 10' (2 Spaces) long.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Row</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>N/A</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Move 1 World Space. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>. <f7>Requires Paddle.</f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Remove 1 Dmg from Vehicle.</div></challengeText></challengeContainer></div></actionContainter></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR1</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                Whenever Critical, the ship sinks.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1 Space. <f7>Requires Paddle. Max: 2 Spaces.</f7>
                </div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        Ship acts in normal Combat Rounds.
        <br> Ship can be carried overhead and used to navigate narrow rivers.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start; width:315.503; height:235.45; background:white; color:black;'><div style='font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:var(--Orange-4); color:white; border-radius:4px;'>Rowboat <f7>Vehicle: Small Boat</f7> <f8>40<img 
        src='/Resources/Art/Images/EWeight_White.svg' 
        height='9px'
        width='9px' 
        style='
            position: relative;
            top: -1px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f8><div style='display:inline-block; float:right;'>20G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A simple boat with oars for rowing about 10' (2 Spaces) long.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>5</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Row</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Move 1 World Space. Resist 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>. <f7>Requires Paddle.</f7>
                     Two CHaracters maydo this and instead Resist 1 Fatigue each.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Shift</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Remove 1 Dmg from Vehicle.</div></challengeText></challengeContainer></div></actionContainter></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR1</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                Whenever Critical, the ship sinks.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat<br> Movement</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><br><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1 Space. <f7>Requires Paddle. Max: 2 Spaces.</f7> 
                    <br> Two Characters can do this and add Successes.
                </div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        Can fit 2 extra passangers but becomes unstable.
    </div></div></div>        <br>
        <div style='color:white; font-weight:600; font-size:20px;'>Ships</div>
        <div style='display:grid; grid-template-columns:auto auto auto; grid-gap:5px; justify-content:start;'><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='height:32px; border-style:solid; border-width:1px; font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:white; color:black; border-radius:4px;'>Sailboat <f7>Vehicle: Small Boat</f7><div style='display:inline-block; float:right;'>50G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A single mast sailboat. About 60' long (12 spaces) and 20ft wide (4 spaces). There is a single cabin below deck.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>1</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>12</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Sail</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>5C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Dmg.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Week</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Do this twice, applying region wind each time.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        Comfort 0.
        <br> Fire Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        <br> 2 Cannon Slots (1 per side). Can have up to 6 Cots.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When taking Dmg a random Character on Vehilce takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
                <br> Whenever Critical, the ship starts to sink <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Round.
                <br> Additional Dmg over Critical is applied to Shore Up and then Sink.
            	     <b>5 Sink:</b> Lower Decks underwater. <b>10 Sink:</b> Goes under and is destroyed.
                <br> Additional Fire Damage over Critical applies Flaming.
            	     <b>5 Fire:</b> Inner decks on fire. Smoke makes it hard to breathe. <b>10 Fire:</b> A flaming husk.
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Critical Mast falls in a random direction. <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Dmg to anyone Hit.
                <br> When Mast is Critical ship cannot move is Adrift.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='font-size:8px; padding:0px 2px 0px 2px;'>May attempt each Action once per Vehicle Combat Round. At least one member of the crew must be to each Action.</div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1R. (Max:3R) &nbsp;&nbsp;&nbsp;  <sc>1S:</sc> May turn ship 1 Hex.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Emergency Repair</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Shore Up Points. <b>3 Shore Up Points:</b> Ship stops sinking.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shoot/Reload Cannon</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Fire any loaded cannon. Reload any non loaded cannon. <br> Any PC in area can add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Cannon reload.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Drop/Raise Anchor</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Dropped Achor:</b> Ship doesn’t move. <b>Raise Anchor:</b> Requires 2 Ship Round to Fully Raise Anchor</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Board</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>If within 1R may begin boarding ship.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='height:32px; border-style:solid; border-width:1px; font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:white; color:black; border-radius:4px;'>Caravale <f7>Vehicle: Medium Boat</f7><div style='display:inline-block; float:right;'>200G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>A double masted sailong ship. About 75' long (15 spaces) and 20ft wide (4 spaces). 
        It has 4 levels, and (1) raised stern and bow, (2) the main deck and a closed master's cabin and meeting room on the port side and a closed crew cabin on the stern side,
        (3) a lower deck with kitchen, storeroom, and 4 officer cabins, (4) a lower hold for storage.</div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>10</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>50</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Sail</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Port</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>15C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Dmg.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>R&R</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale.
                    <br> Additional <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale if using Alcohol Cargo.
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Injuries.
                    <br> Doctors/Surgeons on board removes <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Max:2)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Week)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Week</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Do this twice, applying region wind each time.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>50<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        <b>Supply/Cargo Prices:</b> <f8>Food (2G), Water (1G), Cargo (5G), Alcohol (2G)</f8>
        
        <br><b>Customization:</b>  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Figurehead (10G) <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sail (10G)  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Hull (10G) 
        <br> <b>Ship Morale:</b> <f7>Each adds 1 Ship Morale ath beginnning of Ship Combat. Ship Morale works like Morale but can only be applied to Vehicle Comba Actions.</f7>
        <div style='height:5px;'></div> Comfort 0.
        Fire Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        4 Cannon Slots (2 per side).
        Comes with 10 Cots.
        <br> Kitchen for cooking food.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px; font-size:10px;'><div style='display:grid; grid-gap:2px; grid-template-rows:auto 1fr;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Morale</div><div style='display:grid; grid-template-columns:1fr auto; border:solid 1px var(--Orange-4); font-size:8px; padding:1px; height:100%; align-self:stretch;'><div></div><div>
                    <b>5:</b> Good
                    <br><b>3-4:</b> Fine
                    <br><b>1-2:</b> Angry
                    <br><b>0:</b> Munity
                    </div></div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Health</div><div style='display:grid; grid-gap:2px; grid-template-columns:1fr auto auto; font-size:8px; padding:1px;'><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Injuries</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Casualties</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Critical</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Half Speed. All Actions <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Adrift. Can't attempt Actions.</div></div><div style='font-size:7px;'>
        Crew Eats <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food Cargo and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Water Cargo per Week. Overflow lowers morale.
        <br><b>Week w/o Food:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale. <b>Week w/o Water:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale
    </div></div></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Starboard Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Port Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Hull takes Dmg, each does <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Crew and a random Character on Vehilce takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
                <br> Whenever Critical, the ship starts to sink <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Round.
                <br> Additional Dmg over Critical is applied to Shore Up and then Sink.
            	     <b>5 Sink:</b> Lower Decks underwater. <b>10 Sink:</b> Goes under and is destroyed.
                <br> Additional Fire Damage over Critical applies Flaming.
            	     <b>5 Fire:</b> Inner decks on fire. Smoke makes it hard to breathe. <b>10 Fire:</b> A flaming husk.
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Forward Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Rear Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Critical a Mast falls in a random direction. <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Dmg to anyone Hit.	
                <br> When 1 Mast is Critical ship moves at have speed and when 2 are Critical ship cannot move is Adrift.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='font-size:8px; padding:0px 2px 0px 2px;'>May attempt each Action once per Vehicle Combat Round. At least one member of the crew must be to each Action.</div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1R. (Max:3R) &nbsp;&nbsp;&nbsp;  <sc>1S:</sc> May turn ship 1 Hex.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Emergency Repair</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Shore Up Points. <b>3 Shore Up Points:</b> Ship stops sinking.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shoot/Reload Cannon</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Fire any loaded cannon. Reload any non loaded cannon. <br> Any PC in area can add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Cannon reload.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Drop/Raise Anchor</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Dropped Achor:</b> Ship doesn’t move. <b>Raise Anchor:</b> Requires 2 Ship Round to Fully Raise Anchor</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Board</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>If within 1R may begin boarding ship.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='height:32px; border-style:solid; border-width:1px; font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:white; color:black; border-radius:4px;'>Longship <f7>Vehicle: Medium Boat</f7><div style='display:inline-block; float:right;'>120G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>
        About 75' long (15 spaces) and 20ft wide (4 spaces). 
        Has a single rowing deck and some limited storage space below deck.
        </div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>40</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>20</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Sail/Row</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>10C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail/Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>10<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.) 
                <br> If wind is bad may Row instead and crew Resists 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Dmg.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>R&R</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale.
                    <br> Additional <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale if using Alcohol Cargo.
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Injuries.
                    <br> Doctors/Surgeons on board removes <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Max:2)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Week)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail/Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Week</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Do this twice, applying region wind each time.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)
                <br> If wind is bad may Row instead and crew Resists 4 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        <b>Supply/Cargo Prices:</b> <f8>Food (3G), Water (2G), Cargo (5G), Alcohol (3G)</f8>
        
        <br><b>Customization:</b>  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Figurehead (5G) <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sail (5G)  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Hull (5G) 
        <br> <b>Ship Morale:</b> <f7>Each adds 1 Ship Morale at the beginnning of Ship Combat. Ship Morale works like Morale but can only be applied to Vehicle Comba Actions.</f7>
        <div style='height:5px;'></div> Comfort 0.
        Fire Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        Can become a Shelter against Rain if turned upside down on land.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px; font-size:10px;'><div style='display:grid; grid-gap:2px; grid-template-rows:auto 1fr;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Morale</div><div style='display:grid; grid-template-columns:1fr auto; border:solid 1px var(--Orange-4); font-size:8px; padding:1px; height:100%; align-self:stretch;'><div></div><div>
                    <b>5:</b> Good
                    <br><b>3-4:</b> Fine
                    <br><b>1-2:</b> Angry
                    <br><b>0:</b> Munity
                    </div></div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Health</div><div style='display:grid; grid-gap:2px; grid-template-columns:1fr auto auto; font-size:8px; padding:1px;'><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Injuries</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Casualties</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Critical</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Half Speed. All Actions <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Adrift. Can't attempt Actions.</div></div><div style='font-size:7px;'>
        Crew Eats <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food Cargo and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Water Cargo per Week. Overflow lowers morale.
        <br><b>Week w/o Food:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale. <b>Week w/o Water:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale
    </div></div></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Starboard Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Port Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Hull takes Dmg, each does <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Crew and a random Character on Vehilce takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
                <br> Whenever Critical, the ship starts to sink <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Round.
                <br> Additional Dmg over Critical is applied to Shore Up and then Sink.
            	     <b>5 Sink:</b> Lower Decks underwater. <b>10 Sink:</b> Goes under and is destroyed.
                <br> Additional Fire Damage over Critical applies Flaming.
            	     <b>5 Fire:</b> Inner decks on fire. Smoke makes it hard to breathe. <b>10 Fire:</b> A flaming husk.
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Critical a Mast falls in a random direction. <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Dmg to anyone Hit.	
                <br> When Mast is Critical ship can only move via rowing.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='font-size:8px; padding:0px 2px 0px 2px;'>May attempt each Action once per Vehicle Combat Round. At least one member of the crew must be to each Action.</div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1R. &nbsp;&nbsp;&nbsp;  <sc>1S:</sc> May turn ship 1 space (2 max) or reverse.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Emergency Repair</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Shore Up Points. <b>3 Shore Up Points:</b> Ship stops sinking.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Board</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>If within 1R may begin boarding ship.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='height:32px; border-style:solid; border-width:1px; font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:white; color:black; border-radius:4px;'>Galley <f7>Vehicle: Large Boat</f7><div style='display:inline-block; float:right;'>300G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>
        About 115' long (23 spaces) and 25ft wide (5 spaces). 
        Has a single rowing deck and roughly 10 small rooms and staoge areas below deck.
        </div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>100</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>20</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Sail/Row</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Any</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>25C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail/Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>15<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.) 
                <br> If wind is bad may Row instead and crew Resists 2 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Dmg.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>R&R</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale.
                    <br> Additional <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale if using Alcohol Cargo.
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Injuries.
                    <br> Doctors/Surgeons on board removes <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Max:2)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Week)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail/Row</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Week</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Do this twice, applying region wind each time.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)
                <br> If wind is bad may Row instead and crew Resists 4 Fatigue w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        <b>Supply/Cargo Prices:</b> <f8>Food (5G), Water (3G), Cargo (5G), Alcohol (5G)</f8>
        <br><b>Customization:</b>  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Figurehead (5G) <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sail (5G)  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Hull (5G) 
        <br> <b>Ship Morale:</b> <f7>Each adds 1 Ship Morale at the beginnning of Ship Combat. Ship Morale works like Morale but can only be applied to Vehicle Comba Actions.</f7>
        <div style='height:5px;'></div> Comfort 0. Comes with 5 Cots.
        Fire Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        <br> Can become a Shelter against Rain if turned upside down on land.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px; font-size:10px;'><div style='display:grid; grid-gap:2px; grid-template-rows:auto 1fr;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Morale</div><div style='display:grid; grid-template-columns:1fr auto; border:solid 1px var(--Orange-4); font-size:8px; padding:1px; height:100%; align-self:stretch;'><div></div><div>
                    <b>5:</b> Good
                    <br><b>3-4:</b> Fine
                    <br><b>1-2:</b> Angry
                    <br><b>0:</b> Munity
                    </div></div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Health</div><div style='display:grid; grid-gap:2px; grid-template-columns:1fr auto auto; font-size:8px; padding:1px;'><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Injuries</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Casualties</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Critical</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Half Speed. All Actions <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Adrift. Can't attempt Actions.</div></div><div style='font-size:7px;'>
        Crew Eats <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food Cargo and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Water Cargo per Week. Overflow lowers morale.
        <br><b>Week w/o Food:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale. <b>Week w/o Water:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale
    </div></div></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Starboard Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Port Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Hull takes Dmg, each does <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Crew and a random Character on Vehilce takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
                <br> Whenever Critical, the ship starts to sink <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Round.
                <br> Additional Dmg over Critical is applied to Shore Up and then Sink.
            	     <b>5 Sink:</b> Lower Decks underwater. <b>10 Sink:</b> Goes under and is destroyed.
                <br> Additional Fire Damage over Critical applies Flaming.
            	     <b>5 Fire:</b> Inner decks on fire. Smoke makes it hard to breathe. <b>10 Fire:</b> A flaming husk.
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Critical a Mast falls in a random direction. <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Dmg to anyone Hit.	
                <br> When Mast is Critical ship can only move via rowing.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='font-size:8px; padding:0px 2px 0px 2px;'>May attempt each Action once per Vehicle Combat Round. At least one member of the crew must be to each Action.</div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1R. &nbsp;&nbsp;&nbsp;  <sc>1S:</sc> May turn ship 1 space (2 max) or reverse.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Emergency Repair</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Shore Up Points. <b>3 Shore Up Points:</b> Ship stops sinking.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Board</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>If within 1R may begin boarding ship.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div><div style='grid-column: 1 / span 3; display:grid; grid-gap:2px; align-content:start; width:800.53; height:588.625; background:white; color:black;'><div style='display:grid; grid-gap:2px; align-content:start; width:800.53; height:400.265; background:white; color:black;'><div style='display:grid; grid-template-columns:3fr 5fr; grid-gap:2px;'><div style='display:grid; grid-gap:2px; align-content:start;'><div style='height:32px; border-style:solid; border-width:1px; font-size:10px; font-weight:600; padding:1px 2px 1px 2px; background:white; color:black; border-radius:4px;'>Frigate <f7>Vehicle: Large Boat</f7><div style='display:inline-block; float:right;'>500G</div></div><div style='font-size:8px; padding:0px 2px 0px 2px; font-style: italic;'>
        A triple masted sailong ship. About 130' long (26 spaces) and 35ft wide (7 spaces). 
        It has 5 levels, and (1) raised stern and bow, (2) the main deck with several meeting rooms and cabins around it,
        (3) a lower deck with kitchen, storeroom, and 10 officer cabins, (4) a crews quarters with room for about 80 people, (5) a large storage area.
        
        </div><div style='display:grid; grid-template-columns:1fr 1fr; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Crew Size:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>100</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Passengers:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>100</div></div></div><div style='display:grid; grid-template-columns:auto auto auto; grid-gap:1px; font-size:10px;'><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Type:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Sail</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Port:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>Deep Port</div></div><div style='display:grid; grid-template-columns:1fr auto;'><div style='border: solid var(--Orange-3) 1px; color:white; background:var(--Orange-3); border-radius:4px 0px 0px 4px; padding:0px 2px 0px 2px;'>Cargo:</div><div style='border: solid var(--Orange-3) 1px; border-radius:0px 4px 4px 0px; padding:0px 5px 0px 10px;'>40C</div></div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Day)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>10<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Ship Repair</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Remove 1 Dmg.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>R&R</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale.
                    <br> Additional <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Morale if using Alcohol Cargo.
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Injuries.
                    <br> Doctors/Surgeons on board removes <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (Max:2)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Actions (Week)</div></div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Sail</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Week</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Orange-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Do this twice, applying region wind each time.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Move 1 World Space. (See Region Wind.)</div></challengeText></challengeContainer></div></actionContainter></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Additional Info</div></div><div style='font-size:9px; padding:0px 2px 0px 2px;'>
        <b>Supply/Cargo Prices:</b> <f8>Food (5G), Water (3G), Cargo (5G), Alcohol (5G)</f8>
        
        <br><b>Customization:</b>  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Figurehead (15G) <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Sail (15G)  <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Hull (15G)
        <br> <b>Ship Morale:</b> <f7>Each adds 1 Ship Morale ath beginnning of Ship Combat. Ship Morale works like Morale but can only be applied to Vehicle Comba Actions.</f7>
        <div style='height:5px;'></div> Comfort 0.
        Fire Resist <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
        8 Cannon Slots (4 per side).
        <br> Comes with 20 Cots, 1 Bed, and 2 Cannons.
        <br> Kitchen for cooking food.
    </div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='display:grid; grid-template-columns:1fr 2fr; grid-gap:2px; font-size:10px;'><div style='display:grid; grid-gap:2px; grid-template-rows:auto 1fr;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Morale</div><div style='display:grid; grid-template-columns:1fr auto; border:solid 1px var(--Orange-4); font-size:8px; padding:1px; height:100%; align-self:stretch;'><div></div><div>
                    <b>5:</b> Good
                    <br><b>3-4:</b> Fine
                    <br><b>1-2:</b> Angry
                    <br><b>0:</b> Munity
                    </div></div></div><div style='display:grid; grid-gap:2px; align-content:start;'><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Crew Health</div><div style='display:grid; grid-gap:2px; grid-template-columns:1fr auto auto; font-size:8px; padding:1px;'><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Injuries</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Casualties</div><div style='color:white; background:var(--Orange-4); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Critical</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Half Speed. All Actions <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center; font-size:7px;'>Adrift. Can't attempt Actions.</div></div><div style='font-size:7px;'>
        Crew Eats <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Food Cargo and <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Water Cargo per Week. Overflow lowers morale.
        <br><b>Week w/o Food:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale. <b>Week w/o Water:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Crew Heath, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Morale
    </div></div></div><div style='color:white; background:var(--Orange-4); font-size:10px; padding:0px 2px 0px 4px; border-radius:4px 4px 0px 0px; margin-bottom:-1px;'>Vehicle Areas</div><div style='display:grid; grid-template-columns:auto auto auto auto auto auto; grid-gap:1px; font-size:10px; border: solid var(--Orange-3) 1px; border-radius:4px;'><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:4px 0px 0px 0px; padding:0px 2px 0px 2px;'>Hit</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Armor</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Name</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Dmg</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 0px 0px 0px; padding:0px 2px 0px 2px;'>Brk</div><div style='color:white; background:var(--Orange-3); font-weight:600; border-radius:0px 4px 0px 0px; padding:0px 2px 0px 2px;'>Crt</div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Starboard Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Port Hull</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Hull takes Dmg, each does <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Crew and a random Character on Vehilce takes <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg.
                <br> Whenever Critical, the ship starts to sink <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Round.
                <br> Additional Dmg over Critical is applied to Shore Up and then Sink.
            	     <b>5 Sink:</b> Lower Decks underwater. <b>10 Sink:</b> Goes under and is destroyed.
                <br> Additional Fire Damage over Critical applies Flaming.
            	     <b>5 Fire:</b> Inner decks on fire. Smoke makes it hard to breathe. <b>10 Fire:</b> A flaming husk.
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Forward Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Mid Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
            </div><div style='grid-column:span 6; border-style:solid none none none; border-radius:0px; border-width:1px; border-color:black; height:2px;'></div><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>DR2</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'>Rear Mast</div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div><div style='display:inline-block; width:3px;'></div><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='font-weight:600; padding:0px 2px 0px 2px; text-align:center;'><div style='display:inline-block; border:black 1px solid; border-radius:100px; width:10px; height:10px;'></div></div><div style='grid-column:span 6; font-weight:400; padding:0px 2px 0px 7px; font-size:7px;'>
                When Critical a Mast falls in a random direction. <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Impact Dmg to anyone Hit.	
                <br> When 1 Mast is Critical ship moves at have speed and when 2 are Critical ship cannot move is Adrift.
            </div></div><div style='display:grid; grid-template-columns:1fr; grid-gap:2px; font-size:10px;'><div style='color:white; background:var(--Orange-4);  padding:0px 2px 0px 4px; border-radius:4px 0px 0px 0px; margin-bottom:-1px;'>Vehicle Combat Actions</div></div><div style='font-size:8px; padding:0px 2px 0px 2px;'>May attempt each Action once per Vehicle Combat Round. At least one member of the crew must be to each Action.</div><div style='display:grid; grid-gap:2px; font-size:10px'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Combat Movement</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Ship moves 1R. (Max:4R) &nbsp;&nbsp;&nbsp;  <sc>1S:</sc> May turn ship 1 Hex.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Emergency Repair</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Shore Up Points. <b>3 Shore Up Points:</b> Ship stops sinking.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shoot/Reload Cannon</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Fire any loaded cannon. Reload any non loaded cannon. <br> Any PC in area can add <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Cannon reload.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Drop/Raise Anchor</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Dropped Achor:</b> Ship doesn’t move. <b>Raise Anchor:</b> Requires 2 Ship Round to Fully Raise Anchor</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Board</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>If within 1R may begin boarding ship.</div></challengeText></challengeContainer></div></actionContainter></div></div></div></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:47.09; background:lightgrey;'></div><div style='border-style:solid none none none; border-color:grey; border-radius:0px; border-width:2px;height:70.635'></div><div style='border-style:dotted none none none; border-color:black; border-radius:0px; border-width:2px;'></div></div></div>    </div>
</body>
</html>