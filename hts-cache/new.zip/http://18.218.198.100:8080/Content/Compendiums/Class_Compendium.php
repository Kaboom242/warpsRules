<html>
<head>
    <title>Classes Compendium</title>
    <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
</head>
<style type="text/css">
    body {
     width: 100%;
    }
    .linkHead0
    {
        font-weight: 900;
        padding-bottom: 5px;
        font-size: 16px;
    }
</style>
<body style='background:hsla(0,0%,40%,1); padding-left:5px;'>
    <!--<div style='background:white; color:black; font-size:8px; padding:2px; display:grid; grid-template-columns:auto auto auto; grid-gap:5px;'>-->
    <!--    <div>-->
    <!--        <b><u><f10>Key</f10></u></b>-->
    <!--    </div>-->
    <!--    <div>-->
    <!--        <bpcombat>Combat</bpcombat></b>-->
    <!--        <br>&nbsp;&nbsp;&nbsp;<bpcombat>Offense (O):</bpcombat> Hitting, Damaging-->
    <!--        <br>&nbsp;&nbsp;&nbsp;<bpcombat>Defense (D):</bpcombat> Mitigating Hits, Mitigating Dmg-->
    <!--        <br>&nbsp;&nbsp;&nbsp;<bpcombat>Control (C):</bpcombat> Crowd Control-->
    <!--        <br>&nbsp;&nbsp;&nbsp;<bpcombat>Support (S):</bpcombat> Helping Others, Will, Mend, Soothe-->
    <!--    </div>-->
        
    <!--    <div>-->
    <!--        <bpgold>Gold:</bpgold> Making Money-->
    <!--        <br><bpsurvival>Survival:</bpsurvival> Food, Water, Travel-->
    <!--        <br><bprecovery>Recovery:</bprecovery> Removing Wound, Removing Fatigue, Morale-->
    <!--        <br><bputility>Utility:</bputility> Challenges, Other weird stuff (knowing languages)-->
    <!--    </div>-->
    <!--</div>-->
    <div style='position: fixed; left: 0px; top: 0px; display: flex; flex-direction: column; height: 100%; background: white; padding: 5px;'>
        <a class=linkHead0 href='#Archer'>Archer</a>
        <a class=linkHead0 href='#Barbarian'>Barbarian</a>
        <a class=linkHead0 href='#Bard'>Bard</a>
        <a class=linkHead0 href='#Cleric'>Cleric</a>
        <a class=linkHead0 href='#Druid'>Druid</a>
        <a class=linkHead0 href='#Fighter'>Fighter</a>
        <a class=linkHead0 href='#Mage'>Mage</a>
        <a class=linkHead0 href='#Monk'>Monk</a>
        <a class=linkHead0 href='#Rogue'>Rogue</a>
    </div>
    <div style='margin-left: 100px;'>
    <div style='display: grid;grid-template-rows: 1fr;grid-template-columns: repeat(auto-fill, 356px);grid-gap: 8px 8px;grid-auto-flow: row;'><div id='Archer' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Archer</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Turquoise-4);'>
            <div>Archer (Class) <f8>Req: Survivalist</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Archers</b> specialize in using bows for Ranged Combat.
            Most Archers begin to learn their trade hunting in the wilderness.
            Some continue to specialize in wilderness survival, while others can be found in armies or outlaw bands.
            <br> <b>Aim</b> is used by Archers to hone in on Targets and deliver the arrow with enhanced accuracy.
            Doing so allows them to do aim better, do additional damage, and other feats. 
        </rulebox><abilitysubtitle class='astTurquoise'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astTurquoise' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Archer 1  
            </abilitysubtitle>
            <abilitysection class='asecTurquoise' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astTurquoise' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Archer 2 
            </abilitysubtitle>
            <abilitysection class='asecTurquoise' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Turquoise-3);'>
                More Aim options (Dmg/Bleed, Knockdown, Range), cheaper Quick Reload, Snipe.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astTurquoise' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Archer 3
            </abilitysubtitle>
            <abilitysection class='asecTurquoise' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Turquoise-3);'>
                Active Shot, more/improved Aim options (Bullseye, Arc Shot, Disarm).
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astTurquoise'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astTurquoise'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Turquoise-4);'>
            <div>Archer 1</div> 
        </rulecardtitle><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Can't use Abilities in Heavy Armor</b>
        </rulebox><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Shooting Skill:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hunt and Shooting Challenges.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Fletch</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Make an Improvised Arrow.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Quick Firing
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Quick Fire</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Quick Reload:</b> May Nock Arrow as a Free Action.
                    <div style='height:1px;'></div><b>Practiced Nock:</b> May Nock an Arrow as an Active Action.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Aim
        </abilitysubtitle><div style='font-size:7px;'>
            <keywordTurquoise>Aim</keywordTurquoise> Points represent an archer's concentration and are directed at a single Target.
            <br><keywordTurquoise>Aim</keywordTurquoise> Points are lost any Round not doing the <keywordTurquoise>Aim</keywordTurquoise> Action.
        </div><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px; border-radius:4px; color:black; '><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Aim</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>Can be done whenever an arrow is nocked or nocking.</f7>
                        <br><cs>1S:</cs> +1 <keywordTurquoise>Aim</keywordTurquoise> towards Target.
                        <br><b>Not Shooting This Round</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='font-size:10px; padding:2px 2px 1px 1px; display:flex; align-items:center; justify-content:flex-end; border-radius:2px; background:white; border:solid 1px var(--Turquoise-3); border-radius:4px;; display:grid; grid-template-columns:1fr; grid-gap:1px; font-size:10px;'>
                <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:3px; ' >/2&nbsp; <keywordTurquoise>Aim</keywordTurquoise></div>
            </div>
        </div><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <div style='height:1px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Shoot. (May do twice.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b>Friendly Fire</b> Check.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>.
        </rulebox></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Turquoise-4);'>
            <div>Archer 2</div> 
        </rulecardtitle><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Can't use Abilities in Heavy Armor</b>
        </rulebox><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Shooting Skill:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hunt and Shooting Challenges.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Fletch</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Make an Improvised Arrow.
                            <br><cs>2S:</cs> Make an Arrow into a Quality Arrow.
                            <br><cs>1S:</cs> Make an Arrow+Poison into a Poison Arrow.
                            <br><cs>2S:</cs> Make a Bolt into a Quality Bolt.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Quick Firing
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Quick Fire</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Practiced Nock:</b> May Nock an Arrow as an Active Action.
                    <div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Quick Reload:</b> May Nock Arrow as a Free Action.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Aim
        </abilitysubtitle><div style='font-size:7px;'>
            <keywordTurquoise>Aim</keywordTurquoise> Points represent an archer's concentration and are directed at a single Target.
            <br><keywordTurquoise>Aim</keywordTurquoise> Points are lost any Round not doing the <keywordTurquoise>Aim</keywordTurquoise> Action.
        </div><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px; border-radius:4px; color:black; '><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Aim</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>Can be done whenever an arrow is nocked or nocking.</f7>
                        <br><cs>1S:</cs> +1 <keywordTurquoise>Aim</keywordTurquoise> towards Target.
                        <br><b>Not Shooting This Round</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='font-size:10px; padding:2px 2px 1px 1px; display:flex; align-items:center; justify-content:flex-end; border-radius:2px; background:white; border:solid 1px var(--Turquoise-3); border-radius:4px;; display:grid; grid-template-columns:1fr; grid-gap:1px; font-size:10px;'>
                <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:3px; ' >/3&nbsp; <keywordTurquoise>Aim</keywordTurquoise></div>
            </div>
        </div><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <div style='height:1px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Shoot. (May do twice.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b>Friendly Fire</b> Check. (May do twice.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bleeding.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +3 Hex. May do twice.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Shot to the Leg cause <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Knockdown (Resist w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>).
        </rulebox></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Turquoise-4);'>
            <div>Archer 3</div> 
        </rulecardtitle><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Can't use Abilities in Heavy Armor</b>
        </rulebox><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <b>Shooting Skill:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hunt and Shooting Challenges.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Fletch</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> Make an Improvised Arrow.
                            <br><cs>2S:</cs> Make an Arrow into a Quality/Armor Piercing/Barbed Arrow.
                            <br><cs>1S:</cs> Make an Arrow+Poison into a Poison Arrow.
                            <br><cs>1S:</cs> Make an Arrow+Oil into a Fire Arrow.
                            <br><cs>2S:</cs> Make a Bolt into a Quality Bolt.
                            
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Quick Fire
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Quick Firing</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Active Nock:</b> May Nock an Arrow as an Active Action.
                    <div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Quick Reload:</b> May Nock Arrow as a Free Action.
                    <div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Active Shot</b>: May Shoot as an Active Action.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astTurquoise'>
            Aim
        </abilitysubtitle><div style='font-size:7px;'>
            <keywordTurquoise>Aim</keywordTurquoise> Points represent an archer's concentration and are directed at a single Target.
            <br><keywordTurquoise>Aim</keywordTurquoise> Points are lost any Round not doing the <keywordTurquoise>Aim</keywordTurquoise> Action.
        </div><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px; border-radius:4px; color:black; '><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Turquoise-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Turquoise-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Aim</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Turquoise-2)); border-color:var(--Turquoise-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Turquoise-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <f7>Can be done whenever an arrow is nocked or nocking.</f7>
                        <br><cs>1S:</cs> +1 <keywordTurquoise>Aim</keywordTurquoise> towards Target.
                        <br><b>Not Shooting This Round</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='font-size:10px; padding:2px 2px 1px 1px; display:flex; align-items:center; justify-content:flex-end; border-radius:2px; background:white; border:solid 1px var(--Turquoise-3); border-radius:4px;; display:grid; grid-template-columns:1fr; grid-gap:1px; font-size:10px;'>
                <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:3px; ' >/4&nbsp; <keywordTurquoise>Aim</keywordTurquoise></div>
            </div>
        </div><rulebox style='border-color:var(--Turquoise-3); background:var(--Turquoise-1);'>
            <div style='height:1px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Shoot. (May do twice.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <b>Friendly Fire</b> Check.(May do twice.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>Bypass</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bleeding.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +1R Hex. May do twice.
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Shot to the Leg cause <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Knockdown (Resist w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>).
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Shot to the Arm cause <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Disarm (Resist w/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>).
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>Arc Shot:</b> May Shoot over or around 1 Space barrier w/ 6 Only. (Friendly Fire still applies.)
            <div style='height:3px;'></div><div style='display:inline-block; 
        color:var(--Turquoise-4); background:var(--Turquoise-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Aim</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b>Bullseye:</b> If hitting Head with <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> over Hit Value: Do +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> Dmg and Blind 3 (Remove w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>).
        </rulebox></rulecard></div><div id='Barbarian' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Barbarian</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Red-4);'>
            <div>Barbarian (Class) <f8>Req: Any Athlete Level, Bloodpact of Tyrannus</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Red-3); background:var(--Red-1);'>
            <b>Barbarians</b> specialize in fearless melee combat and survival.
            They gain their power from Tyrannus, the God of blood and war.
            Most Barbarians are from harsh wilderness areas, and come from tribal communities.
            <br><b>Rage</b> is an ability Barbarians develop to have their passion for battle enhance their physical power.
            Rage is built through taking damage or even missing targets, and allows Barbarians to take more damage, move faster, and hit harder.
            Rage is granted through Tyrannus and in extreme circumstances may cause Barbarians to lose control, attacking whoever is closest to them, even their own allies.
        </rulebox><abilitysubtitle class='astRed'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astRed' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Barbarian 1
            </abilitysubtitle>
            <abilitysection class='asecRed' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astRed' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Barbarian 2
            </abilitysubtitle>
            <abilitysection class='asecRed' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Red-3);'>
                Can Shout to empower your allies, Powerful rage 10 effects, Cheaper Double Attack.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astRed' style='border-radius:4px 0px 0px 0px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Barbarian 3
            </abilitysubtitle>
            <abilitysection class='asecRed' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Red-3);'>
                Tyrannus Battle Recover, Blood Scream, Beefed up abilities.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astRed'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astRed'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Red-4);'>
            <div>Barbarian 1</div> 
        </rulecardtitle><rulebox style='border-color:var(--Red-3); background:var(--Red-1);'>
            <b>Can't use Combat Abilities in Medium or Heavy Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Resilient</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Rest.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Fatigue for Physcial Labor and Travel.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Toughness Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Tough</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    Gain up to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> DR this Round.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Untiring</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Ignore Weak and <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> until end of Combat.
                    <br> End of Combat gain <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Combat Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Wide Strike</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    If using a Large Weapon may attack two adjacent Targets in Range.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Double Attack</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Both weapons must be hafted weapons.
	                <br> May attack with two weapons this Round.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Rage
        </abilitysubtitle><div style='display: grid; grid-template-columns: 1fr 70px; grid-gap 1px;'>
            <div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Enrage</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <div style='height:2px;'></div> <f7><div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 1</div></f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <sc>1S:</sc> +1 <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:1px;'></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Berserk</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        When taking Damage gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter></div>
            <div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Red-3); color:black; font-weight:700; font-size:13px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/8 <keywordRed>Rage</keywordRed></div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 2 to 7</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> 1, +1 Pace, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 8</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, +1 Pace, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Red-4);'>
            <div>Barbarian 2</div> 
        </rulecardtitle><rulebox style='border-color:var(--Red-3); background:var(--Red-1);'>
            <b>Can't use Combat Abilities in Medium or Heavy Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Resilient</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Rest.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Recovery:Exposure.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Fatigue for Physcial Labor and Travel.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Toughness Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Tough</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    Gain up to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> DR this Round.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Untiring</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Ignore Weak and <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> until end of Combat.
                    <br> End of Combat gain <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Combat Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shout</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> You or Ally gain 1 Will.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Wide Strike</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    If using a Large Weapon may attack two adjacent Targets in Range.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Double Attack</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Both weapons must be hafted weapons.
	                <br> May attack with two weapons this Round.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Rage
        </abilitysubtitle><div style='display: grid; grid-template-columns: 1fr 70px; grid-gap: 1px;'>
            <div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Enrage</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='height:2px;'></div> <f7><div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 1</div></f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <sc>1S:</sc> +1 <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:1px;'></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Berserk</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        When taking Damage gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter></div>
            <div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Red-3); color:black; font-weight:700; font-size:13px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/10 <keywordRed>Rage</keywordRed></div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 2 to 5</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> 1, +1 Pace, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 6 to 9</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, +1 Pace, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 10</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, +1 Pace, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                    <br> At the start of Round, Roll a dice for each Character within 1 Hex of you, Attack the Character who got the highest number.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Red-4);'>
            <div>Barbarian 3</div> 
        </rulecardtitle><rulebox style='border-color:var(--Red-3); background:var(--Red-1);'>
            <b>Can't use Abilities in Medium or Heavy Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Resilient</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Rest.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Remove Exposure.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Hunger/Thirst/Sleep.
                    <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Fatigue for Physcial Labor and Travel.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Toughness Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Tough</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>                
                    Gain up to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> DR this Round.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Untiring</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Ignore Weak and <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div> until end of Combat.
                    <br> End of Combat gain <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 1</div> Battle Recover</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> Harm.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Combat Abilities
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Wide Strike</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    If using a Large Weapon may attack two adjacent Targets in Range.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Shout</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> You or Ally gain 1 Will.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Blood Scream</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Contest: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. <Sc>1S:</sc> Target gains 1 Dread.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Double Attack</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Both weapons must be hafted weapons.
	                <br> May attack with two weapons this Round.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><img 
        src='/Resources/Art/Images/Hand_L.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Hand_R.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Throw Halfted</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <span style='padding-left: 20px;'></span></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> <cb><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Throw Large Weapon</cb></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Red-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Dmg</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>Use Weapon's Damage</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astRed'>
            Rage
        </abilitysubtitle><div style='display: grid; grid-template-columns: 1fr 70px; grid-gap:1px;'>
            <div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Enrage</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='height:2px;'></div> <f7><div style='display:inline-block; 
        color:var(--Red-4); background:var(--Red-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Blood Pact 1</div></f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <sc>1S:</sc> +1 <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter><div style='height:1px;'></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Berserk</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        When taking Damage gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <keywordRed>Rage</keywordRed>.
                    </div></challengeText></challengeContainer></div></actionContainter></div>
            <div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Red-3); color:black; font-weight:700; font-size:13px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/10 <keywordRed>Rage</keywordRed></div>
            </div>
        </div>
        <actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 2 to 4</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> 1, +1 Pace, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 5 to 9</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, +1 Pace, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                    <br> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <sc>1S:</sc> Gain 1 Will.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);     ; background:white; border-style:solid; border-color:var(--Red-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Rage 10</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <div style='display:inline; font-weight:700;'>DR</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>, +1 Pace, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Melee Dmg.
                    <br> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <sc>1S:</sc> Gain 1 Will.
                    <br> At the start of Round, Roll a dice for each Character within 1 Hex of you, Attack the Character who got the highest number.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Bard' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Bard</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Pink-4);'>
            <div>Bard (Class)</div> 
            <div><f8>Req: Musician: Instrument 1 (Any), Revelation of Yavara</f8></div>
        </rulecardtitle><rulebox style='border-color:var(--Pink-3); background:var(--Pink-1);'>
            <b>Bards</b> specialize in using music to assist allies in combat.
            Bards gain their power from Yavera, the God of Art and mischeif.
            The power of a Bard's music can influence minds, invigorate allys, and confuse enemies.
            <br><b>Hearten</b> songs are those played to soothe the party on the road, and often involve creating songs and legends around the party itself.
            <br><b>Playing in Combat</b> is used to channel musical power, granted through Yavara, to enhance the Bard's allies or sow discord in their enemies.
            Songs are mainly played through an instrument, but can be enhanced by singing and dancing.
            The more <b>Harmony</b> a Bard is able to achieve, the stronger the effect.
            <br><b>Embelishments</b> are more advanced chords and notes a Bard may play to ehance their performance, but require greater concentration.
            <br><b>Perfect Harmony</b> is something all Bards strive to acheive, and allows them to channel the power of music to it's full effect.
        </rulebox><abilitysubtitle class='astPink'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astPink' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Bard 1 <f7></f7>
            </abilitysubtitle>
            <abilitysection class='asecPink' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astPink' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Bard 2
            </abilitysubtitle>
            <abilitysection class='asecPink' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Pink-3);'>
                Taunt (song to distract enemies), Embellish Reputation.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astPink' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Bard 3 <br><f7>Req: Musician 2</f7>
            </abilitysubtitle>
            <abilitysection class='asecPink' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Pink-3);'>
                Noise Blast (song to push away enemies), Travel Song (gain Morale during Travel), improved Hearten.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astPink'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astPink'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Pink-4);'>
            <div>Bard 1</div>
        </rulecardtitle><rulebox style='border-color:var(--Pink-3); background:var(--Pink-1);'>
            <b>Bard Abilities cannot be done in Heavy/Medium/Light Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Hearten</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Allies/Self Roll <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> and gain Morale.
                    <br><sc>1S:</sc> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> towards Allies' check.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPink'>
            Battle Songs
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Play</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Pink-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Use Instrument to Play <b>Techinque</b> Motif & <b>Style</b> Motif, or play a Motif with <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rally</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Ally gains <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will, <b>or</b> Ally Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> for a Check.
                    <br> <sc>3 Harmony:</sc> Spread <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will. (Can spend on self.)
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Battle<br> Hymn</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle 3</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit <b>or</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check.
                    <br> <sc>3 Harmony:</sc> +<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit and +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check. Added dice are <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div style='display: inline-block;background: var(--Green-3);color: white;font-weight: 700;font-size: 8px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding: 0px 2px 0px 2px;'> Success 4/5/6</div>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Waltz</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Self/Ally<br> <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Move You/Ally 1 Space. <f7>(You + Ally must agree on move.)</f7>
                    <cs>1 Harmony:</cs> You may Defend or <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Defend.
                    <br> <sc>3 Harmony:</sc> Two allies switch positions. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dodge.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Taunt</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div><b>Target:</b> <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Target Reduces Harmony w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                    <br><cs>1 Harmony:</cs> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><sc>3 Harmony:</sc> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and Hit is <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Pink-4);'>
            <div>Bard 2</div>
        </rulecardtitle><rulebox style='border-color:var(--Pink-3); background:var(--Pink-1);'>
            <b>Bard Abilities cannot be done in Heavy/Medium/Light Armor. </b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Hearten</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Allies/Self Roll <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> and gain Morale.
                    <br><sc>1S:</sc> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> towards Allies' check.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Embellish <br> Reputation</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Convince locals to treat you better, give you free food/drink/lodging.
	                <br> Less successes required if actually completing renowned deeds, more required if you’ve done nothing.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPink'>
            Battle Songs
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Play</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Pink-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Use Instrument to Play <b>Techinque</b> Motif & <b>Style</b> Motif, or play a Motif with <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br> <b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/HexagonW_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> to Range:</b> Take <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Arm Dmg.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rally</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Ally gains <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will, <b>or</b> Ally Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> for a Check.
                    <br> <sc>3 Harmony:</sc> Spread <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will. (Can spend on self.)
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Battle<br> Hymn</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle 3</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit <b>or</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check 
                    <br> <sc>3 Harmony:</sc> +<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit and +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check w/ <div style='display: inline-block;background: var(--Green-3);color: white;font-weight: 700;font-size: 8px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding: 0px 2px 0px 2px;'> Success 4/5/6</div>. 
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Waltz</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Self/Ally<br> <img 
        src='/Resources/Art/Images/Hexagon_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Move You/Ally 1 Space. <f7>(You + Ally must agree on move.)</f7>
                    <cs>1 Harmony:</cs> You may Defend or <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Defend.
                    <br> <sc>3 Harmony:</sc> Two allies switch positions. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dodge.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Taunt</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div><b>Target:</b> <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Target Reduces Harmony w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                    <br><cs>1 Harmony:</cs> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><sc>2 Harmony:</sc> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> to Hit anyone but you. 
                    <br><sc>3 Harmony:</sc> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and Hit is <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Duet of<br> Agony</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Self/Ally<br> Circle 3</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> 1 Dmg is applied to Random Ally (including you) in Range instead. <f7>Body Area is the same.</f7>
                    <br> <sc>3 Harmony:</sc> Up to 3 Dmg is applied to random Ally (including you) instead and also applied to a Random Enemy in Range.<f7>Body Area is the same.</f7>
                    <br> <f7>Any additional Dmg Effects (ex: poison, bleeding, etc.) are moved to the new Target as well.</f7> 
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Pink-4);'>
            <div>Bard 3</div>
        </rulecardtitle><rulebox style='border-color:var(--Pink-3); background:var(--Pink-1);'>
            <b>Bard Abilities cannot be done in Heavy/Medium/Light Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Hearten</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Allies/Self Roll <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> and gain Morale.
                    <br><sc>1S:</sc> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> towards Allies' check.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f8>-1 <div style='display:inline-block; 
        color:var(--Gray-4); background:var(--Gray-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Morale</div></f8><br> Travel Song</div></div> <actionSubtitle style='margin-left:3px;'>Travel Add On</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> All Allies Resist Fatigue with <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> while Traveling.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Embellish <br> Reputation</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Convince locals to treat you better, give you free food/drink/lodging.
	                <br> Less successes required if actually completing renowned deeds, more required if you’ve done nothing.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPink'>
            Battle Songs
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Play</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Pink-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                    Use Instrument to Play <b>Techinque</b> Motif & <b>Style</b> Motif, or play a Motif with <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br> <b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><img 
        src='/Resources/Art/Images/HexagonW_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> to Range:</b> Take <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Arm Dmg.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Rally</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Ally gains <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will, <b>or</b> Ally Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> for a Check.
                    <br> <sc>3 Harmony:</sc> Spread <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will. (Can spend on self.)
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Battle<br> Hymn</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Ally<br> Circle 3</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit <b>or</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check 
                    <br> <sc>3 Harmony:</sc> +<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Hit and +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg Check w/ <div style='display: inline-block;background: var(--Green-3);color: white;font-weight: 700;font-size: 8px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding: 0px 2px 0px 2px;'> Success 4/5/6</div>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Waltz</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Self/Ally<br> <img 
        src='/Resources/Art/Images/Hexagon_2R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> Move You/Ally 1 Space. <f7>(You + Ally must agree on move.)</f7>
                    <cs>1 Harmony:</cs> You may Defend or <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Defend.
                    <br> <sc>3 Harmony:</sc> Two allies switch positions. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dodge.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Taunt</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div><b>Target:</b> <img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Target Reduces Harmony w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
                    <br><cs>1 Harmony:</cs> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><sc>2 Harmony:</sc> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> to Hit anyone but you. 
                    <br><sc>3 Harmony:</sc> Reduce Target’s Hit by <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> and Hit is <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Duet of<br> Agony</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Self/Ally<br> Circle 3</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1 Harmony:</cs> 1 Dmg is applied to Random Ally (including you) in Range instead. <f7>Body Area is the same.</f7>
                    <br> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May reroll which random ally takes the Dmg.
                    <br> <sc>3 Harmony:</sc> Up to 3 Dmg is applied to Choosen Ally instead and also applied to a Random Enemy in Range.<f7>Body Area is the same.</f7>
                    <br> <f7>Any additional Dmg Effects (ex: poison, bleeding, etc.) are moved to the new Target as well.</f7> 
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Noise<br> Blast</div></div> <actionSubtitle style='margin-left:3px;'>Motif</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Pink-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Enemies<br> Cone</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b><img 
        src='/Resources/Art/Images/HexagonW_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><img 
        src='/Resources/Art/Images/HexagonW_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Push <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. Collision <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><b><img 
        src='/Resources/Art/Images/HexagonW_2.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>-</div><img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Push <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. Collision <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br><cs>1 Harmony:</cs> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Push, <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Collision Dmg.
                    <br> <sc>3 Harmony:</sc> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Push, , <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Collision Dmg, <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Blast Dmg 
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Cleric' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Cleric</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Yellow-4);'>
            <div>Cleric (Class) <f8>Req: Healer 1:Nurse, Follower of Azeal</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Clerics</b> specialize in using healing and holy magic.
            Clerics gain their power from Azeal, the God of light and order.
            Most are trained in churches and often directly in the care of the church.
            Often they continue to have fealty to the church organization as they continue their adventures.
            <br><b>Praying</b> allows a Cleric to channel the power of Azeal into them.
            While this can be done while fighting, full concentration allows a Cleric to more easily get in contact with the power of Azeal.
            <b>Prayer</b> gained this way can me used to heal allies, smite foes, and many other effects.
            <br><b>Turning</b> is a power a Cleric can preform through holy implements, and can be used to drain away the life and spirit from an enemy, particularly Vile enemies.
        </rulebox><abilitysubtitle class='astYellow'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astYellow' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Cleric 1 
            </abilitysubtitle>
            <abilitysection class='asecYellow' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        <rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            If taken in Character Creation, may exchange Clothes for Cleric Robes. 
        </rulebox>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astYellow' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Cleric 2 
            </abilitysubtitle>
            <abilitysection class='asecYellow' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Yellow-3);'>
                Turn: Light Beam, Create light from Implement.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astYellow' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Cleric 3 
            </abilitysubtitle>
            <abilitysection class='asecYellow' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Yellow-3);'>
                Blinding Light, improved Healing Light, Save life, and Bless allies.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astYellow'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astYellow'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Yellow-4);'>
            <div>Cleric 1 <small>- Initiate</small></div>
        </rulecardtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Pray and Care:</b> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Give Treatment.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f8>-1 Morale</f8><br> Street Preach</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Can only be done in Cities and Towns.
                    <br><cs>1S:</cs> 1 Gold and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordYellow>Favor</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Divine</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>Attempt to sense Divine Power nearby.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Blessings
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Bless Allies</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Use 1 Holy Water.
                    <br> All Allies have +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Vile creatures) to Resist Non-Physcial Damage effect for 12 hours.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Save Life</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>After Combat</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally Resist Death.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Prayers
        </abilitysubtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Mend:</b> Prevent Dmg <b>OR</b> Remove Harm. Prevented Dmg can still apply Bleeding.
        </rulebox><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Pray</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                    <div style='display:flex; justify-content:flex-start;'>
                        <div style='text-align:left;'>
                            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b><i>Free:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                            <div style='height:1px;'></div><b><i>Active:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><b><i>Full:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Valor</div></f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
                        </div>
                    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7></f7>Requires use of Voice.</b>
                        <br> <cs>1S:</cs> +1 <keywordYellow>Prayer</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Yellow-3); color:black; font-weight:700; font-size:12px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/4 <keywordYellow>Prayer</keywordYellow></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Prayer</div></f7> Bless</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'><img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Ally Mend <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> OR +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Check.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Prayer</div></f7> Healing Light</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Circle 2</b> Ally's Mend <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. You Mend <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>,
                    <br> May continue to keep active +1 Round for 1 <keywordYellow>Prayer</keywordYellow>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Prayer</div></f7> Smite</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg. (+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Target is Vile.)</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Yellow-4);'>
            <div>Cleric 2</div>
        </rulecardtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Pray and Care:</b> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> to Give Treatment.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f8>-1 Morale</f8><br> Street Preach</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Can only be done in Cities and Towns.
                    <br><cs>1S:</cs> 1 Gold and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordYellow>Favor</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Divine</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>Attempt to sense Divine Power nearby.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Blessings
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Lighted <br> Implement</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>Use 1 Holy Water.
                <br> Implement has Light 2 for a 6 Hours. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Turn Checks w/ Implement.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Bless Allies</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Use 1 Holy Water.
                    <br> All Allies have +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Vile creatures) to Resist Non-Physcial Damage effect for 12 hours.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Save Life</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>After Combat</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally Resist Death.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Prayers
        </abilitysubtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Mend:</b> Prevent Dmg <b>OR</b> Remove Harm. Prevented Dmg can still apply Bleeding.
        </rulebox><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Pray</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                    <div style='display:flex; justify-content:flex-start;'>
                        <div style='text-align:left;'>
                            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b><i>Free:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                            <div style='height:1px;'></div><b><i>Active:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><b><i>Full:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Valor</div>/1 Fatigue</f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
                        </div>
                    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7></f7>Requires use of Voice.</b>
                        <br> <cs>1S:</cs> +1 <keywordYellow>Prayer</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Yellow-3); color:black; font-weight:700; font-size:12px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/4 <keywordYellow>Prayer</keywordYellow></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Prayer</div></f7> Bless</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'><img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Ally Mend <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> OR +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Check.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Prayer</div></f7> Turn: Light Beam</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Turn: Add On</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>When Doing Turn: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Target is Slow 1 this Round.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Prayer</div></f7> Smite</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg. (+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Target is Vile.)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Prayer</div></f7> Healing Light</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Circle 2</b> Ally's Mend <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. You Mend <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>,
                    <br> May continue to keep active +1 Round for 1 <keywordYellow>Prayer</keywordYellow>.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Yellow-4);'>
            <div>Cleric 3</div>
        </rulecardtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Pray and Care:</b> Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fatigue. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> to Give Treatment.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f8>-1 Morale</f8><br> Street Preach</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Can only be done in Cities and Towns.
                    <br><cs>1S:</cs> 1 Gold and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordYellow>Favor</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Divine</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>Attempt to sense Divine Power nearby.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Blessings
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Lighted <br> Implement</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>Use 1 Holy Water.
                <br> Implement has Light 2 for a 6 Hours. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Turn Checks w/ Implement.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Bless Allies</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Interim</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    Use 1 Holy Water.
                    <br> All Allies have +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Vile creatures) to Resist Non-Physcial Damage effect for 12 Hours.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Save Life</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>After Combat</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally Resist Death.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astYellow'>
            Prayers
        </abilitysubtitle><rulebox style='border-color:var(--Yellow-3); background:var(--Yellow-1);'>
            <b>Mend:</b> Prevent Dmg <b>OR</b> Remove Harm. Prevented Dmg can still apply Bleeding.
        </rulebox><div style='display:grid; grid-template-columns:1fr 70px; grid-gap:1px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Pray</div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                    <div style='display:flex; justify-content:flex-start;'>
                        <div style='text-align:left;'>
                            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b><i>Free:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                            <div style='height:1px;'></div><b><i>Active:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><b><i>Full:</b></i> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                            <div style='height:1px;'></div><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Valor</div>/1 Fatigue</f7><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>
                        </div>
                    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7></f7>Requires use of Voice.</b>
                        <br> <cs>1S:</cs> +1 <keywordYellow>Prayer</keywordYellow>.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Yellow-3); color:black; font-weight:700; font-size:12px; align-items: end;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/4 <keywordYellow>Prayer</keywordYellow></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Prayer</div></f7> Bless</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'><img 
        src='/Resources/Art/Images/HexagonW_3.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Ally Mend <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> OR +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ally's Check.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Prayer</div></f7> Turn: Light Beam</div></div> <actionSubtitle style='margin-left:3px;'>Turn: Add On</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>When Doing Turn: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Target is Slow 1 this Round.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);     ; background:white; border-style:solid; border-color:var(--Yellow-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Prayer</div></f7> Smite</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg (+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> if Target is Vile.) and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Burning.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Prayer</div></f7> Healing Light</div></div> <actionSubtitle style='margin-left:3px;'>Active</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Yellow-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Circle 2</b> Ally's Mend <b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. You Mend <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    <br> May continue to keep active +1 Round for 1 <keywordYellow>Prayer</keywordYellow>.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Yellow-3);    ;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Yellow-4); background:var(--Yellow-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Prayer</div></f7><br> Blinding <br> Light</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Yellow-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Proj&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. (Misses if doesn’t hit head w/ eyes.)</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Yellow-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Holy</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Yellow-2)); border-color:var(--Yellow-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='text-align: left;'> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> (+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Vile Creatures).
                        <br> <b>Blind</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Remove (Free) w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. </div></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></rulecard></div><div id='Druid' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Druid</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Green-4);'>
            <div>Druid (Class) <f8>Req: Survivalist, Witness of Ernok</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <b>Druid</b> are people who have an intense connection to the natural world. They almost always feel more comfortable out in nature then in cities or other crowded places.
            Druids almost always worship Ernok, the God of Nature, and are devoted to protecting the harmony of nature.
            Druids can come from all walks of life, but all find themselves plled ot wild, untamed lands where nature's power and beauty is at it's strongest.
            <br> <b>Companions</b> are much like a pet, but with a more powerful and personal connection. Gain a Druid Companion Card.
            <br> <b>Communions</b> involve channeling the power of nature through the Druid's body.
            This can alter the area arond the Druid, but does take a tole on his Body. <b>Wither</b> is the drain this takes on the Druid's life energies.
            <br> <b>Brewing</b> allows the Druid to use his knowledge of the natural world to make powerful concotions.
            These <b>Liquors</b> and <b>Draughts</b> can have effects ranging from healing, to temporarily transforming the body of the drinker.
            <br> <b>Guardians</b> are the creatures of the wilderness that can be summoned to do fight alongside the Druid.
            A Druid must first <b>Summon</b> the creature, and then attempt to <b>Command</b> it, lest it run away.
            A Guardians Summon Cost and Command Points are listed alongside it.
        </rulebox><abilitysubtitle class='astGreen'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGreen' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Druid 1  
            </abilitysubtitle>
            <abilitysection class='asecGreen' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGreen' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Druid 2 
            </abilitysubtitle>
            <abilitysection class='asecGreen' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Green-3);'>
                Companion Scout, Mist Cloud Communion, Brew Aspect of the Wolf, Summon more powerful Guardians.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:100px 1fr auto;'>
            <abilitysubtitle class='astGreen' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Druid 3
            </abilitysubtitle>
            <abilitysection class='asecGreen' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Green-3);'>
                Create Druid Staff, Poison Spore Communion, Brew Aspect of the Oak, Red Liqour, Gain Greater Control over your Guardians.
                <div><div style='display:inline-block; 
        color:var(--Green-4); background:var(--Green-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>Essence 5</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Gain a Druid Staff of Choice. (Max: 1)</div>
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astGreen'> 
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astGreen'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Green-4);'>
            <div>Druid 1</div> 
        </rulecardtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <b>Druid Abilities cannot be done in Heavy/Medium/Light Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);     ; background:white; border-style:solid; border-color:var(--Green-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Speak to Nature</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain info from nature/animals.</div></challengeText></challengeContainer></div></actionContainter><abilitysubtitle class='astGreen'>
            Companion
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Bond’s Animal Play.
            <br> Able to understand Bonded Animals speech in a manner.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Communions
        </abilitysubtitle><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Remove Wither</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> -1 Wither.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/1 <small>Wither</small></div>
                <div style='text-align:right; padding:0px 1px 0px 1px; margin-top:-5px; font-weight:500;'><f7>Over becomes Fatigue/Wound</f7></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Undergrowth</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 3 Wither w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. <f7>4 if no plants near the Target Area.</f7>
            		<br> Create Circle 1 within 1R for 3 Rounds. All enemies inside are Slow 2.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Brewing
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Brew</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		<f7>Requires Brewing Kit.</f7>
            		<br> <b>Water + Herb</b> <cs>1S:</cs> Make Brown (Max: 2 Doses).
            		<br> <b>Water + Herb</b> <cs>1S:</cs> Make Yellow Liquor (Max: 1 Dose)
                </div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	May Drink a Dose as Full Action. Gain an <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> to acquire a Brewing Kit.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Guardians
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	<b>Guardians</b> appear 1R away when Summoned (GM discretion) with 3 Command. 
        	<br><f7><b>Forest:</b> Boar (3) <b>Jungle:</b>  Snake (3) <b>Desert:</b>  Snake (3) <b>Grasslands:</b>  Boar (3) <b>Wetland:</b>  Snake (3)</f7>
        </rulebox><div style='display: grid; grid-template-columns: 1fr 90px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Summon</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                        <div style='height:1px;'></div> Use Raw Meat:+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> </div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <sc>1S:</sc> +1 Summon Point.
                        <br> May Spend Summon to call Guardian.
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='display:grid; grid-template-columns:1fr; align-items: end; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>  <small>Summon</small></div>
            </div>
        </div><div style='display: grid; grid-template-columns: 1fr 70px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Command</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='text-align: left;'>
                            <b>Full:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>
                            <div style='height:1px;'></div> <b>Active:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                            <div style='height:1px;'></div> <b>Free:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>
                        </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7>Must attempt every Round.</f7></b>
                        <br><sc>1S:</sc><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Guardian’s Check.
                        <br> <fc>0S:</fc> -1 Command. 
                        <br><b>0 Command:</b> Guardian leaves.                    
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr;  align-items: end;border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
                <div style='text-align:center; padding:4px 2px 4px 2px;'><small>Command</small></div>
            </div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Green-4);'>
            <div>Druid 2</div> 
        </rulecardtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <b>Druid Abilities cannot be done in Heavy/Medium/Light Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);     ; background:white; border-style:solid; border-color:var(--Green-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Speak to Nature</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain info from nature/animals.</div></challengeText></challengeContainer></div></actionContainter><abilitysubtitle class='astGreen'>
            Companion
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Bond’s Animal Play.
            <br> Able to understand Bonded Animals speech in a manner.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Communions
        </abilitysubtitle><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Remove Wither</div></div> <actionSubtitle style='margin-left:3px;'>Active / Full: +1S</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> -1 Wither.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/2 <small>Wither</small></div>
                <div style='text-align:right; padding:0px 1px 0px 1px; margin-top:-5px; font-weight:500;'><f7>Over becomes Fatigue/Wound</f7></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Undergrowth</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 3 Wither w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. <f7>4 if no plants near the Target Area.</f7>
            		<br> Create Circle 1 within 1R for 3 Rounds. All enemies inside are Slow 2.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Mist Cloud</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 3 Wither w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. Resist 4 if in a dry area.
		            <br> Create 1R Circle of Mist around you for 4 Rounds. 
		            <br> Visibility 1 in Mist. Hits in Mist are <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Brewing
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Brew</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		<f7>Requires Brewing Kit.</f7>
            		<br> <b>Water + Herb</b> <cs>1S:</cs> Make Brown (Max: 3 Doses).
            		<br> <b>Water + Herb</b> <cs>1S:</cs> Make Yellow Liquor (Max: 2 Dose)
            		<br> <b>Water+Herb+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound</b> <cs>1S:</cs> Make Red Liquor (Max: 1 Dose) OR Black Liquor (Max: 1 Dose).
            		<br> <b>Any Liquor + 1 Wound</b> <cs>1S:</cs> Make Aspect of the Wolf (Max: 1 Dose)
                </div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	May Drink a Draught as Full Action. Gain an <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> to acquire a Brewing Kit.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Guardians
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	<b>Guardians</b> appear 1R away when Summoned (GM discretion) with 3 Command. 
        	<br><f7><b>Alpine:</b> Wolf (5) <b>Forest:</b> Boar (3), Wolf (5) <b>Jungle:</b>  Snake (3) <b>Desert:</b>  Snake (3), Hyena (5) 
        	<br><b>Grasslands:</b>  Boar (3), Wolf (5) <b>Wetland:</b>  Snake (3), Dire Toad (5)</f7>
        </rulebox><div style='display: grid; grid-template-columns: 1fr 60px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Summon</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                        <div style='height:1px;'></div> <b>Active:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>
                        </div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        Use Raw Meat:+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                        <br> <sc>1S:</sc> +1 Summon Point.
                        <br> May Spend Summon to call Guardian.
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='display:grid; grid-template-columns:1fr; align-items: end; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:11px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>  <small>Summon</small></div>
            </div>
        </div><div style='display: grid; grid-template-columns: 1fr 60px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Command</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='text-align: left;'>
                            <b>Full:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>
                            <div style='height:1px;'></div> <b>Active:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                            <div style='height:1px;'></div> <b>Free:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>
                        </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7>Must attempt every Round.</f7></b>
                        <br><sc>2S:</sc> +1 Command. 
                        <br><sc>1S/<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</sc><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Guardian’s Check.
                        <br> <fc>0S:</fc> -1 Command. 
                        <br><b>0 Command:</b> Guardian leaves.                    
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr;  align-items: end;border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:11px;'>
                <div style='text-align:center; padding:4px 2px 4px 2px;'><small>Command</small></div>
            </div>
        </div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Green-4);'>
            <div>Druid 3</div> 
        </rulecardtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <b>Druid Abilities cannot be done in Heavy/Medium/Light Armor.</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);     ; background:white; border-style:solid; border-color:var(--Green-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f9>Speak to Nature</f9></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain info from nature/animals.</div></challengeText></challengeContainer></div></actionContainter><abilitysubtitle class='astGreen'>
            Companion
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
            <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Bond’s Animal Play. 
            <br> Able to understand Bonded Animals speech in a manner.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Communions
        </abilitysubtitle><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Remove Wither</div></div> <actionSubtitle style='margin-left:3px;'>Active / Full: +1S</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> -1 Wither.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:13px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>/3 <small>Wither</small></div>
                <div style='text-align:right; padding:0px 1px 0px 1px; margin-top:-5px; font-weight:500;'><f7>Over becomes Fatigue/Wound</f7></div>
            </div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Undergrowth</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 3 Wither w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. <f7>4 if no plants near the Target Area.</f7>
            		<br> Create Circle 1 within 1R for 3 Rounds. All enemies inside are Slow 2.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Mist Cloud</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		Resist 3 Wither w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>. Resist 4 if in a dry area.
		            <br> Create 1R Circle of Mist around you for 4 Rounds. 
		            <br> Visibility 1 in Mist. Hits in Mist are <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Poison Spore</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                		Resist 2 Wither<br> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Green-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>
                		Cone 2
                    </div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                		<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Green-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>
                		 Target Resist 3 Poison w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                    </div></challengeText></challengeContainer></div></actionContainter></div><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Brewing
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Brew</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><f7>Requires<br> Brewing<br> Kit</f7><br><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
            		<f7>
            		<b>Water+Herb</b> <cs>1S:</cs> Make Brown (Max:3 Doses) OR Yellow Liquor (Max:3 Dose)
            		<br> <b>Water+Herb+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound</b> <cs>1S:</cs> Make Red Liquor (Max: 2 Dose) OR Black Liquor (Max: 1 Dose).
            		<br> <b>Any Liquor+1 Wound</b> <cs>1S:</cs> Make Aspect of the Wolf (Max: 2 Dose)
            		<br> <b>Any Liquor+1 Herb</b> <cs>1S:</cs> Make Aspect of the Oak (Max: 1 Dose)
            		</f7>
                </div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	May Drink a Draught as Full Action. Gain an <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> to acquire a Brewing Kit.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astGreen'>
            Guardians
        </abilitysubtitle><rulebox style='border-color:var(--Green-3); background:var(--Green-1);'>
        	<b>Guardians</b> appear 1R away when Summoned (GM discretion) with 3 Command. 
        	<br><f7><b>Alpine:</b> Wolf (5) <b>Forest:</b> Boar (3), Wolf (5) <b>Jungle:</b>  Snake (3) <b>Desert:</b>  Snake (3), Hyena (5) 
        	<br><b>Grasslands:</b> Boar (3), Wolf (5) <b>Wetland:</b>  Snake (3), Dire Toad (5)</f7>
        </rulebox><div style='display: grid; grid-template-columns: 1fr 60px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Summon</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                        <div style='height:1px;'></div> <b>Active:</b><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>
                        </div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        Use Raw Meat:+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> 
                        <br> <sc>1S:</sc> +1 Summon Point.
                        <br> May Spend Summon to call Guardian.
                    </div></challengeText></challengeContainer></div></actionContainter>
            <div style='display:grid; grid-template-columns:1fr; align-items: end; border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:11px;'>
                <div style='text-align:right; padding:4px 2px 4px 2px;'>  <small>Summon</small></div>
            </div>
        </div><div style='display: grid; grid-template-columns: 1fr 60px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Green-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Command</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Green-2)); border-color:var(--Green-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='text-align: left;'>
                            <b>Full:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div>
                            <div style='height:1px;'></div> <b>Active:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                            <div style='height:1px;'></div> <b>Free:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>
                        </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Green-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        <b><f7>Must attempt every Round.</f7></b>
                        <br><sc>2S/1 Fatigue:</sc> +1 Command. 
                        <br><sc>1S/<img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>:</sc><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Guardian’s Check.
                        <br> <fc>0S:</fc> -1 Command. 
                        <br><b>0 Command:</b> Guardian leaves.                    
                    </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr;  align-items: end;border-style:solid; border-width:1px; border-color:var(--Green-3); color:black; font-weight:700; font-size:11px;'>
                <div style='text-align:center; padding:4px 2px 4px 2px;'><small>Command</small></div>
            </div>
        </div></rulecard></div><div id='Fighter' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Fighter</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Fighter (Class) <f8>Req: Any Athlete Level</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Fighters</b> specialize in fighting with melee weapons.
            Fighters come in all types from lawless brigands, to professional soldiers, to valiant knights.
            Most fighters highly prize the mastery and care of their weapons.
            <br><b>Edge</b> is gained through reading the fight, where Fighters try to gain any advantage they can on their enemies in the course of a battle.
            <br><b>Showdowns</b> are when a Fighter takes a calculated risk against a Target, which may give the Target an opening, but more likely allow the Fighter a decisive blow.
        </rulebox><abilitysubtitle class='astOrange'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Fighter 1
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Fighter 2 
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Orange-3);'>
                Weapon Techniques, weapon repair/sharpness, Shield Attack, improved Read Fight, Showdown Despertaion bonus. 
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Fighter 3 
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Orange-3);'>
                Improved Weapon Techniques, Parry (counter defend), improved Read Fight, Maintain Armor.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astOrange'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astOrange'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Fighter 1</div> 
        </rulecardtitle><abilitysubtitle class='astOrange'>
            Techniques
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);     ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Read Fight</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Choose 2:</b><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Must be Attacking / Grappling / Being Attacked.</b></f7>
                <br><cs>1S:</cs> +1 <keywordOrange>Edge</keywordOrange> until end of Round.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Combat Skill</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit/Dmg/Defend Check. (Max 2 per Check.)  Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
            <div style='height:2px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Reposte</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May <keyword>Block</keyword> and Hit with same Weapon this Round. (Not Large Weapons.)
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Showdown</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Can use only if you + Target are Melee Attacking each other.</b></f7>
                <br>Choose <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge Vs. Target.
                <div style='height:1px;'></div><b>Lose:</b> Target has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    <b>Win:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                    <div style='height:1px;'></div><b>Lose:</b> Target has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                    <div style='height:1px;'></div> <b>Tie:</b> You and Target get +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                </f7></div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Fighter 2</div> 
        </rulecardtitle><abilitysubtitle class='astOrange'>
            Weapon/Armor Care
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Maintenance</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Sharpen Weapon</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Requires Weapon Repair Kit.</b><br> <cs>1S:</cs> +1 Sharpness.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='border-style:none none none none; border-radius:0px; border-width:1px; text-align:right; padding:4px 2px 2px 2px; font-size:13px; display:flex; align-items:center; justify-content:flex-end;'>
                <div style='display:grid; grid-template-columns:1fr; grid-gap:1px;'>
                    <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:2px;'>/3&nbsp; <keywordOrange>Sharpness</keywordOrange></div>
                    <div style='font-size:8px;'><keywordOrange>1 Sharpness:</keywordOrange> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Melee Dmg.</div>
                </div>
            </div>
        </div><rulebox style='border-color:var(--Orange-3);background:var(--Orange-1);'>
            <b>Weapon Knowledge:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Repair Weapon.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Techniques
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);     ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Read Fight</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Choose 3:</b><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Must be Attacking / Grappling / Being Attacked.</b></f7>
                <br><cs>1S:</cs> +1 <keywordOrange>Edge</keywordOrange> until end of Round..</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Combat Skill</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit/Dmg/Defend Check. (Max 3 per Check.) Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
            <div style='height:2px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Reposte</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May <keyword>Block</keyword> and Hit with same Weapon this Round. (Not Large Weapons.)
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Edge</div> <b>Shield Attack</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May Attack with Shield as Add-On.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Showdown</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Can use only if you + Target are Melee Attacking each other.</b></f7>
                <br>Choose <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge Vs. Target.
                <br> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Showdown Check. (Max 3 per Check.)
                <br><f7> <b>Desperation</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <f7>(Requires 3 or more Head/Torso Wound) <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></f7>
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    <b>Win:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg. All Allies gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Will.
                    <div style='height:1px;'></div><b>Lose:</b> Target has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                    <div style='height:1px;'></div> <b>Tie:</b> You and Target get +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                </f7></div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Weapon Techniques
        </abilitysubtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Sword) Deep Cut</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Bleeding.
            <div style='height:2px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Hafted) Power Hit</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg. +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Weapon.
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Pole-Arm) Defensive Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Space.
        </rulebox></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Fighter 3</div> 
        </rulecardtitle><abilitysubtitle class='astOrange'>
            Weapon/Armor Care
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Maintenance</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Sharpen Weapon</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Requires Weapon Repair Kit.</b><br> <cs>1S:</cs> +1 Sharpness.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Maintain Armor/Shield</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Requires Armor Repair Kit.</b><br> <cs>1S:</cs> +1 Durability.</div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:4fr 5fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='border-style:none none none none; border-radius:0px; border-width:1px; text-align:right; padding:4px 2px 4px 2px; font-size:13px; display:flex; align-items:center; justify-content:flex-end;'>
                <div style='display:grid; grid-template-columns:1fr; grid-gap:1px; font-size:10px;'>
                    <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:2px;'>/3&nbsp; <keywordOrange>Sharpness</keywordOrange></div>
                    <div style='font-size:8px;'><keywordOrange>1 Sharpness:</keywordOrange> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Melee Dmg.</div>
                </div>
            </div>
            <div style='border-style:none none none solid; border-radius:0px; border-width:1px; text-align:right; padding:4px 2px 4px 2px; font-size:13px; display:flex; align-items:center; justify-content:flex-end;'>
                <div style='display:grid; grid-template-columns:1fr; grid-gap:1px; font-size:10px;'>
                    <div style='display:flex; justify-content:flex-end; font-weight:700; padding-top:2px;'>/3&nbsp; <keywordOrange>Durability</keywordOrange></div>
                    <div style='font-size:8px;'><keywordOrange>1 Durability:</keywordOrange> Armor/Shield absorbs +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg.</div>
                </div>
            </div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Repair Knowledge:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Repair Weapon.
            <br> <b>Armor Knowledge:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Repair Armor/Shield.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Techniques
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);     ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Read Fight</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='height:1px;'></div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Must be Attacking / Grappling / Being Attacked.</b></f7>
                <br><cs>1S:</cs> +1 <keywordOrange>Edge</keywordOrange>.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Combat Skill</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit/Dmg/Defend Check. (Max 3 per Check.) Ignores <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div>.
            <div style='height:2px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>Reposte</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May <keyword>Block</keyword> and Hit with same Weapon this Round. (Not Large Weapons.)
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Edge</div> <b>Shield Attack</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> May Attack with Shield as Add-On.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Showdown</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7><b>Can use only if you + Target are Melee Attacking each other.</b></f7>
                <br>Choose <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> Challenge Vs. Target.
                <br> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Showdown Check. (Max 3 per Check.)
                <br><f7> <b>Desperation</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <f7>(Requires 3 or more Head/Torso Wound) <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></f7>
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><f7>
                    <b>Win:</b> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg. All Allies gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> Will.
                    <div style='height:1px;'></div><b>Lose:</b> Target has +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                    <div style='height:1px;'></div> <b>Tie:</b> You and Target get +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                </f7></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Parry</div></div> <actionSubtitle style='margin-left:3px;'>Active/Defend</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>On Full Block may Attack with +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Hit and Dmg.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Weapon Techniques
        </abilitysubtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Sword) Deep Cut</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Bleeding.
            <div style='height:2px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Hafted) Power Hit</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg. +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Weapon.
            <div style='height:1px;'></div> <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Edge</div> <b>(Pole-Arm) Defensive Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Space and may add all Space Succeses to Hit.
        </rulebox></rulecard></div><div id='Mage' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Mage</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Purple-4);'>
            <div>Mage (Class) <f8>Req: Scholar</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b>Mages</b> specialize in using arcane magic.
            Most are trained by the Acedemy, but others are trained by personal tutors.
            Mages tend to be highly involved with the search for knowledge. 
            Magic involves uses mental concentration and arcane formulae to bend the form of either.
            Magic is very difficult and dangerous and is skill few can master.
            <f7>
            <br><b>Preparing Spells</b> is required before casting them. 
            This process uses materialized formula, usually in the form of a scroll or other components. Some spells being more difficult than others. 
            <br><b>Incanting Spells</b> is the final step before casting.
            While incanting a Mage concentrates on calculating the final formulas for casting. This requires the use the voice and hands for chanelling the forms of the spell.
            This builds <b>Arcanum</b>, a type of charged either, that will be used to cast the spell.
            Arcanum has an either type (Ex: Red, Blue, Shadow, etc.) and can be seen gathering around the mage while Incanting.
            <br><b>Casting Spells</b> is the final step and uses the accumulated Arcanum to inact the effects of the spell.
            <br><b>Overcharge</b> is the act of increasing the power of a spell, often at the cost of requiring additional Arcanum or Backlash.  
            <br><b>Backlash</b> are dangerous and uncontrolled conseqences of a spell. When casting, a mage will try to reduce the backlash as much as possible.
            <br><b>Spell Materials</b> some items such as Orichalcum and Magical Remenants (tokens from creatures with magical energy) can aid in preparing and incanting spells. 
            <br><b>Untrained:</b> Schools of magic that the caster has not yet completed training in. 
            </f7>
        </rulebox><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b>Ether Types / Arcane Schools</b>  
            <div style='display:grid; grid-template-columns:1fr 1fr;'>
                <div>
                    <b>Chromatic Magic</b> is the standard type of magic. Each has a school in the Citadel.
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Red </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            Manipulation of fire and light and other combustible energies.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Blue </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            Manipulation of water, ice, and storms.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Green </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                             The art of mental awareness, including scrying and mide control.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Yellow </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                             The creation of illusions and other manipulation of the senses.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Purple </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                              Manipulation of gravity and the earth. Some arts can alter time itself.
                        </div>
                    </div>
                </div>
                <div style='padding-left: 2px;'>
                    <b>Dark Magic</b> is forbidden by the Citadel and assocaited with the power of Morgeth.
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Plague </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            Manipulation of vermin, poison, acid, and other kinds of decay.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Shadow </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            Manipulation of the darkness. Related to nightmares and dark illusions.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Death </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            The creation of undead creatures and the manipulation of dead flesh.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Soul </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            Power to control and consme soul ether.
                        </div>
                    </div>
                    <div style='display:grid; grid-template-columns:auto 1fr;'>
                        <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                            <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <f8> Void </f8>
                        </abilitysubtitle>
                        <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 4px 0px;'>
                            <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/5<div style='display:inline; color:black; font-weight:800;'>AP</div><f8> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div>
                        </abilitysection>
                        <div class='classinfo' style='border-color:var(--Purple-3); font-size: 6px;'>
                            The art of anti-matter magic and nothingness.
                        </div>
                    </div>
                </div>
            </div>
                <div>
                    <f7><b>Grey:</b> Is the school non-magical studies, including langauges, history, and logic.</f7>
                </div>
        </rulebox><abilitysubtitle class='astPurple'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Mage 1 
            </abilitysubtitle>
            <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Purple-3);'>
                 If taken in Character Creation, may exchange Clothes for Mage Robes.  <b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div>5 AP Training towards Ether Type.</b>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Mage 2 
            </abilitysubtitle>
            <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Purple-3);'>
                Gain Arcane Missile, Take less backlash, and step when preform Arcane Tricks, Increased Arcanum. <b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div>5 AP Training towards Ether Type.</b>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astPurple' style='border-radius:4px 0px 0px 4px;'> 
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Mage 3 
            </abilitysubtitle>
            <abilitysection class='asecPurple' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Purple-3);'>
                Cast Mage Step, Arcane Fog, May move pace when Incanting, No Novice caster backlash, Increased Arcanum. <b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div>5 AP Training towards Ether Type.</b>
            </div>
        </div>
        </rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Purple-4);'>
            <div>Mage 1 <small>- Novice</small></div>
            <div style='display:flex; align-items:center; font-size:9px;'><div></div></div>
        </rulecardtitle><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Prepare Spell</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    May apply up to <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div> Prepare Cost of Spell.
                    <br> Spells Prepare Cost's are cumulative.
                    <br> <b>Consume Spell Material:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPurple'>
            Cantrips
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Ball of Light</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist</b> <keywordPurple>1 Fatigue</keywordPurple> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                <br>Create Ball of <keywordPurple>Light 2</keywordPurple> that lasts up to 5 Minutes.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Arcane</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Determine if any Arcane Magic is nearby and possibly it's nature.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPurple'>
            Arcane Spellcasting
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Purple-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/3 <small>Arcanum (Incanted) of Type</small></div>
        </div><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b><f7>Arcane Magic requires a free hand, standing, speaking loudly, freedom of movement.
            Otherwise may make Incanting or Reducing Backlash <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> or impossible.</b></f7>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Incant</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>  <br><div style='font-size:7px;'><cs>-1 Spell Material:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div> <b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +1 <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><cs>1S:</cs> At Max Arcanum. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Move 1 Space.
                    <br> <b>Switch Arcanum Type:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Backlash per Arcanum.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cast</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cast</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    See Spell Arcanum Cost and Effect.
                    <br> <b>Overcharge:</b> May add Spell Overcharge Effects.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Backlash:</b> Defualt Spell <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> Overcharge <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                    <div style='height:1px;'></div><b>Resisting:</b> Reduce backlash by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <b>(<keywordPurple>1 Arcanum:</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>)</b>
                    <br> <f7>For each Backlash over Spell's listed Backlash Effects gain +1 Fatigue.</f7>
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Purple-4);'>
            <div>Mage 2 <small></small></div>
            <div style='display:flex; align-items:center; font-size:9px;'><div></div></div>
        </rulecardtitle><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Prepare Spell</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    May apply up to <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div> Prepare Cost of Spell.
                    <br> Spells Prepare Cost's are cumulative.
                    <br> <b>Consume Spell Material:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPurple'>
            Cantrips
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Ball of Light</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist</b> <keywordPurple>1 Fatigue</keywordPurple> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                <br>Create Ball of <keywordPurple>Light 2</keywordPurple> that lasts up to 1 Hour.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Arcane Trick</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>May do a simple magic trick. More Successes improves it. <br><f7> Ex: Snuff Candle, Colored Sparkles, Small Gust of Wind, Write Temporary Arcane Glyph into Surface.</f7> </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Arcane</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Determine if any Arcane Magic is nearby and possibly it's nature.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astPurple'>
            Arcane Spellcasting
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Purple-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/4 <small>Arcanum (Incanted) of Type</small></div>
            <div style='text-align:right; padding:0px 2px 0px 2px; margin-top:-5px;'><f7></f7></div>
        </div><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b><f7>Arcane Magic requires a free hand, standing, speaking loudly, freedom of movement.
                    Otherwise may make Incanting or Reducing Backlash <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> or impossible.</b></f7>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Incant</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>  <br><div style='font-size:7px;'><cs>-1 Spell Material:</cs> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div> <b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +1 <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><cs>1S:</cs> At Max Arcanum. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Move 1 Space.
                    <br> <b>Switch Arcanum Type:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Backlash per Arcanum.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cast</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Move 1 Space. Must not be Slowed and have a Pace of 1 or more..
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cast</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    See Spell Arcanum Cost and Effect.
                    <br> <b>Overcharge:</b> May add Spell Overcharge Effects.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Backlash:</b> Defualt Spell <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> Overcharge <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                    <div style='height:1px;'></div><b>Resisting:</b> Reduce backlash by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <b>(<keywordPurple>1 Arcanum:</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>)</b>
                    <br> <f7>For each Backlash over Spell's listed Backlash Effects gain +1 Fatigue.</f7>
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:0px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><br> Arcane Missile<br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Arcanum-Any</div></f7><br><f7>+3 Backlash</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'></div></actionContainter><div style='display:grid; grid-gap:1px;'><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc><b>+</b><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Overcharge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <b>+1 Backlash:</b> Go around allies and corners. <div style='height:1px;'></div> <b>+1 Backlash:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>1:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue.<br><b>2:</b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue. <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Casting Arm.<br><b>3:</b> +<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue. <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Casting Arm.</f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div></div></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr auto; background:var(--Purple-4);'>
            <div>Mage 3 <small></small></div>
            <div style='display:flex; align-items:center; font-size:9px;'><div></div></div>
        </rulecardtitle><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f9>Prep. Spell</f9></div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    May apply up to <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Prepare Cost of Spell.
                    <br> Spells Prep Costs are cumulative.
                    <b>Consume Spell Material:</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><abilitysubtitle class='astPurple'>
            Cantrips
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Ball of Light</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Resist</b> <keywordPurple>1 Fatigue</keywordPurple> w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div>.
                Create Ball of <keywordPurple>Light 2</keywordPurple>. Lasts up to a 6 hours.
                <br> Can be put onto a Staff or similar.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f9>Arcane Trick</f9></div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='height:1px;'></div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>May do simple magic trick. More Successes improves it. <br><f7> Ex: Snuff Candle, Colored Sparkles, Small Gust of Wind, Write Temporary Arcane Glyph into Surface.</f7> </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sense Arcane</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Determine if any Arcane Magic is nearby and possibly it's nature.</div></challengeText></challengeContainer></div></actionContainter><abilitysubtitle class='astPurple'>
            Arcane Spellcasting
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Purple-3); color:black; font-weight:700; font-size:10px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/5 <small>Arcanum (Incanted) of Type</small></div>
        </div><rulebox style='border-color:var(--Purple-3); background:var(--Purple-1);'>
            <b><f7>Arcane Magic requires a free hand, standing, speaking loudly, freedom of movement.
            Otherwise may make Incanting or Reducing Backlash <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div> or impossible.</b></f7>
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Incant</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><br><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>  <br><div style='font-size:7px;'><cs>-1 Spell Material:</cs> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div> <b style='font-size:7px;'>Untrained:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 7px;'><b>6 Only</b> </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +1 <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><cs>1S:</cs> At Max Arcanum. <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keywordPurple>Arcanum</keywordPurple> of chosen type.
                    <br><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Move 1 Space.
                    <br> <b>Switch Arcanum Type:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Backlash per Arcanum.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cast</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Move 1 Space. Must not be Slowed and have a Pace of 1 or more.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Cast</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    See Spell Arcanum Cost and Effect.
                    <br> <b>Overcharge:</b> May add Spell Overcharge Effects.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>Backlash:</b> Defualt Spell <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> Overcharge <keywordPurple>Backlash</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                    <div style='height:1px;'></div><b>Resisting:</b> Reduce backlash by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <b>(<keywordPurple>1 Arcanum:</keywordPurple> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>)</b>
                    <br> <f7>For each Backlash over Spell's listed Backlash Effects gain +1 Fatigue.</f7>
                </div></challengeText></challengeContainer></div></actionContainter><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:0px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Arcane Missile<br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Arcanum-Any</div></f7><br><f7>+2 Backlash</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'></div></actionContainter><div style='display:grid; grid-gap:1px;'><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc><b>+</b><img 
        src='/Resources/Art/Images/HexagonW_1R.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Energy</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Overcharge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <b>+1 Backlash:</b> Go around allies and corners. <div style='height:1px;'></div> <b>+1 Backlash:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f7><b>1:</b> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>2:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue. <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Casting Arm.<br><b>3:</b> +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue. <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg to Casting Arm.</f7>
                        </div></challengeText></challengeContainer></div></actionContainter></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Mage Step<br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Arcanum-Any</div></f7><br><f7>+1 Backlash</f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Move 2 Space along the ground. May be done as a Defensive Action.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Overcharge</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>+1 Backlash:</b> +3 Spaces, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
                </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Purple-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Backlash</div></div></challengeHead><challengeText style='; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <b>1:</b> +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Faitigue.
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Purple-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Arcane Fog<br><f7><div style='display:inline-block; 
        color:var(--Purple-4); background:var(--Purple-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Arcanum-Any</div></f7></div></div> <actionSubtitle style='color:black; '></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>Up to 3 Adjacent Spaces gain a Fog that lasts for 3 Rounds. Looking through the Fog has Visibility 1.</div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Monk' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Monk</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Monk (Class) <f8>Req: Any Athlete Level</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Monks</b> specialize in unarmed fighting and body control.
            Most Monk Schools originate from the eastern kands, but they exisit in pockets all over the world.
            Monks practice high control over their body and can even channel and bend their own ether to attempt feats impossible to others.
            <br><b>Chakra</b> is gained throgh silent meditation.
            This allows the Monk to clear their mind and strengthen their body, allowing them to better resist physical damage, or even the need to eat or sleep.
            <br><b>Ki</b> is channelled in battle through special Ki Strikes and is made of gathered ether.
            The more Ki a Monk has channelled the more powerful moves they can perform when it is unleashed.
            <br><b>Chain Techniques</b> involve a Monk doing multiple attacks in a single round of combat.
            This is very tiring, and they must use a different Limb for each attack.
        </rulebox><abilitysubtitle class='astOrange'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Monk 1 
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Monk 2
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Orange-3);'>
                Increased Chakra, cheaper Chain Technique, Flying Attack, Sweep Kick, Fox Stance.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astOrange' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Monk 3 
            </abilitysubtitle>
            <abilitysection class='asecOrange' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Orange-3);'>
                Increased Ki, improved Stances, Turtle Stance, Tiger Claw, improved Meditate.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astOrange'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astOrange'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Monk 1</div> 
        </rulecardtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astOrange'>
            Chakra
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/2 <keywordOrange>Chakra</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Chakra</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Resist Dmg/Fatigue/Hunger/Thirst/Terror/Stress/Dread/Infection/Dying. 
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Meditate</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <keywordOrange>Chakra</keywordOrange>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Stances
        </abilitysubtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can switch from/to any stance at the beginning of each Round.</b>
            <div style='height:3px;'></div> <b>Swallow Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> against Impede, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Pace.
            <div style='height:3px;'></div> <b>Leopard Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Martial Techniques
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/5 <keywordOrange>Ki</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Chain Technique:</b> Attempt an additional Active Martial Action this Round. May use each Arm and Leg once. (1 Main Arm Punch, 1 Off Arm Punch, 2 Kicks.)
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Ki Punch</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><keywordOrange>Bypass:</keywordOrange> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <keyword>Ki</keyword>.</div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Ki</div></f7> Roundhouse Kick</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Push 1 (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Ki</div></f7> Arm Guard</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Defend: Block</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                May be done after a Failed Dodge to continue to reduce Hit. 
                <br> Reduce Hit by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Arm used to Block has <b>DR</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Monk 2</div> 
        </rulecardtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astOrange'>
            Chakra
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/3 <keywordOrange>Chakra</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Chakra</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Resist Dmg/Fatigue/Hunger/Thirst/Terror/Stress/Dread/Infection/Dying. 
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Meditate</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <keywordOrange>Chakra</keywordOrange>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Stances
        </abilitysubtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can switch from/to any stance at the beginning of each Round.</b>
            <div style='height:3px;'></div> <b>Swallow Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> against Impede, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Pace.
            <div style='height:3px;'></div> <b>Leopard Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
            <div style='height:3px;'></div> <b>Fox Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ki per Round.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Martial Techniques
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/5 <keywordOrange>Ki</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Chain Technique:</b> Attempt an additional Active Martial Action this Round. May use each Arm and Leg once. (1 Main Arm Punch, 1 Off Arm Punch, 2 Kicks.)
            <br> <b>Flying Attack:</b> If jumping from one space above Target get +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Ki Punch</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><keywordOrange>Bypass:</keywordOrange> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <keyword>Ki</keyword>.</div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Ki</div></f7> Sweep Kick</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> (Legs Only)</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Knockdown 2 (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Ki</div></f7><br> Roundhouse<br> Kick</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Ki</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Can attempt against additional Target.</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Push 1 (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Ki</div></f7> Arm Guard</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Defend: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                May be done after a Failed Dodge to continue to reduce Hit. 
                <br> Reduce Hit by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Arm used to Block has <b>DR</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Orange-4);'>
            <div>Monk 3</div> 
        </rulecardtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can't use Abilities in Light/Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astOrange'>
            Chakra
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/3 <keywordOrange>Chakra</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Chakra</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Resist Dmg/Fatigue/Hunger/Thirst/Terror/Stress/Dread/Infection/Dying. 
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    ;'><div style='text-align:center;'><div style='text-align:left;'>Meditate</div></div> <actionSubtitle style='margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <keywordOrange>Chakra</keywordOrange>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Stances
        </abilitysubtitle><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <b>Can switch from/to any stance at the beginning of each Round.</b>
            <div style='height:3px;'></div> <b>Swallow Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> against Impede, +1 to Pace.
            <div style='height:3px;'></div> <b>Leopard Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
            <div style='height:3px;'></div> <b>Fox Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Ki per Round.
            <div style='height:3px;'></div> <b>Turtle Stance</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Can't Attack, -1 Pace, +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge, <b6>Arm Guard:</b6> <b>0</b><keyword>Ki</keyword>, Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> <keyword>Ki</keyword>
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astOrange'>
            Martial Techniques
        </abilitysubtitle><div style='display:grid; grid-template-columns:1fr; border-style:solid; border-width:1px; border-color:var(--Orange-3); color:black; font-weight:700; font-size:13px;'>
            <div style='text-align:right; padding:4px 2px 4px 2px;'>/6 <keywordOrange>Ki</keywordOrange></div>
        </div><rulebox style='border-color:var(--Orange-3); background:var(--Orange-1);'>
            <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Chain Technique:</b> Attempt an additional Active Martial Action this Round. May use each Arm and Leg once. (1 Main Arm Punch, 1 Off Arm Punch, 2 Kicks.)
            <br> <b>Flying Attack:</b> If jumping from one space above Target get +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
        </rulebox><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Ki Punch</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'></div></actionContainter><div style='display:grid; grid-template-rows:auto 1fr; grid-gap:2px;'><div style='display:grid; grid-template-columns:auto 1fr; grid-gap:2px;'><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><keywordOrange>Bypass:</keywordOrange> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><div style='display:flex; align-items:center; margin-right:2px;'><img 
        src='/Resources/Art/Images/RightArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div><actionContainter style='font-size: ; grid-template-columns:1fr; ; '><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>Gain <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> <keyword>Ki</keyword>.</div></challengeInner>
                                </challenge>
                            </challengeContainer></div></actionContainter></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>2 Ki</div></f7> Sweep Kick</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> (Legs Only)</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Knockdown 2 (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Ki</div></f7><br> Roundhouse<br> Kick</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '>
                                <challenge style='border-radius:4px 4px 4px 4px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; border-style:solid; border-width:2px 2px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Ki</div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Can attempt against additional Target.</div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 4px 4px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            </challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Push 1 (Resist w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div>/<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div>)</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>3 Ki</div></f7> Tiger Claw</div></div> <actionSubtitle style='margin-left:3px;'>Active: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto auto 1fr;; '><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Strike&nbsp;<img 
        src='/Resources/Art/Images/Hexagon_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'><keywordOrange>Bypass:</keywordOrange> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto auto auto 1fr;; '><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div><challengeHead style='; background:var(--Orange-2);'><div style='display:flex; align-items:center; font-size:9px;'><div>Bash</div></div></challengeHead>
                                <challenge style='border-radius:0px 0px 0px 0px;  background:var(--Orange-2)); border-color:var(--Orange-2);background:white;; '>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>Bleeding 2</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Orange-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Orange-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f7><div style='display:inline-block; 
        color:var(--Orange-4); background:var(--Orange-1);
        border-radius:4px; padding:0px 2px 0px 2px; font-weight:700;
        position:relative; top:-1px;'>1 Ki</div></f7> Arm Guard</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Defend: Martial</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Orange-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                May be done after a Failed Dodge to continue to reduce Hit. 
                <br> Reduce Hit by <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>. Arm used to Block has <b>DR</b> <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                <br> <b>Catch Weapon:</b> If beating Hit By +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> may attempt Grapple:Disarm against Weapon.
                </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div id='Rogue' style='grid-column: 1 / -1;font-size: 30px;font-weight: 900;color: white;margin-bottom:-6px;'>Rogue</div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Blue-4);'>
            <div>Rogue (Class) <f8>Req: Any Athlete Level</f8></div> 
        </rulecardtitle><rulebox style='border-color:var(--Blue-3); background:var(--Blue-1);'>
            <b>Rogues</b> specialize in stealing, acrobatics, and sneak attacks.
            Rogues come in many forms, but most from poor urban neighborhoods, having learned their trade in order to survive.
            Often on the wrong side of the law, Rogues are often for jobs as theives, assassins, and other dirty work.
            <br><b>Infiltration</b> is the are of sneaking into areas. A Rogue may use these skills to create a route for allies as well.
            <br><b>Flanking</b> is a primary tactic of the Rogue. This involves surrounding a Target and using the disctraction to perform a more devasting attack.
            <br><b>Sneak Attacks</b> are where Rogues are at their best.
            When able to move around the battlefield unseen and get the drop on their Targets, Rogues can do tremendous damage or even steal directly from the Target.
        </rulebox><abilitysubtitle class='astBlue'>
            Core
        </abilitysubtitle>
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astBlue' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rogue 1
            </abilitysubtitle>
           <abilitysection class='asecBlue' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astBlue' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rogue 2
            </abilitysubtitle>
            <abilitysection class='asecBlue' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Blue-3);'>
                Sand Dodge, additional Flank/Sneak Attack options, Hidden Items, Pick Locks.
            </div>
        </div>
        
        <div style='display:grid; grid-template-columns:auto 1fr auto;'>
            <abilitysubtitle class='astBlue' style='border-radius:4px 0px 0px 4px;'>
                <div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> Rogue 3 
            </abilitysubtitle>
            <abilitysection class='asecBlue' style='display:grid; grid-template-columns:1fr auto; grid-gap:2px; font-weight:700; background:white; border-radius:0px 4px 0px 0px;'>
                <div style='display:flex; align-items:center; justify-content:flex-end;'><f8>/20<div style='display:inline; color:black; font-weight:800;'>XP</div><f8></div>
            </abilitysection>
            <div style='display: flex; justify-content: center; align-items: center; grid-gap: 2px; margin-right: 2px; margin-left: 2px;'>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
                <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>
            </div>
            <div class='classinfo' style='border-color:var(--Blue-3);'>
                Gain Silent Kill, Double Attack, Sneak Attack Grapple, Improved Pick Lock/<br>Flank Attack/Sneak Attack.
            </div>
        </div>
        <div style='height:5px;'></div><abilitysubtitle class='astBlue'>
            Advanced
        </abilitysubtitle><div style='height:5px;'></div><abilitysubtitle class='astBlue'>
            Mastery
        </abilitysubtitle></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Blue-4);'>
            <div>Rogue 1</div> 
        </rulecardtitle><rulebox style='border-color:var(--Blue-3); background:var(--Blue-1);'>
            <b>Can't use Abilities in Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astBlue'>
            Thief Skills
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Guide Infiltration</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>Guide Allies into the area you already snuck into (ex: around a corner, through a door). </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Allies Stealth Checks.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <b>Rouge Reflexes:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Sneaking/Hiding/Stealing/Acrobatics Challenges. May attempt some that others cannot.
            <br> <b>Readied Items:</b> May have +1 Readied Item.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Combat Skills
        </abilitysubtitle><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <b>Impoved Dodge</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
            <br><b>Improved Throwing</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit and Dmg when attempting Throw Attacks.
            <br> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Theif's Luck</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Prevent +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Damage.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flee</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Active, Defend:Dodge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Must be moving away from Attacker.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Reduce</b> Strike/Proj by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Surprise Attacks
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flank<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Can apply when <keywordBlue>Flanking</keywordBlue>. (In addition to standard +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.)</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div><keywordBlue>Sneak Attack</keywordBlue> occurs when attacking a Target unaware of you.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> <b>vs</b><div style='height:1px;'></div> <b>Target</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Target can't Attack you.
                    <br><cs>1S:</cs> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Dmg.
                    <br><cs>1S:</cs> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Target's Defend.
                    <br><sc>1S:</sc> May take non Held/Worn Item.
                    </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Blue-4);'>
            <div>Rogue 2</div> 
        </rulecardtitle><rulebox style='border-color:var(--Blue-3); background:var(--Blue-1);'>
            <b>Can't use Abilities in Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astBlue'>
            Theif Skills
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Guide <br> Infiltration</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>Guide Allies into the area you already snuck into (ex: around a corner) </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Allies Stealth Checks.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Nimble Fingers<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to fine finger movements. <f8>Ex. Picking Lock, Disarming Trap, Stealing</f8></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Covert Movement<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hiding/Sneaking</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Acrobatic<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Acrobatics Challenges. May attempt some that others cannot.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <b>Hidden Items:</b> 1E may be hidden in such a way that it is rarely found when searched.
            <br> <b>Readied Items:</b> May have +2 Readied Items.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Combat Skills
        </abilitysubtitle><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <b>Impoved Dodge</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
            <br><b>Slippery</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Escape Grapple.
            <br><b>Improved Throwing</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit and Dmg when attempting Throw Attacks.
            <div style='height:2px;'></div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Theif's Luck</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Prevent +<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Damage.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flee</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Active, Defend:Dodge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Must be moving away from Attacker.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Reduce</b> Strike/Proj by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Taunt</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Target must reroll check and take new result if lower.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Surprise Attacks
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flank<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Can apply when <keywordBlue>Flanking</keywordBlue>. (In addition to standard +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.)</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bypass.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div><keywordBlue>Sneak Attack</keywordBlue> occurs when attacking a Target unaware of you.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> <b>vs</b><div style='height:1px;'></div> <b>Target</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Target can't Attack you.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Dmg.
                    <br><cs>1S:</cs> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Target's Defend.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Grapple if Grabbing this Round.
                    <br><sc>1S:</sc> May take non Held/Worn Item.
                    <br><cs>1S:</cs> +1 Bypass.
                    </div></challengeText></challengeContainer></div></actionContainter></rulecard></div><div style='display:grid; grid-template-columns:356px ; grid-gap:2px;'><rulecard><rulecardtitle style='display:grid; grid-template-columns:1fr; background:var(--Blue-4);'>
            <div>Rogue 3</div> 
        </rulecardtitle><rulebox style='border-color:var(--Blue-3); background:var(--Blue-1);'>
            <b>Can't use Abilities in Medium/Heavy Armor</b>
        </rulebox><abilitysubtitle class='astBlue'>
            Theif Skills
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Guide <br> Infiltration</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>Guide Allies into the area you already snuck into (ex: around a corner) </div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to all Allies Stealth Checks.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Nimble Fingers<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to fine finger movements. <f8>Ex. Picking Lock, Disarming Trap, Stealing</f8></div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Covert Movement<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hiding/Sneaking, May reroll.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);     ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><f10>Acrobatic<f10></div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Challenge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Acrobatics Challenges. May attempt some that others cannot.</div></challengeText></challengeContainer></div></actionContainter><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <div style='height:2px;'></div> <b>Hidden Items:</b> 1E may be hidden on person. May draw hidden items as Free Action.
            <div style='height:2px;'></div> <b>Readied Items:</b> May have +3 Readied Items.
        </rulebox><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Combat Skills
        </abilitysubtitle><rulebox style='border-color:var(--Blue-3);  background:var(--Blue-1);'>
            <b>Impoved Dodge</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
            <br><b>Slippery</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Escape Grapple.
            <div style='height:2px;'></div><b>Impoved Throwing</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit and Dmg when attempting Throw Attacks.
            <div style='height:2px;'></div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Double Attack:</b> May attack with two Knife type weapons this round.
            <div style='height:2px;'></div> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> <b>Theif's Luck</b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> Prevent +<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Damage.
        </rulebox><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flee</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Active, Defend:Dodge</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Must be moving away from Attacker.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><b>Reduce</b> Strike/Proj by <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Silent Kill</div></div> <actionSubtitle style='margin-left:3px;'>Grapple</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S</sc> Muffle Target so they cannot Speak.
                    <br><div style='display: flex;'><div style='display:flex; align-items:center; margin:0px 2px 0px 2px;'><img 
        src='/Resources/Art/Images/ReturnArrow.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '></div> <sc>1S:</sc> May attempt Attack with +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>&nbsp; to Hit and Dmg.</div>
                </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '> Taunt</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b>Contest:</b><br><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> (you) vs <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> (target)</div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> Target must reroll check and take new result if lower.
                </div></challengeText></challengeContainer></div></actionContainter><div style='height:2px;'></div><abilitysubtitle class='astBlue'>
            Surprise Attacks
        </abilitysubtitle><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Flank<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div>Can apply when <keywordBlue>Flanking</keywordBlue>. (In addition to standard +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.)</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Hit.
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dmg.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Dodge.
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<cs>1S:</cs> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bypass.
                    </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Blue-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Blue-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sneak<br>Attack</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Melee<br>Attack</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:var(--Blue-3); padding:2px; color:black; font-size:; background:white; height:100%;'><div><keywordBlue>Sneak Attack</keywordBlue> occurs when attacking a Target unaware of you.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Blue-2)); border-color:var(--Blue-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <b>vs</b><div style='height:1px;'></div> <b>Target</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div><div style='height:2px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Blue-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                    <sc>1S:</sc> Target can't Attack you.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Dmg.
                    <br><cs>1S:</cs> -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Target's Defend.
                    <br><cs>1S:</cs> +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Grapple if Grabbing this Round.
                    <br><sc>1S:</sc> May take non Held/Worn Item.
                    <br><cs>1S:</cs> +2 Bypass.
                    </div></challengeText></challengeContainer></div></actionContainter></rulecard></div></div>    </div>
</body>
</html>