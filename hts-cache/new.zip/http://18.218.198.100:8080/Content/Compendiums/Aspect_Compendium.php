<html>
<head>
    <title>Aspect Compendium</title>
    <style>
    b1 /*Bold*/ {Font-weight: 100;}
    b2 /*Bold*/ {Font-weight: 200;}
    b3 /*Bold*/ {Font-weight: 300;}
    b4 /*Bold*/ {Font-weight: 400;}
    b5 /*Bold*/ {Font-weight: 500;}
    b6 /*Bold*/ {Font-weight: 600;}
    b7 /*Bold*/ {Font-weight: 700;}
         b /*Bold*/ {Font-weight: 700;}
    b8 /*Bold*/ {Font-weight: 800;}
    b9 /*Bold*/ {Font-weight: 900;}
    bf10 /*Bold*/ {Font-weight: 700; font-size: 10px}

    sc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: black;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    cs
    {
        display: inline-block;
        background: white;
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: solid;
        border-color: black;
        border-width: 1px;
        border-radius: 4px;
        color: black;
        Font-weight: 800;
        line-height: 1.1;
    }
    fc /*success cost (<sc>1S:</sc> effect)*/
    { 
        display: inline-block;
        background: hsla(0,55%,30%,1);
        padding: 0px 3px 0px 3px;
        margin: 1px 1px 1px 1px;
        border-style: none;
        border-radius: 4px;
        color: White;
        Font-weight: 800;
        line-height: 1.1;
    }
    stat 
    {
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: black;
        
        font-weight:700;
    }
    dc /*Damage Cost*/ {
        background:hsla(0,55%,30%,1);
        border-radius: 4px;
        color: white;
        Font-weight: 500;
        padding: 0px 2px 0px 2px;
    }
    mini /* Useful for small suplmental text*/
    {
       display:inline-block; 
       font-size:8px;
    }
    noWrap
    {
        white-space: nowrap;
        display: inline-block;
    }
    end {
        align-self: center;
        display: grid;
        grid-auto-flow: column; 
        grid-gap: 0px 2px;
        align-items: end;
        justify-content: left;
    }    
    hit {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        font-weight: 700;
        color: white;
        white-space: nowrap;

    }
    dmg {
        display: inline-block;
        background: hsla(21.6,0%,40%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 1px 2px;
        margin: 1px 0px;
        min-height: 14px;
        
        font-weight: 700;
        color: white;
        white-space: nowrap;
    }
    dmgEffect
    {
        display: inline-block;
        background: hsla(0,55%,95%,1);
        color: hsla(0,55%,20%,1);
        border-color: hsla(0,55%,20%,1);
        color: black;
        font-size:9px;
        font-weight: 400;
        border-radius: 2px;
        border: 1px solid;
        padding: 0px 2px;
    }
    lvl {
        display: inline-block;
        border-radius: 5px;
        padding: 0px 2px 0px 3px;
        border-radius: 4px 0px 0px 4px;
        font-weight: 800;
        background: hsla(0,0%,25%,1);
        color: white;
        margin-top: 1px;
    }
    resist {
        display:inline-block;
        background:white; 
        padding:1px 2px 1px 2px;
        margin-top:1px;
        margin-left:3px;
        border-radius:4px;
        color:black;
        font-weight:400;
        margin-bottom:1px;
    }
    cb {
        display:inline-block; 
        border-style:solid; 
        border-radius: 4px;
        border-color: var(--Gray-2);
        border-width:1px; 
        height: min-content;
        /*background:white;*/
        padding: 0px 2px 0px 0px; 
    }
    gc { /*Grey Cost*/
         /*display: inline-block;*/
        background: var(--Gray-1);
        padding: 0px 2px 0px 2px;
        border-style: none;
        border-radius: 4px 0px 0px 4px;
        height: 100%;
        color: black;
        Font-weight: 800;
        line-height: 1.1;   
    }
    sb{
        display:inline; 
        padding:0px 2px 0px 2px; 
        border:1px solid var(--Gray-3); 
        background:--var(Gray-1); 
        border-radius:4px;
    }
    sbi{
        display:inline;
        font-size:90%;
        font-weight: 700;
    }
    
    keyword {
        display:inline;
        color:hsla(244.8,55%,40%,1);
        font-weight: 700;
    }
    keywordGray {
        display:inline;
        color:var(--Gray-4);
        font-weight: 700;
    }
    keywordred {
        display:inline;
        color:var(--Red-4);
        font-weight: 700;
    }
    .kRed{color:var(--Red-4);}
    keywordyellow {
        display:inline;
        color:var(--Yellow-4);
        font-weight: 700;
    }
    keywordpurple {
        display:inline;
        color:var(--Purple-4);
        font-weight: 700;
    }
    keywordpink {
        display:inline;
        color:var(--Pink-4);
        font-weight: 700;
    }
    keywordturquoise {
        display:inline;
        color:var(--Turquoise-4);
        font-weight: 700;
    }
    keywordgreen {
        display:inline;
        color:var(--Green-4);
        font-weight: 700;
    }
    keywordblue {
        display:inline;
        color:var(--Blue-4);
        font-weight: 700;
    }
    keywordorange {
        display:inline;
        color:var(--Orange-4);
        font-weight: 700;
    }
    
    titleword {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Gray-4);
    }
    .twRed { background:var(--Red-3); }
    .twTurquoise { background:var(--Turquoise-3); }
    .twPurple { background:var(--Purple-3); }
    .twGreen { background:var(--Green-3); }
    .twBlue { background:var(--Blue-3); }
    titlewordred {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Red-4);
    }
    titlewordpurple {
        display:inline;
        font-weight:800;
        color:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        background:var(--Purple-4);
    }
    
    titlewordfree {
        display:inline;
        font-weight:800;
        background:white;
        padding:0px 4px 0px 4px;
        border-radius:4px;
        border-style:solid;
        border-width:1px;
        color:black;
        border-color:black;
    }
    .twfRed { color:var(--Red-4); border-color:var(--Red-4);}
    .twfTurquoise { color:var(--Turquoise-4); border-color:var(--Turquoise-4);}
    .twfGreen { color:var(--Green-4); border-color:var(--Green-4);}
    .twfBlue { color:var(--Blue-4); border-color:var(--Blue-4);}
    .twfOrange { color:var(--Orange-4); border-color:var(--Orange-4);}
    
    f7 {
        display:inline;
        font-size:7px;
    }
    f8 {
        display:inline;
        font-size:8px;
    }
    f9 {
        display:inline;
        font-size:9px;
    }
    f10 {
        display:inline;
        font-size:10px;
    }
    f11 {
        display:inline;
        font-size:11px;
    }
    f12 {
        display:inline;
        font-size:12px;
    }
    f13 {
        display:inline;
        font-size:13px;
    }
    f14 {
        display:inline;
        font-size:13px;
    }
    f15 {
        display:inline;
        font-size:14px;
    }
    f16 {
        display:inline;
        font-size:16px;
    }
    gtxt {
        color: hsl(0, 0%, 70%);
    }
    abilitysubtitle{
        font-weight:700; 
        color:white;
        font-size:9px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    abilitysectiontitle{
        font-weight:700; 
        color:white;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        margin-top: 0px;
        padding:1px 2px 1px 5px;
        background:var(--Gray-3);
    }
    .astGray{background:var(--Gray-3);}
    .astRed{background:var(--Red-3);}
    .astPink{background:var(--Pink-3);}
    .astPurple{background:var(--Purple-3);}
    .astYellow{background:var(--Yellow-3);}
    .astTurquoise{background:var(--Turquoise-3);}
    .astGreen{background:var(--Green-3);}
    .astBlue{background:var(--Blue-3);}
    .astOrange{background:var(--Orange-3);}
    abilitysection{
        border:solid 1px; 
        border-radius:4px;
        font-size:80%;
        padding:1px 2px 1px 2px; 
        background:var(--Gray-1); 
        border-color:var(--Gray-3);
    }
    .asecGray{background:var(--Gray-1); border-color:var(--Gray-3);}
    .asecRed{background:var(--Red-1); border-color:var(--Red-3);}
    .asecPink{background:var(--Pink-1); border-color:var(--Pink-3);}
    .asecPurple{background:var(--Purple-1); border-color:var(--Purple-3);}
    .asecYellow{background:var(--Yellow-1); border-color:var(--Yellow-3);}
    .asecTurquoise{background:var(--Turquoise-1); border-color:var(--Turquoise-3);}
    .asecGreen{background:var(--Green-1); border-color:var(--Green-3);}
    .asecBlue{background:var(--Blue-1); border-color:var(--Blue-3);}
    .asecOrange{background:var(--Orange-1); border-color:var(--Orange-3);}
    
    .vCenter{display:flex; align-items:center;}
    
    red
    {
        display: inline;
        color: red;
    }
    
    blue
    {
        display: inline;
        color: blue;
    }
    
    bpcombat
    {
        display:inline;
        font-weight:800;
        color: red;
    }
    bpgold
    {
        display:inline;
        font-weight:800;
        color: #fcba03;
    }
    bpsurvival
    {
        display:inline;
        font-weight:800;
        color: #0cbec4;
    }
    bprecovery
    {
        display:inline;
        font-weight:800;
        color: #1250e0;
    }
    bputility
    {
        display:inline;
        font-weight:800;
        color: #850ba3;
    }
    bptotal
    {
        display:inline;
        font-weight:800;
        color: black;
    }
    
    .classinfo
    {
        margin-left: 5px; 
        padding-left: 3px; 
        font-size: 8px; 
        font-style: italic; 
        grid-column: span 3; 
        font-weight:500; 
        border: 1px solid;  
        border-radius: 0px 0px 4px 4px;
    }
    
</style>
</style><link rel='stylesheet' type='text/css' href='/Resources/style.css'><link rel='stylesheet' type='text/css' href='/Resources/normalize.css'><style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
</style><style> @import url('https://fonts.googleapis.com/css?family=Francois+One'); </style><style> @import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap'); </style><style>
    actionContainter {
        display:grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        grid-gap: 2px;
    }
    actionTitle {
        background: hsla(122.4,0%,20%,1);
        border-radius: 4px 0px 0px 4px;
        margin-right: -1px;
        color: white;
        font-weight: 800;
        padding: 2px;
        
        display:inline-flex;
        justify-content: center;
        align-items:center;
       
    }
    actionSubtitle {
        font-weight: 700; 
        display:inline-flex; 
        justify-content: center;
        padding: 0px 2px;
        font-style:italic;
        font-size: 75%;
        display:block;
    }
    challengeContainer {
        display: inline-grid; 
        grid-template-columns: auto;  
        grid-auto-flow:column; 
        justify-content: start;
        
        grid-template-columns:auto auto 1fr;
    }
    challengeHead {
        background: hsla(122.4,0%,30%,1);
        border-radius: 4px 0px 0px 4px;
        padding: 2px;
        
        color: white;
        font-weight: 700;
        padding-right:3px;
        
        display:inline-flex;
        align-items:center;
    }
    challenge {
        display:flex;
        border-radius: 4px;
        border-width: 2px 2px 2px 2px;
        border-style: solid solid solid none;
        border-color: hsla(122.4,0%,44%,1) ;
        
        background: hsla(122.4,0%,44%,1);
        
        font-weight: 500;
        color: white;
        
        border-radius:4px 0px 0px 4px;
        
        align-items:center;
        border-radius:0px
    }
    challengeInner {
        display:flex;
        background: white;
        padding: 2px;
        color: black;
        font-weight: 500;
        border-radius: 4px;
        margin-left: 4px;
        height:100%; 
        align-items:center;
        font-size: 80%;
        width:100%;
    }
    challengeText {
        display:inline-flex;
        align-items:center;
        border-radius:0px 4px 4px 0px;
        border-width:1px;
        border-style:solid solid solid none;
        border-color:black;
        padding:1px 2px 1px 1px;
        font-size: 80%;
    }
    RuleTitle {
        display: block;
        color: Black; 
        border-radius: 100px 100px 0px 0px; 
        padding: 2px 2px 2px 15px;
        margin-bottom: 0px;
        font-family: 'Oswald', sans-serif;
        font-size: 15px; 
        font-weight: 600;
        text-align: center;
        vertical-align: middle;
    }
    small{
        display:inline-block;
        font-size:80%;
    }
    
    
    situationHeader {
        background: hsla(122.4,0%,81%,1); 
        color: Black; 
        border: 1px solid black; 
        border-radius: 4px;
        font-weight: 800; 
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px 1px 0px 1px;
        font-size:80%;
    }
    
    RuleSection {
        display:grid; 
        grid-template-columns:80px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    RuleHeader {
        background:hsla(41.4,0%,78%,1);
        font-weight:600;
        font-size:10px;
        color:black;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    
    rulecard
    {
        display:grid; 
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:3.70in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardmetadata
    {
        background:white; 
        color:black; 
        padding:2px;
        width:100%;
        border-radius:4px;
        font-size:11px;
    }
    rulecardwide
    {
        display:grid; 
        grid-template-rows:auto 1fr;
        grid-gap:1px;
        align-content:start;
        height:5.20in; width:7.30in; padding:0px; color:black;
        font-size:10px;
        background:white;
        border-radius:4px;
    }
    rulecardtitle {
        background:black;
        color:white;
        font-weight:700;
        font-size:12px;
        padding:2px 2px 1px 5px;
        border-radius:4px;
    }
    rulecardsubtitle {
        /*background: hsla(122.4,0%,40%,1);*/
        background: black;
        color: white;
        font-weight:700;
        font-size: 9px;
        padding: 2px 2px 1px 2px;
        border-radius:4px 4px 0px 0px;
        margin-top: 0px;
    }
    
    rulebox {
        display: block;
        border-radius:4px; border:solid 1px black; 
        padding:1px 2px 1px 2px; 
        font-size:8px;
        background:var(--Gray-1);
    }
    .rbRed {background:var(--Red-1); border-color:var(--Red-3);}
    ruleboxTab {
        display: block;
        margin-left:10px; 
        margin-top:2px; 
        font-size:8px;
    }
    
    
    SubTitle {
        display: block;
        background:var(--Gray-3);  
        color: black; 
        
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        line-height: 12px;
        
        background: white; 
        padding: 2px 0px 0px 0px; 
        border-bottom: 2px solid black; 
        border-radius: 0px;
    }
    
    BasicsSection {
        display:grid; 
        grid-template-columns: 100px 1fr; 
        grid-auto-flow:column; 
        width:100%; 
        grid-gap:2px;
    }
    
    BasicsHeader {
        background:var(--Gray-1);
        color:black;
        font-weight:600;
        font-size:12px;
        border-right: 1px solid black;
        padding-left: 2px;
        margin-left: 5px;
        margin-top: 2px;
        margin-bottom: 2px;
        
        display:flex;
        align-items:center;
        justify-content:start;
    }
    BasicsHeaders {
        background:var(--Gray-3);
        color:white;
        font-weight:700;
        font-size:12px;
        border-radius:4px 4px 4px 4px;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    BasicsText {
        background:white;
        font-weight:400;
        font-size:10px;
        color:black;
        display:flex;
        align-items:center;
        padding:2px 0px 2px 0px;
    }
    SideTitleContentGrid {
        display:grid; 
        grid-auto-flow:column; 
        grid-template-columns:auto 1fr; 
        grid-gap:2px; 
    }
    RotatedTitleContainer 
    {
        display:flex; 
        align-items:center; 
        justify-content:center; 
        padding:1px; 
        font-weight:600; 
        width:20px; 
        border-style:solid; 
        border-width:1px; 
        border-radius: 4px;
        font-size:10px; 
        background: var(--Gray-2);
    }
    RotatedTitle {
        transform:rotate(-90deg); 
        transform-origin: 50% 50%;
        white-space: nowrap;
    }
    
</style>
</head>
<style type="text/css">
    body {
        width: 100%;
        background: gray;
    }
    #CompendiumInfoBox {
        position: fixed;
        overflow-y:scroll;
        overflow-x:hidden;
        right: 0px;
        top: 0px;
        bottom: 0px;
        width: 150px;
        background: white;
        color: black;
        padding: 5px;
        border-radius: 4px;
        z-index:100;
    }
    .CompendiumHead {
        font-size: 16;
        font-weight: 700;
    }
    .linkHead0 {
        font-weight: 900;
        font-size: 20px;
    }
    .linkHead1 {
        font-weight: 900;
        font-size: 16px;
        padding-left: 5px;
    }
    .linkHead2 {
        font-weight: 900;
        font-size: 12px;
        padding-left: 10px;
    }
</style>
<body style="color: white;">
<div style="width: 800px">

<div style='display: grid;grid-template-columns: repeat(8, 155px);padding: 5px;margin-left: 150px;grid-gap: 5px 5px;'><div id='Edges' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Edges</div><div id='5XP Edges' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>5XP Edges</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$StreetSmarts</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Street Smarts<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can only be done in Cities and Towns.</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Petty Theft</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><b>All:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold
                            <br> <sc>1S:</sc> 2 Disgusting Food.
                            <br> <sc>2S:</sc> 2 Disgusting Food + 1 Meal.
                            <br> <sc>3S:</sc> 2 Meal.
                        </div></challengeText></challengeContainer></div></actionContainter><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Gold wheneever Begging/Busking/Underworld (Job)/Street Preach.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Experience stealing and living on the street.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$StrongStomach</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Strong Stomach<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to eat Disgusting Food and Raw Meat.
                <br>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Illness when eating Mystery Food.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Can eat foods that would make others gag.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Cannibal</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Cannibal<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Req: Must have Wilderness Background or Sociopath Aspect.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Ingore Dread effects when eating humanoid flesh.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have an acquired taste for human flesh.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Rugged</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Rugged<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> on <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> Challenges	</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+2 Capacity.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are tough and don't mind doing physical work.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$NaturalLeader</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Natural Leader<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> on <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Challenges.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> on Encourage Checks.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have strong andinfluential personality.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Sociopath</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Sociopath<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP <div style='display:inline-flex; background:white; color:grey; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div> </div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Ignore Effects of First Kill on a Person, Cold Blooded Murder, Witness Something Terrible.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Total Morale.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have no qualms about killing people in cold blood.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$VerySmall</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Diminutive<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Human Only.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Max <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str 1
    </div>, Max <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort 2
    </div>.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> to Stealth/Hide in small areas.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Hunger. +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Thirst.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Capacity</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Light (10<b6>E</b6>)</div><div style='color: White;font-size: 12px;font-weight: 700;border-radius: 4px;padding: 0px 2px;background: var(--Green-2);margin-bottom: 1px;'>Optional Flavour</div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Green-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Goblin Blood</div><div style='border: 1px solid var(--Green-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>Ex: Grandfather was a Goblin.</div></div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Green-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Halfling</div><div style='border: 1px solid var(--Green-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>Ex: From a people who are small.</div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are are under 5 feet tall.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$VeryTall</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Lanky<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Human Only.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Hit Range <img 
        src='/Resources/Art/Images/HexagonW_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> counts as <img 
        src='/Resources/Art/Images/HexagonW_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Pace.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to not be seen in certain Stealth/Hide Checks.</div><div style='color: White;font-size: 12px;font-weight: 700;border-radius: 4px;padding: 0px 2px;background: var(--Green-2);margin-bottom: 1px;'>Optional Flavour</div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Green-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Giants Blood</div><div style='border: 1px solid var(--Green-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>Ex: Grandfather was a Half Giant</div></div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Green-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Spriggan Blood</div><div style='border: 1px solid var(--Green-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>Ex: Great Grandmother was a Spriggan</div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have very long arms and legs.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$ElfBlood</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Elf Blood<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Human only. Req 2 of: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl 2
    </div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense 2
    </div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit 2
    </div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenges</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Hunger, Thirst, and Sleep.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have Elf Blood in you.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$DwarfBlood</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Dwarf Blood<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Human only, Requires 2 of: <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str 2
    </div> / <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort 2
    </div> / <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr 2
    </div>.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Dim Light Vision 3 (Applies +3 Visibility in Low Light.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+1 Capacity</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have Dwarf Blood in you.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='10XP Edges' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>10XP Edges</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$OgreBlood</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Ogre Blood<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-10CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Requires: Human, <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Str 3
    </div> OR <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort 3
    </div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div> to Resist Hunger.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div> to not be seen in certain Stealth/Hide Checks.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Hit Range <img 
        src='/Resources/Art/Images/HexagonW_0.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> counts as <img 
        src='/Resources/Art/Images/HexagonW_1.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '>.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Pace.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+2 Capacity</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can use/attack with a Large Weapon with one Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Heavy 1 (Resist Push and similar by +1, 20<b6>E</b6>)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have Ogre Blood in you. Are over 6 and half feet tall. (Cannot mix with Lanky Aspect.)</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$CelestialBlood</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Celestial/Demon Blood<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-10CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Req:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha 2
    </div> AND <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit 2
    </div>.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Blood of an Angel/Demon far back in the family line. May have one unorthodox feature (hair color, eye color, etc.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Pray Actions.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Challenges.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>May use Favor to apply <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to any Stat Check.</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='height:1px;'></div><f8><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='8px'
        width='8px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '></f8><br> Soul Aura</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Free</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '><challengeHead style='; background:var(--Gray-3);'><div style='display:flex; align-items:center; font-size:9px;'><div>Circle 1R</div></div></challengeHead><challengeText style='; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                            All Allies prevent <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg or Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Harm.
                            <br> All Enemies gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Terror.
                        </div></challengeText></challengeContainer></div></actionContainter><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>May be considered a Celestial/Vile for some effects.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have Angel/Demon Blood deep in your ancestry.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Dragonblood</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Dragon Blood<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-10CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Req:</b> Cannot have any 0 in any Stats.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Blood of a dragon far back in the family line. May have one unorthodox feature (hair color, eye color, etc.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Fire Damage
               <br> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Resist Exposure.
               <br> Can remove Illness with only <cs>1S</cs>.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have Dragon Blood deep in your ancestry.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$AncestralWeapon</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Green-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Green-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Green-3);'>Ancestral Weapon<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-10CP</div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Lose Standard Weapon Cost x1.25 at Character Creation. (Must have Gold to Lose.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Gain Weapon that has been passed down from your family. May name weapon.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Pick one:</b> 
                   <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gain Mythril Weapon.
	               <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><sc>-100<div style='display:inline; color:black; font-weight:800;'>AP</div></sc> Gain a Magic Weapon.</blue>
	               <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <blue><sc>-100<div style='display:inline; color:black; font-weight:800;'>AP</div></sc> Gain a Cursed Weapon.</blue>
	        </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Green-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Penalties:</b>
                <br> If weapon is lost: Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> If selling weapon: Gain <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>7<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> If weapon is regained, lose all gained Dread.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> An ancient weapon has been passed down to you.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Drawbacks</div><div id='5XP Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>5XP Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$PoorVision</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Bad Vision<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Without Glasses, Visibility 1. Can’t Read.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>During Character Creation may get Glasses for 3<b6>G</b6>.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have poor sight requiring glasses.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$CantSwim</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Can't Swim<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't do normal Swim actions. Can't Learn Athelete Swimmer</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Air Loss<div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div></b>Don’t remove all Air Loss when Surfacing. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resist 2 Air Loss per Round w/ <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp<b>10 Air loss:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>KO</b> </div>. <b>20:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;height: 15px;'><img 
        src='/Resources/Art/Images/skull_white.svg' 
        height='12px'
        width='12px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div>.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Red-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Struggle</div></div> <actionSubtitle style='margin-left:3px;'>Full: Swimming</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Red-2)); border-color:var(--Red-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='height:1px;'></div><img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Red-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Move 1 Space. (Once)
                        <br><sc>1S:</sc> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> Air Loss (if at surface.)
                        <sc>1S:</sc> May Catch Breath.
                        </div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Red-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Learn to Swim</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/<div>15AP  <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div></div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You never learned to swim.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Pursued</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Pursued<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>You are being pursued for a crime or debt (ex: 100G). It will be difficult to get out of this, and the people looking fo you are malicious.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are being pursued by an organization.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$OneEye</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>One Eye<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Notice Actions.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Drawback:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Aim/Strike/Block/Dodge Actions.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Ignore Drawback. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If both eyes are lost: trade in for Blind Aspect.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Ignore Drawback (already adapted.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have lost vision in one eye.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Hideous</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Hideous<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Most people will not trust you and probably treat yo badly due to your noticably hideous/bizarre appearence.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> on Most Social Checks</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a bizzarre/hideous body. Allows other malformed Aspects.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Vegetarian</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Vegetarian<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress whenever eating Meat.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a psychological block preventing you from harming nature.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Allergies</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Allergies<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to eat Disgusting Rummage or Raw Meat.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>At the beginning of Combat out in Nature:</b> Roll <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Gain that much Allergy Con Points until end of Combat.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a sensitive stomach.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$BadLimb</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Bad Leg<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Cancel out a Leg Wound Point.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a fragile leg.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Reckless</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Reckless<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Resist 2 Stress w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> whenever fleeing or cowering from danger.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You find yourself unwilling to back down from danger.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Insomnia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Insomnia<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>For <b>Rest:Fatigue</b> roll <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b>Comfort</b>. <br>(This is <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> less than normal Character's Rest.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have trouble sleeping well.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Honorable</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Honorable<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can’t apply Flank Bonus or target unaware foes without gaining Dread.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are unwilling to use dirty tricks.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Phobia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Phobia<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                In Character Creation may take 2. 5<div style='display:inline; color:black; font-weight:800;'>AP</div> per Phobia.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='height:1px;'></div>
                <b>Phobia(s):</b>
                <div style='height:1px;'></div>
            </div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Purple-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Common<br> Phobia</div><div style='border: 1px solid var(--Purple-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>, Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> Water, Heights/Flying, Insects, Narrow Spaces, Blood, Darkness, Fire, Magic/Technology, Germs</div></div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Purple-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Rare<br> Phobia</div><div style='border: 1px solid var(--Purple-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>, Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> Spiders, Snakes, </div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a deep irrational fear of something.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Addict</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Addict<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display:grid; grid-template-columns:auto 1fr 1fr 1fr 1fr; grid-gap:7px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Active</b></div>
                    <div style='display: flex; flex-direction: rows; grid-gap: 2px;'><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <b>Inactive</b></div>
                </div>
                <f7>Character Creation: Aspect is Active and gain Pipe and 5G worth of Drugs.</f7>
            </div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Purple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Withdrawal</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'></div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <br> Taking Drug Withdrawal is set to <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Withdrawal.
                <br> Addiction <b>(A)</b> is a Con Point representing Addiction. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>1 Morale:</b> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Addiction. <b>Mental Breakdown:</b> May remove all A.
                <br><b>Relapse:</b> If Inactive, roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> for each Dread. <cs>1S:</cs> Active. Withdrawal <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </f8>
                
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <b>Withdrawal Effects:</b>
                <br>&nbsp;&nbsp;&nbsp; <b>0-2 Withdrawal:</b> No Effect.
                <br>&nbsp;&nbsp;&nbsp; <b>3-4 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>5-6 Withdrawal:</b> <b>(AAA<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>7-10 Withdrawal</b>: <b>(AA)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>11-15 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>16 Withdrawal:</b> No effect.
            </f8>
                
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You self medicate with addictive substances.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Alcoholic</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Alcoholic<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display:grid; grid-template-columns:auto 1fr 1fr 1fr 1fr; grid-gap:7px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Active</b></div>
                    <div style='display: flex; flex-direction: rows; grid-gap: 2px;'><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <b>Inactive</b></div>
                </div>
                <f7>Character Creation: Aspect is Active and gain Pipe and 5G worth of Drugs.</f7>
            </div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Purple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Withdrawal</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'></div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <br> Taking Drug Withdrawal is set to <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Withdrawal.
                <br> Addiction <b>(A)</b> is a Con Point representing Addiction. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>1 Morale:</b> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Addiction. <b>Mental Breakdown:</b> May remove all A.
                <br><b>Relapse:</b> If Inactive, roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> for each Dread. <cs>1S:</cs> Active. Withdrawal <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </f8>
                
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <b>Withdrawal Effects:</b>
                <br>&nbsp;&nbsp;&nbsp; <b>0-2 Withdrawal:</b> No Effect.
                <br>&nbsp;&nbsp;&nbsp; <b>3-8 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>9-13 Withdrawal:</b> <b>(AA<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>14-19 Withdrawal</b>: <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>20 Withdrawal:</b> No effect.
            </f8>
                
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You need a drink to get through the day.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$SeaSick</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Sea Sick<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Gain Two Sea Sickness Constitution Points whenever on a boat.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have do very bad at sea.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='10XP Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>10XP Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Hobbled</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Hobbled<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Pace <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div> +1 Pace</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on Challenges that invole Mobility.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Your legs or spine are stunted and/or twisted.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Fat</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Fat<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> Daily Hunger</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Heavy 1 (Resist Push and similar by +1, 20<b6>E</b6>)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to not be seen in certain Stealth/Hide Checks.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If 4 or more Hunger, may remove 1 Hunger and remove 1 Fat Point.</div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Red-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Fat</b><f8>(Exhausted:<br> Discard this card)</f8></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5 Fat <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Exercise</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> -1 Fat Point.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are seriously overweight.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Sickly</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Sickly<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Every Day Roll <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Gain that much Sick <b style='font-weight:900;'>(Sk)</b> Con Points until the end of Day.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a incurable sickness which causes general fatigue.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostHand</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Hand<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Lost Hand:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't do most Hand Actions with this Arm. 
                <br> (10G at Character Creation to get Hook Hand.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Off Arm becomes Main Arm. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Already Adapted.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost your hand.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Coward</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Coward<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Begin Combat:</b> Resist 2 Terror w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Resist Terror/Stress/Dread.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are easily scared.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LameLeg</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lame Leg<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-2 Pace (from Standard Pace). Can use Cane/Crutch to walk better.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on Challenges that invole Mobility.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>May be able to find surgeon to correct problem. (See Medic: Surgeon.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(3G at Character Creation to get Cane.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> One of your legs never quite healed right.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Pacifist</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Pacifist<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Hurting Another Living Creature:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress at end of Combat.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Hurting Another Living Person:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress at end of Combat.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Killing a Living Creature:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress and <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread at end of Combat.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Killing a Person:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread at end of Combat.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a psychological block against harming living things.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$ExtremePhobia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'><f15>Extreme Phobia</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f9>+10/15CP</f9> +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='height:1px;'></div>
                <b>Phobia(s):</b>
                <br> <f7>10AP for Common (Water, Heights/Flying, Insects, Narrow Spaces, Blood, Darkness, Fire, Magic/Technology, Germs)</f7>
                <br> <f7>15AP for Rare (Spiders, Snakes, Other specific creatures/things)</f7>
                <div style='height:1px;'></div>
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread when around Phobia.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                May only attempt Cower Action. Use Morale or Will to ignore for this Round.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cower</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        	<sc>1S:</sc> May Defend this Round.
                    		<br><cs>1S:</cs>  May move 1 Space.
                    		<br><sc>2S:</sc>  May attempt an Active Action.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a deep irrational fear of something.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='15XP Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>15XP Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostArm</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Arm<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Lost Main Arm:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't do Actions with this Arm. Cross out Body Area on Character Sheet.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Off Arm becomes Main Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Already Adapted.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost an arm.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostLowerLeg</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'><f12>Lost Lower Leg</f12><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Use Legs (Pace is Zero) need Crutch/Peg Leg to walk.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on Challenges that invole Mobility.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Lose Leg Harm Point.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(10G at Character Creation to get Peg Leg.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost a leg below the knee.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Craven</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Craven<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Begin Combat:</b> <u>Resist</u> 3 Terror w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Resist Terror/Stress/Dread.
                <br> <b>Getting 1 Stress:</b> Can't Act for <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rounds. (Once per Combat)
                <br> <b>Getting 2 Stress:</b> Become Prone. Can't Act for <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Rounds. <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Fall Dmg. (Once per Combat)
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are easily scared.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Obese</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Obese<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> Daily Hunger</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Pace, <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '><div style='display:inline; font-weight:800; margin-left:1px; margin-right:2px;'>:</div>+1 Pace, Max <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> 2,</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Heavy 2 (Resist Push +2, 30<b6>E</b6>)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> when Resisting Travel Fatigue. Can't Ride Horses</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to not be seen in certain Stealth/Hide Checks.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If 4 or more Hunger, may remove 1 Hunger and remove 1 Fat Point.</div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Red-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Fat</b><f8>(Exhausted:<br> Discard this card)</f8></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5 Fat <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '><div style='display:inline-block; background: white; color: black; font-weight:700; padding: 0px 1px 0px 2px; border:solid 1px black; border-radius:10px; font-size:8px;'>1F</div> Exercise</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> -1 Fat Point.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are morbidly overweight.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Hemophiliac</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Hemophiliac<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Bleed Damage</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Your blood clots slowly.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$ExtremePhobia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'><f15>Extreme Phobia</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f9>+10/15CP</f9> +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='height:1px;'></div>
                <b>Phobia(s):</b>
                <br> <f7>10AP for Common (Water, Heights/Flying, Insects, Narrow Spaces, Blood, Darkness, Fire, Magic/Technology, Germs)</f7>
                <br> <f7>15AP for Rare (Spiders, Snakes, Other specific creatures/things)</f7>
                <div style='height:1px;'></div>
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread when around Phobia.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                May only attempt Cower Action. Use Morale or Will to ignore for this Round.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cower</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        	<sc>1S:</sc> May Defend this Round.
                    		<br><cs>1S:</cs>  May move 1 Space.
                    		<br><sc>2S:</sc>  May attempt an Active Action.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a deep irrational fear of something.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='20XP Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>20XP Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$BloodyCough</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Bloody Cough<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+20CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Every Day Roll <b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>. Gain that much Sick <b style='font-weight:900;'>(Sk)</b> Con Points until the end of Day.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a incurable sickness which causes caughing up blood.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostLegs</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Legs<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+20CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Use Legs (Pace is Zero) need Wheel Chair to move</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(10G at Character Creation to get Wheel Chair.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost most of your legs.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='25XP Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>25XP Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$TerminalIllness</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Terminal Illness<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+25CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>+<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Terminal Illness <b style='font-weight:900;'>(TI)</b> Con Points per Day.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Use Medicine:</b> -1 Terminal Illness.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>There may be a way to cure this, but it will be difficult. (Work with GM.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have an incurable illness giving you a shorter lifespan.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Blind</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Blind<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+25CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can’t See or React to anything. (For example can't Dodge.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>When moving <b>Stumble Check</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>
                    <br><sc>0S:</sc> Knockdown occurs. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Adapt:</b> Need Inspiration towards adapt.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>1. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Stumble Checks. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>2. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Stumble Checks. Ignore when Pace 1.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>3. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> Ignore Stumble when Pace 2.  Visibility 0. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>4. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b>Ignore Stumble when Pace 3. Visibility 1.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Dodge/Block Melee with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>5. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> +Monk1:</b>Ignore Stumble. Visibility 2.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Can Dodge/Block as normal. Can't be Flanked. 
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Stat Drawbacks' style='grid-column-start: 1;grid-column-end: 9;font-size: 30px;font-weight: 900;color: white;'>Stat Drawbacks</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Feeble</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Feeble<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Pink-4);
        
        font-weight:700;
    '>
        Strength
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Cancel out a Torso Harm Point.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Strength Based Attacks have a -<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b> penalty</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are exceptionally weak.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Frail</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Frail<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Cancel out a Torso Harm Point.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Capacity,</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You can barely withstand damage.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Anemic</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Anemic<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Endr
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Remove a Weak Slot from Stamina Meter.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You lose your breath very easily.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Clumsy</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Clumsy<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>When Failing Stealth: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Catastrophic fail. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>All Falls +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dmg. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Resist Knockdown.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You sometimes trip over your own feet.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Uncoordinated</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'><f14>Uncoordinated</f14><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Green-4);
        
        font-weight:700;
    '>
        Dex
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>When getting Hit/losing footing/being surprised: <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> Drop Item.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Resist Disarm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>On a Missed Strike:</b> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <fc>0S:</fc> Drop Weapon.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You randomly drop and buump into things.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Oblivious</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Oblivious<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <sc>0S:</sc> No Active/Full Actions the First round of combat. No Movement unless already moving. (GM Discretion.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are often distracted and slow to react.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Unlikable</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Unlikable<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Turquoise-4);
        
        font-weight:700;
    '>
        Cha
    </div> is Zero. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>At End of Day:</b> You gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress OR Ally gains <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress OR You and Ally gain +<b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Feast:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div>.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> People just don't like you.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Dense</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Dense<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div> is 0. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Train. Ignore with +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can’t Read</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Learn to Read/Train:</b> <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Red-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Learn to Read</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/20 AP</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> Your brain don't work so good.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Irresolute</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Irresolute<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f10>+1 Stat OR +10CP and +<div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div></f10></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div> is 0. <f7>Aspect goes away if above 0.</f7></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Determination requires +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <img 
        src='/Resources/Art/Images/Stamina.svg' 
        height='10px'
        width='10px' 
        style='
            position: relative;
            top: 0px;
            left: 0;
            
            padding: 0px 1px 0px 0px;
        '>.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You're unsure of yourself.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Trauma' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Trauma</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Phobia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Phobia<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                In Character Creation may take 2. 5<div style='display:inline; color:black; font-weight:800;'>AP</div> per Phobia.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='height:1px;'></div>
                <b>Phobia(s):</b>
                <div style='height:1px;'></div>
            </div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Purple-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Common<br> Phobia</div><div style='border: 1px solid var(--Purple-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>, Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> Water, Heights/Flying, Insects, Narrow Spaces, Blood, Darkness, Fire, Magic/Technology, Germs</div></div><div style='display: grid;grid-template-columns: auto auto 1fr ;grid-auto-flow: column;'><div style='display: inline-block;background: white;width: 15px;height: 15px;border-radius: 8px;border: solid 1px black;z-index: 10;'></div><div style='background: var(--Purple-2);color: white;padding: 2px;border-radius: 0px 10px 10px 0px;font-weight: 800;margin-left: -8px;padding-left: 10px;padding-right: 6px;z-index: 8;min-width: 75px;'>Rare<br> Phobia</div><div style='border: 1px solid var(--Purple-4);;margin-left: -8px;padding-top: 2px;padding-left: 10px;color: black;font-size: 8px;z-index: 6;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>, Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b>+<b style='font-weight:700; color: black;'>4<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread.
                <br> Spiders, Snakes, </div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a deep irrational fear of something.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$ExtremePhobia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'><f15>Extreme Phobia</f15><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'><f9>+10/15CP</f9> +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='height:1px;'></div>
                <b>Phobia(s):</b>
                <br> <f7>10AP for Common (Water, Heights/Flying, Insects, Narrow Spaces, Blood, Darkness, Fire, Magic/Technology, Germs)</f7>
                <br> <f7>15AP for Rare (Spiders, Snakes, Other specific creatures/things)</f7>
                <div style='height:1px;'></div>
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>6<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Dread when around Phobia.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                May only attempt Cower Action. Use Morale or Will to ignore for this Round.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Purple-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Cower</div></div> <actionSubtitle style='margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Purple-2)); border-color:var(--Purple-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Purple-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                        	<sc>1S:</sc> May Defend this Round.
                    		<br><cs>1S:</cs>  May move 1 Space.
                    		<br><sc>2S:</sc>  May attempt an Active Action.
                        </div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have a deep irrational fear of something.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Alcoholic</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Alcoholic<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display:grid; grid-template-columns:auto 1fr 1fr 1fr 1fr; grid-gap:7px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Active</b></div>
                    <div style='display: flex; flex-direction: rows; grid-gap: 2px;'><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <b>Inactive</b></div>
                </div>
                <f7>Character Creation: Aspect is Active and gain Pipe and 5G worth of Drugs.</f7>
            </div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Purple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Withdrawal</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'></div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <br> Taking Drug Withdrawal is set to <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Withdrawal.
                <br> Addiction <b>(A)</b> is a Con Point representing Addiction. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>1 Morale:</b> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Addiction. <b>Mental Breakdown:</b> May remove all A.
                <br><b>Relapse:</b> If Inactive, roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> for each Dread. <cs>1S:</cs> Active. Withdrawal <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </f8>
                
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <b>Withdrawal Effects:</b>
                <br>&nbsp;&nbsp;&nbsp; <b>0-2 Withdrawal:</b> No Effect.
                <br>&nbsp;&nbsp;&nbsp; <b>3-8 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>9-13 Withdrawal:</b> <b>(AA<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div> A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>14-19 Withdrawal</b>: <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>20 Withdrawal:</b> No effect.
            </f8>
                
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You need a drink to get through the day.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Addict</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Addict<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display:grid; grid-template-columns:auto 1fr 1fr 1fr 1fr; grid-gap:7px;'>
                    <div><div style='display:inline-block; background:white; height:9px; width:9px; border:solid 1px black; position:relative; top:2px;'></div> <b>Active</b></div>
                    <div style='display: flex; flex-direction: rows; grid-gap: 2px;'><div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <b>Inactive</b></div>
                </div>
                <f7>Character Creation: Aspect is Active and gain Pipe and 5G worth of Drugs.</f7>
            </div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Purple-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Withdrawal</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'></div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <br> Taking Drug Withdrawal is set to <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Withdrawal.
                <br> Addiction <b>(A)</b> is a Con Point representing Addiction. 
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>1 Morale:</b> Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Addiction. <b>Mental Breakdown:</b> May remove all A.
                <br><b>Relapse:</b> If Inactive, roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> for each Dread. <cs>1S:</cs> Active. Withdrawal <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </f8>
                
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
            Each Day without Drug gain 1 <b>Withdrawal</b>. 
                <b>Withdrawal Effects:</b>
                <br>&nbsp;&nbsp;&nbsp; <b>0-2 Withdrawal:</b> No Effect.
                <br>&nbsp;&nbsp;&nbsp; <b>3-4 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>5-6 Withdrawal:</b> <b>(AAA<div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>7-10 Withdrawal</b>: <b>(AA)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>11-15 Withdrawal:</b> <b>(A)</b> in Con.
                <br>&nbsp;&nbsp;&nbsp; <b>16 Withdrawal:</b> No effect.
            </f8>
                
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You self medicate with addictive substances.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostEdge</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Lost Edge<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Trauma</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Begin Combat:</b> <u>Resist</u> 2 Terror w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Resist Terror/Stress/Dread.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Overcome:</b>  Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards overcoming Trauma. 
                <br> After completing remove Trauma.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have lost your edge.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Depression</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Depression<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Trauma</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Max Morale is 1.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Overcome:</b>  Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards overcoming Trauma. 
                <br> After completing remove Trauma.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You wonder if maybe you should just give up.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Nightmares</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Nightmares<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Trauma</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>When Sleeping:</b> Resist 1 Stress w/ <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Overcome:</b>  Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards overcoming Trauma. 
                <br> After completing remove Trauma.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You are haunted in your sleep.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Shakes</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Shakes<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Trauma</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> when Hitting, using Class actions, and using any other Checks that require fine Concentration (GM determined).
                <br>Doesn't Apply to dice rolled with Will/Morale.
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Overcome:</b>  Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards overcoming Trauma. 
                <br> After completing remove Trauma.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> There are times you just can't stop shaking.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Sociopath</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Purple-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Purple-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Purple-3);'>Sociopath<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Edge/Trauma</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>-5CP <div style='display:inline-flex; background:white; color:grey; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div> </div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Ignore Effects of First Kill on a Person, Cold Blooded Murder, Witness Something Terrible.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Purple-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-1 Total Morale.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have no qualms about killing people in cold blood.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Insanity' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Insanity</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Voices</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Voices<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
                <b>Beginning of Round:</b> Roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Mental Strain Point.
                <br><fc>2S:</fc> GM controls Character for Round.
                <br><fc>3S:</fc> GM controls Character for Round. Attempt to Harm Self or Others.
            </f8>
            </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
                <b>Beginning of Day:</b> Roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Mental Strain Point.
                <br><fc>2S:</fc> GM controls Character for part of Day.
                <br><fc>3S:</fc> GM controls Character for part of Day. May attempt to Harm Self or Others.
            </f8>
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$The_Horror_Inside</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>The Horror Inside<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>5 Mental Strain:</b> Immediately attempt to <b>Cut Out The Horror</b></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Cut Out The<br>Horror</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>10<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            Remove <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Mental Strain.
                            <br>Get 1 Wound per Success. May choose Body Area.
                            <br><fc>4S:</fc> Remove Insanity.
                            <br><fc>5S+:</fc> Mortal Wound. Remove Insanity.
                            </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Dispair</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Dispair<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>1 Mental Strain:</b> +1 Apathy Con Point <b>(Ap)</b>.
                <br><b>3 Mental Strain:</b> Can't Eat.
                <br><b>5 Mental Strain:</b> Can’t Drink. Can't Act. (No Day Actions, No Round Actions.)
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$StaringIntoTheVoid</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Staring Into The Void<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Beginning<br> of each<br> Round</div></div> <actionSubtitle style=''></actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'>
                            <b>1 Mental Strain:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                            <div style='height:1px;'></div> <b>3 Mental Strain:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>
                            <div style='height:1px;'></div> <b>5 Mental Strain:</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div>
                        </div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'><fc>0S:</fc> Can't Act this Round.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Seizures</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Seizures<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <f8>
                    <b>1 Mental Strain:</b> If rolling 4 ‘1s’ or all 1s on any Action Check have Seizure.
                    <br><b>3 Mental Strain:</b> If rolling 3 ‘1s’ or all 1s on any Action Check have Seizure.
                    <br><b>5 Mental Strain:</b> If rolling 2 ‘1s’ or all 1s on any Action Check have Seizure.
                </f8>
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);     ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Seizure</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>
                            Become Prone. Cannot Act.
                            Each Round roll <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b>.
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <fc>0S:</fc> Collision <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Insanity Dmg.
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <sc>2S:</sc> End Seizure.
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have random, debilitating seizures.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$DelusionalParanoia</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Delusional Paranoia<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Mental Strain</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Delusion</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily/<br> When Getting<br> Mental Strain</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per<br> Mental<br> Strain</div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> Someone is watching. Can’t Sleep today. 
                                <div style='height:1px;'></div> <sc>2S:</sc> The food is dangerous. Can’t Eat today.
                                <div style='height:1px;'></div> <sc>3S:</sc> The water is dangerous. Can’t Drink today.
                                <div style='height:1px;'></div> <sc>4S:</sc> A random ally is evil. Attempt to KO and capture them. WIll not stop until you are KOd/Killed.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Damaged</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Damaged<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Mental Strain</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Damage</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                            Gain <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound.
                            <br><b>5 Mental Strain:</b> Give yourself a Mortal Wound. Remove Mental Strain.
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$NotMyHand</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Not My Hand<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Mental Strain</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <f8>
                	<b>1 Mental Strain or more:</b> Can’t use Off Hand.
                	<br><b>3 Mental Strain or more:</b> Hand is controlled by GM separately from the rest of your body. Will attempt to Attack you and Allies. May attempt to escape binding.
                	<br><b>5 Mental Strain:</b> GM controls you as long as Hand is still attached. You control your Main hand separately from the rest of your body.
                	<br> Removing the Hand removes the Insanity Card.
            	</f8>
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$ForbiddenSight</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Forbidden Sight<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Mental Strain</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><f8> +<b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div> Challenges </f8> </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
            <f8>
                <b>Beginning of Round:</b> Roll <b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> per Mental Strain  Point.
                <br><fc>2S:</fc> Act as if seeing something not there.
                <br><fc>3S:</fc> Act as if seeing something not there. Attempt to Harm Self/Others.
            </f8>
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);     ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Blind Self</div></div> <actionSubtitle style='color:black; margin-left:3px; margin-top:2px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'>
                            <f8>
                            Lose Insanity.
                            <br> <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound to Head. Blind until Wounds Healed.
                            </f8>
                        </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> See amazing sights no mortal should see.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$MadGenius</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Insane Invention<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Requires <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int 3
    </div> or more.</div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'>Invention</div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/10</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Each Day w/o Working on the Invention gain <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Distracted Con Point <b>(Ds)</b>.</div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center;;'><div style='text-align:center;'><div style='text-align:left;'>Work on the Device</div></div> <actionSubtitle style='margin-left:3px;'>Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Pink-2)); border-color:var(--Pink-2);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Int);
        
        font-weight:700;
    '>
        Int
    </div></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Invention.
                                        <br> <blue><b>10 Invention:</b> Gain Magic Item and/or Terrible Drawback.</blue>
                            </div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Masochist</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Masochist<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Mental Strain</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Ignore effects of Harm 2.
                <br> Will/Moral can't remove Mental Strain.
            </div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Pink-3);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:var(--Pink-3); border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Hurt Yourself</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Full</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:var(--Pink-3);'><div style='background:white; color:black; width:100%; font-size:;'>Give yourself <b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>/</div><b style='font-weight:700; color: black;'>5<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Wound. <br> For each Wound reduce 1 Terror/Stress/Dread.</div></challengeText></challengeContainer></div></actionContainter><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Sanity</div></div> <actionSubtitle style='color:black; margin-left:3px;'>Daily</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:1fr;; '><challengeText style='border-style:solid; border-radius:4px; border-color:black; padding:2px; color:black; font-size:; background:white; height:100%;'><div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Stress per Day.</div></challengeText></challengeContainer><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Purple-4);
        
        font-weight:700;
    '>
        Spirit
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><cs>1S:</cs> +1 Recovery.<br><b>15 Recovery:</b> Lose Insanity.</div></challengeText></challengeContainer></div></actionContainter><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/15</div></div></div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$MurderousIntent</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Murderous Intent<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Insanity</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                Attempt to kill random Ally. Do not stop until end of Day.
                <br> Ignore Harm 2 Effects.
                <br> After a Day has passed lose this card.
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Injuries' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Injuries</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostFingers</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Fingers<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Injury</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't take in Character Creation.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Lost Fingers:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Ignore Lost Finger Penalty.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You lost some digits on your hand.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$OneEye</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>One Eye<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+5CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Notice Actions.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Drawback:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> to Aim/Strike/Block/Dodge Actions.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Ignore Drawback. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If both eyes are lost: trade in for Blind Aspect.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Ignore Drawback (already adapted.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You have lost vision in one eye.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostHand</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Hand<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Lost Hand:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't do most Hand Actions with this Arm. 
                <br> (10G at Character Creation to get Hook Hand.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Off Arm becomes Main Arm. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Already Adapted.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost your hand.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostArm</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Arm<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Lost Main Arm:</b> <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on all Aim/Attack Actions or similar with Off Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't do Actions with this Arm. Cross out Body Area on Character Sheet.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><b>Adapt:</b> Need <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> towards adapt. Off Arm becomes Main Arm.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>If chosen in Character Creation: Already Adapted.</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost an arm.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LameLeg</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lame Leg<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+10CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>-2 Pace (from Standard Pace). Can use Cane/Crutch to walk better.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on Challenges that invole Mobility.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>May be able to find surgeon to correct problem. (See Medic: Surgeon.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(3G at Character Creation to get Cane.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> One of your legs never quite healed right.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostLowerLeg</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'><f12>Lost Lower Leg</f12><div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+15CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Use Legs (Pace is Zero) need Crutch/Peg Leg to walk.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'><div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;'><b>6 Only</b> </div> on Challenges that invole Mobility.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Lose Leg Harm Point.</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(10G at Character Creation to get Peg Leg.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost a leg below the knee.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$LostLegs</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Lost Legs<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+20CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can't Use Legs (Pace is Zero) need Wheel Chair to move</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>(10G at Character Creation to get Wheel Chair.)</div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> You've lost most of your legs.</div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Blind</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Red-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Red-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr auto  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Red-3);'>Blind<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Drawback/Injury</div></div><div style='font-size: 14px;font-weight: 700; color: black;display: flex; align-items: center;padding: 1px;border-radius: 4px;justify-content: flex-end;'>+25CP +<div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div><div style='display:inline-flex; background:lightgray; color:black; height:16px; width:15px; padding:3px; border:solid 1px black; border-radius:15px; font-weight: 600; justify-content:center;'>i</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>Can’t See or React to anything. (For example can't Dodge.)</div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>When moving <b>Stumble Check</b> <div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Orange-4);
        
        font-weight:700;
    '>
        Agl
    </div>+<div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Blue-4);
        
        font-weight:700;
    '>
        Sense
    </div>
                    <br><sc>0S:</sc> Knockdown occurs. </div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Red-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Adapt:</b> Need Inspiration towards adapt.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>1. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Stumble Checks. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>2. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> <div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>2<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> to Stumble Checks. Ignore when Pace 1.
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>3. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b> Ignore Stumble when Pace 2.  Visibility 0. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>4. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div>:</b>Ignore Stumble when Pace 3. Visibility 1.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Dodge/Block Melee with <div style='display: inline-block;background: var(--Dmg-3);color: white;font-weight: 500;font-size: 9px;white-space: nowrap;padding: 1px;border-style: solid;border-color: black;border-width: 1px;border-radius: 4px;padding-left: 0px;padding: 0px 1px 0px 1px;font-size: 8px;'><b>6 Only</b> </div>. 
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>5. <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> <div style='display:inline-flex; background:white; color:grey; height:11px; width:11px; border:solid 1px black; border-radius: 5px; font-weight: 600; justify-content:center;'>i</div> +Monk1:</b>Ignore Stumble. Visibility 2.
                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp Can Dodge/Block as normal. Can't be Flanked. 
            </div></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div><img 
        src='/Resources/Art/Images/CardNote.svg' 
        height='14px'
        width='14px' 
        style='
            position: relative;
            top: 1px;
            left: 0;
            
            padding: 0px 0px 0px 0px;
        '> </div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div><div id='Temporary Effects' style='grid-column-start: 1;grid-column-end: 9;font-size: 40px;font-weight: 900;color: white;'>Temporary Effects</div><div style='grid-column: span 2;display: grid;grid-template-columns: 1fr;grid-template-rows: 12px auto ;grid-gap: 5px 5px;'><div 
                    style='color: white;
                '>$Plague</div><div style='grid-column: span 2;border-radius: 0px 8px 8px 8px;border: solid; border-color: var(--Pink-3); border-width: 2px;Width: 315.503;Height: 235.45;overflow: hidden;text-overflow: ellipsis;background: var(--Pink-1);padding: 0px 3px 0px 3px;display: grid;grid-template-rows: 25px 1fr;'><div style='display: grid;grid-template-columns: 1fr 45px 45px;grid-template-rows: 25px;grid-gap: 2px 2px;grid-template-columns: 1fr  ;'><div style='font-size: 18px;font-weight: 700; color: white;display: flex; align-items: center;border-radius: 0px 20px 20px 0px;padding: 0px 0px 0px 3px;margin: 0px 0px 0px -3px;background: var(--Pink-3);'>Plague<div style='font-size: 10px;font-weight: 500; color: white;display: flex; text-align: left; align-self: flex-end;margin: 0px 0px 1px 2px;border-radius: 4px;'>Sickness</div></div></div><div style='display: grid;grid-template-columns: auto;grid-template-rows: auto 1fr ;grid-gap: 1px 2px;'><div style='display: grid;grid-template-columns: auto; grid-template-rows: auto; grid-auto-flow: row;grid-gap: 2px 2px;font-size: 10px;'><div></div><div style='height: fill-available; border-radius: 4px 4px 4px 4px;border-style: solid;border-width: 1px;border-color: var(--Pink-2);overflow: hidden;text-overflow: ellipsis;padding: 1px 5px;font-size: 10px;text-align: left;position: relative;left: 0;bottom: 0;color: Black;background: White;'>
                <b>Beginning of Day:</b> Remove all Illness (Plague) and gain <b style='font-weight:700; color: black;'>3<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>S</div></b><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>8<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b> Illness (Plague)
            </div><div style='display: grid;grid-gap: 1px;'><div style='display: grid;grid-template-columns: auto;grid-auto-flow: column;grid-gap: 1px;'></div><div style='display: grid;grid-template-columns: auto 1fr;grid-auto-flow: column;grid-gap: 5px;height: 30px;background:var(--Pink-2);color: white;font-size: 10px;padding: 2px;border-radius: 4px;'><div style='align-self: center;display: grid;grid-auto-flow: column; grid-gap: 0px 2px;align-items: stretch;justify-content: left;font-weight: 700;'><b>Recovery</b></div><div style='background: white;color: black;padding: 1px;padding-right: 2px;border-radius: 4px;display: flex;align-items: center;justify-content: flex-end;font-weight: 600;'>/5</div></div></div><actionContainter style='font-size: ; grid-template-columns:auto 1fr; ; '><actionTitle style='background:var(--Gray-4);    align-items:flex-start; flex-direction:column; justify-content:center; ; background:white; border-style:solid; border-color:black; border-width:1px;'><div style='text-align:center; color:black; border-radius:40px; background:white;'><div style='text-align:left; '>Recover</div></div> <actionSubtitle style='color:black; margin-left:3px;'>End of Day</actionSubtitle></actionTitle><div style='display:grid; grid-auto-flow:row; grid-gap:1px; background:none;'><challengeContainer style='grid-template-columns:auto 1fr;; '>
                                <challenge style='border-radius:4px 0px 0px 4px;  background:var(--Gray-3)); border-color:var(--Gray-3);background:white;; border-style:solid; border-width:2px 3px 2px 2px;'>
                                    <nowrap></nowrap>
                                    <challengeInner style=';margin-left:0px;'><div style='text-align:center;'><div style='
        display: inline-block;
        
        background:white;
        padding:0px 2px 0px 2px;
        
        border-width:1px;
        border-style: solid;
        border-radius: 4px;
        border-color: black;
        color: var(--Red-4);
        
        font-weight:700;
    '>
        Fort
    </div><div style='display:inline; font-weight:800; margin-left:1px; margin-right:1px;'>+</div><b style='font-weight:700; color: black;'>1<div style='display: inline;color:var(--Gray-3);font-weight: 800;'>D</div></b></div></challengeInner>
                                </challenge>
                            <challengeText style='margin-left:-1px; padding-left:3px;; ; background:white; border-color:black;'><div style='background:white; color:black; width:100%; font-size:;'><sc>1S:</sc> +1 Recovery.<br><b>5 Recovery:</b> Lose Card.</div></challengeText></challengeContainer></div></actionContainter></div><div style='border-radius: 4px 4px 4px 4px;overflow: hidden;text-overflow: ellipsis;padding: 0px 5px;font-size: 10px;color: Black;display: grid;grid-template-rows: 1fr auto;'><div></div><div style='display: grid; grid-template-columns: auto;'><div></div></div></div></div></div></div></div><b>Total Execution Time:</b> 0.24748396873474 Seconds</div>

</body>
</html>